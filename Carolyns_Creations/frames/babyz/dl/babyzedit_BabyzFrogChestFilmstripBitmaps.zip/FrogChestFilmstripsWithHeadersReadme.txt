
This is part of a little "kit" which I hope will help you to make your
own Toy chests.  It overwrites the Frog.chest.  In order to have the
fullest easy-edit facilities, you should download two zips; one is
the chest with external files. People who understand how to chop and 
strip the filmstrips don't need anything else.

The second zip contains the filmstrips split up for your convenience,
with bitmap header info and an explanation for those who are not familiar
with filmstrips.

Also I've provided this third zipfile, which contains the filmstrip sections 
already provided with their correct bitmap headers.  This is for people who don't
give a toss as to how to do it themselves, but want me to do everything
for them.  Well, I can't do _everything_, you're going to have to strip
off the headers yourself after editing the pics and then stitch 'em together,
but that's the best I can do for you anyway :-)

How to use this third package
=============================

This zipfile contains bitmaps which you can edit and then strip and 
stitch together to make your own CHEST_H2.flm filmstrip:

frogflm1.bmp, frogflm2.bmp, frogflm3.bmp, frogflm4.bmp, frogflm5.bmp

Open these into your favourite paint package and edit them to your 
heart's content.  If your work is going to look good, you need to keep
your pictures so that they fit into each frame of the filmstrip.  The
pink part is see-through to the game; there's nothing to stop you from
filling up the whole of that see-through background if you wish.  A
simple rectangle of a "chest" can be made by simply flooding the whole 
of each of the four strips with a single colour.  Or you could make an
"invisible" chest by filling the whole set with the background colour,
but that would make an extremely frustrating "chest" -- and yes, I did
try it at first on my "gone" chest before I changed it to a gunk one :-)

When you've finished editing, open frogflm1.bmp into a hex editor
and go to the end of the bitmap header.  Look at headerstrip.gif,
it shows you where exactly the bitmap header stops -- it's the same for 
all these bitmaps, the header is 1078 (in decimal) or 0436 (in hexadecimal) 
bytes long.  Now select from that point to the end of the bitmap; this will
be the filmstrip part without the bitmap header.   Choose "copy", open a 
new file in the hex editor and choose "paste".  Go to the end of the new 
file and put the cursor at the very end.

Now open frogflm2.bmp in the hex editor.  In the same way find the end of 
the bitmap header and select from there to the end, choose copy, go to the 
new file and choose Paste.  Go to the end of the new file and put the cursor 
at the very end.

Repeat the process three times more, with frogflm3.bmp, frogflm4.bmp, and
frogflm5.bmp.

Now save the finished filmstrip.  Call it CHEST_H2.flm and replace the
one that's in your game's \art\Sprites\Toychestz\Frog directory -- you
must have that in place already since you've installed the Frog Easy-edit 
kit, haven't you :-)

Enjoy

Carolyn Horn




