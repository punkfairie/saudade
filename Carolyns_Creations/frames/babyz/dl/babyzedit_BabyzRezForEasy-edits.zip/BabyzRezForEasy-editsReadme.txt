
This file is the main babyz Resource file, just with one byte changed so
that it will work with the easy-edit kit.  Do not try to use the BabyzRezPatch
file that's inside the Easy-edit kit on this one.  For your convenience I'm
including in this package everything you actually need to make it work.

So you should see inside this zipfile the following files:

BabyzRezForEasy-editsReadme.txt -- the file you're reading right now :-)
BabyzRez.dll -- the main .dll file.
EasyEditInstallReadme.txt -- read this carefully, please, if you don't even know what BabyzRez.dll is!
Babyzlnzfiles.zip -- the zip containing the vital .lnz files.

Right.  If you've never made new babyz before, nor even seen
your BabyzRez.dll file, please read EasyEditInstallReadme.txt.
If you're reading this because Resource Hacker has crashed once
too many and you want to try it my way, then you need to replace
your BabyzRez.dll file with the one in this zip.  You also need
to install the files from the included Babyzlnzfiles.zip. If you
unzip it into your game's main directory (where the babyz.exe 
is), then all the .lnz files should be in the correct place, 
in subdirectories off a new directory called PtzFiles.  If you 
unzipped it to somewhere else, find the PtzFiles directory and 
move it (using Windows Explorer or My Computer) and drag-and-drop 
it to your Babyz directory.  Take a look in the ptzFiles directory 
now; there should be several subdirectories:

Baby
bunny
clothes
doll
Dropper
Foodblob
milk
rattle
Sipcup
spoon

In all of them you should see .lnz files.  In the Baby 
Subdirectory you should see all the .lnz files which 
are used by the game to make new babyz.  When you want 
to make a new baby, find out which .lnz you want to edit, 
open it in Notepad and edit to your heart's content.

Much quicker and simpler than Resource Hacker, you can
easily keep backup copies of your little .lnz files in case
you need to rehex a babyz, and you need never worry about
ResHack going cranky on you nor your babyzRez.dll corrupting.

Neat, huh?

Happy hexing

Carolyn Horn

