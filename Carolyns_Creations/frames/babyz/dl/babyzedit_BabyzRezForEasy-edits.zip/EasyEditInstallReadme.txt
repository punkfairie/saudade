This is for people who haven't even tried "hexing" before
and don't even know where their BabyzRez.dll file is.

First, find where your Babyz game is installed.  If you don't
know where it is, it's probably in

C:\Program Files\PF.Magic\Babyz\

Your babyz.exe file will be in that main directory.
The BabyzRez.dll file is in your game's Resource directory

C:\Program Files\PF.Magic\Babyz\Resource\BabyzRez.dll

First of all you need to make your BabyzRez.dll file visible
in your Babyz Resource directory in Windows Explorer (or My 
Computer) if it isn't already.  You do this by choosing View 
from the W. E. or M. C. menu bar and then Options.  When the 
dialogue box opens, choose the View tab and make sure that 
"Show all files" is ticked.  Make a copy of the BabyzRez.dll 
and store it somewhere safe.  Also of course you do always make 
sure that your precious adopted .baby files are copied somewhere 
safe, don't you?  It would also be wise to keep this zipfile 
Okay, now that you have everything safe, you can go ahead with 
this installation.

Now put the BabyzRez.dll which is in this zipfile into the
gams'e Resource directory.

If you unzip the file Babyzlnzfiles.zip into your game's main 
directory (where the babyz.exe is), then all the .lnz files 
should be in the correct place, in subdirectories off a new 
directory called PtzFiles.  If you unzipped it to somewhere 
else, find the PtzFiles directory and move it (using Windows 
Explorer or My Computer) and drag-and-drop it to your Babyz 
directory.  Take a look in the ptzFiles directory now; there 
should be several subdirectories:

Baby
bunny
clothes
doll
Dropper
Foodblob
milk
rattle
Sipcup
spoon

In all of them you should see .lnz files.  In the Baby 
Subdirectory you should see all the .lnz files which 
are used by the game to make new babyz.  When you want 
to make a new baby, find out which .lnz you want to edit, 
open it in Notepad and edit to your heart's content.

There you go.  You've got your .lnz files in the crrect place,
your BabyzRez.dll from this downloaded zip, and Notepad at
the ready.  Hurray!  You're all ready to start editing your
own brand-new babyz, without having to touch a hex editor
or any other fancy editing program.  If you don't know what
all the numbers etc mean, just read some basic babyz editing
tutorials.  There are plenty out there, and several forums
where people will give help.

Have fun!

Carolyn Horn
