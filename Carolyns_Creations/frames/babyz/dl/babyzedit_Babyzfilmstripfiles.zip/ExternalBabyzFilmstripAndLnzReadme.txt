

Please read this carefully; it tells you how to make sure that 
your external filmstrip files are installed correctly.

First of all you need to make your BabyzRez.dll file visible
in your Babyz Resource directory in Windows Explorer (or My 
Computer) if it isn't already.  You do this by choosing View 
from the W. E. or M. C. menu bar and then Options.  When the 
dialogue box opens, choose the View tab and make sure that 
"Show all files" is ticked.  Make a copy of the BabyzRez.dll 
and store it somewhere safe.  Also of course you do always make 
sure that your precious adopted .baby files are copied somewhere 
safe, don't you?  It would also be wise to keep this zipfile. 
Okay, now that you have everything safe, you can go ahead with 
this installation.

If you unzip the zipfile Babyzfilmstripfiles.zip into your game's root 
directory (where the babyz.exe is), then all the .lnz files 
should be in the correct place, in subdirectories off a new 
directory called art.  If you unzipped it to somewhere 
else, find the art directory and move it (using Windows 
Explorer or My Computer) and drag-and-drop it to your Babyz 
directory.  Take a look in the art directory now; there 
should be a subdirectory called Sprites.  Inside that there should be
a whole bunch of subdirectories, each containing at least one
.flm and one .flh file.  These are the filmstrips and can
be edited using Nicholas' Tinker program.  Check out the
"Nicholas' Tools" section of my site if you've never heard
of Nicholas or Tinker.

Now to make this all work right, there needs to be a small
change to the BabyzRez.dll file.  You can either do this yourself, using
Nicholas' LNZPro, or you can download the one from my site. It's a
5 megabyte download and you can do it very easily in LNZPro, but
it's your choice.  To change it yourself, open BabyzRez.dll into
in LNZPro.  Find FLH and change it to, say, GLH. Find FLM and 
change it to GLH.  If you want external LNZ files too, change LNZ
to GNZ, but remember also to download my external-lnz package and 
unzip it into the root of your game so as to create the ptzfiles
directory with its subdirectories.


Have fun!

Carolyn Horn
