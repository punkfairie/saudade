
This file is intended for the use of hexers and anyone who wants to
change their Babyz Kitchen.

This Kitchen.env file for Babyz will overwrite your game's original, and unless
you put everything in the correct place it _will_ crash your game, so please
please please make sure that you have your original safe somewhere and copies of
all your babyz somewhere safe.

Place the Kitchen.env in your game's resource\Area directory.

Now unpack the included zipfile, called KitchenFilmstripsEtc, into your game's
main directory (the directory which contains the babyz.exe file)

The unzipping process _should_ create a set of subdirectories like the
ones shown in the included KitchenfilesWhere.jpg picture, with the needed files in

\art\Sprites\Area\Kitchen

If the unzipping process did not do that, then you will have to create the
directories manually, using Windows Explorer or My Computer, and place the files
in there.

What you should get are a load of .flm and .flh files -- these are the filmstrips
and filmstrip-info for the game.

Also in the Kitchen directory are the Kitchen icon and the Kitchen backdrop.  These are 
simple bitmaps and you can change these to whatever you wish in a paint program.
The Window, closet, tap etc filmstrips will still be in the same places; they will 
look the same.

I have not had the time to do my usual process of putting headers on the .FLM
files; all you're getting in this package are the raw filmstrips, and if you
want to know how to put headers on and edit them but don't know how, you will
need to download and study my filmstrip editing tutorials.  Sorry about that.
But at least with this package you don't have to fit them back inside the .env
file when you're done, and if the filmstrips are a nuisance to you you can simply
fill them up with transparency in a hex editor (open the filmstrip in the hex 
editor, select the whole of it and fill it all with hex number FD ).

No sounds have been extracted for this particular playscene.  In case you are interested,
the sounds that the scene contains are the sink/tap on and off noises, the microwave being used,
the window and closet opening and closing, various fridge noises, and birds chirping.  
I haven't had the time or inclination to extract them, sorry.

Have fun giving your babyz nice new kitchens!

Cheers

Carolyn Horn


