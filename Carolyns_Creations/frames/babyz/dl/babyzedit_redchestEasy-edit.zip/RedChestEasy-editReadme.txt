
This is a little "kit" which I hope will help you to make your
own Toy chests.  It overwrites the Chest.chest.  This zip contains
the toychest with external files for your easy-edit convenience, as well
as a subdirectory with the filmstrips split up for your convenience plus
filmstrip bitmap header info and a blank bitmap header to use. 

You'll have to make your own bitmap headers for these, as I don't have the
time to do it now.  If you aren't sure how to do it, take a look in the
FilmstripChopped subdirectory (which should have been created when this
package unzipped) at the screengrabs -- as well as reading this readme
fully oif course :-) 

How to use this package
=======================

If you unpacked this redchestEasy-edit.zip file into the root directory of your 
babyz game -- where the babyz.exe is -- it should have put all the files except 
for the chest.chest itself into the correct places.  The chest.chest will
overwrite the one in your game's ToyChestz directory, so move the original
to somewhere safe before moving the one from this zipfile in there.
The rest of the files should have ended up here, off your main babyz dir:

\art\Sprites\Toychestz\Red

with the wav files in here:

\art\Sprites\Toychestz\Red\Sounds

If they aren't there, then you will have to create the subdirectories, 
using My Computer or Windows Explorer, find where the files were placed 
on your hard drive, and place the files in those directories.

First off, remember to always, always keep a safe copy of any file that
you are going to edit.  Also always keep safe copies of your precious
.baby files; you should do that even if you are not going to edit anything,
as the game can corrupt them.

The Toychest is made up mostly of filmstrips.  If you are just replacing 
your chest, all you need to do is to edit those filmstrips and, if you
wish, give it new sounds.

If you're making an extra toychest, you will need to rename the chest 
and give it a unique ID number so that it will show up separately
in the "choose a toychest" dialogue. For an explanation of ID numbers, 
look at my howto on Un-hiding and giving shelf graphics to difficult toyz.  
Re-naming the toychest is simple, especially if you keep the name the 
same length as the original.  Take a look at my tutorial on hexing 
babyz clothes, I explain there how to rename a file.  One thing to
note with a Toychest, however, is that the ID number can be tricky
to find; it's sandwiched between two copies of the thumbnail bitmap.
I attach a screengrab of where you can find it in the Red toychest.
If you want to change the thumbnail, you will have to either use a
hex editor to change the bitmap which is above the ID number -- it
is lacking the first 14 bytes of the header, which you might find a
bit tricky to deal with, but if you save out the second of the two
bitmaps and edit it, you can copy/paste it (minus the first 14 bytes)
over the first one.

00034432 4300 4800 4500 5300 5400 5000 4900 4300 C.H.E.S.T.P.I.C.
00034448 4B00 5500 5000 3200 0000 0000 0000 0000 K.U.P.2.........
00034464 2800 0000 7000 0000 6000 0000 0100 0800 (...p...`....... <--first one starts with (...p
00034480 0000 0000 002A 0000 0000 0000 0000 0000 .....*..........


00046256 0000 0000 0000 0000 0000 0000 0000 0000 ................     and ends directly before
00046272 0000 0000 0000 0000 0100 0000 546F 7963 ............Toyc <-- the 0100 0000 here
00046288 6865 7374 7A5F 5265 6400 0000 0000 0000 hestz_Red.......
00046304 0000 0000 0000 0000 0000 0000 4368 6573 ............Ches
00046320 7400 0000 0000 0000 0000 0000 0000 0000 t...............
00046336 0000 0000 0000 0000 0000 0000 224E 0000 ............"N..
00046352 0300 0000 0000 0000 424D 362E 0000 0000 ........BM6..... <-- 2nd one starts with BM
00046368 0000 3604 0000 2800 0000 7000 0000 6000 ..6...(...p...`.


00058160 0000 0000 0000 0000 0000 0000 0000 0000 ................     and ends with
00058176 0000 0000 0000 0000 0000 0000 0000 0000 ................ <-- the last-but-two 0000 here
00058192 6500 0000 0F00 9400 AA00 0000 EE00 3101 e.............1.
00058208 7201 B601 0000 0000 5802 5802 4472 6F70 r.......X.X.Drop
00058224 7065 6441 0000 0000 0000 0000 0200 0000 pedA............


Or you can use Resource Hacker to replace it.

How to use the chopped filmstrip bits
=============================

The FilmstripChopped subdirectory contains the five sections of the filmstrip for
the red chest.  The zip also includes a basic bitmap header.  Open each of the
filmstrip sections in your hex editor, also the bitmap header, which you should
copy/paste onto the beginning of each filmstrip section.  Save them as

redflm1.bmp to redflm7.bmp

Now you need to do a bit of work on the headers.  If you're unfamiliar with 
filmstrip editing, grab my Look at BitmapHeaderCorrect.gif
-- this shows, highlighted in red, the numbers that had to be changed to make
the header on part of the frog chest filmstrip, frogflm5.bmp, correct.  It's a
tiny bit different for the hippo, but you should get the idea. Now look 
at RedChestFilmstripHeaderInfo.gif and Don't Panic.  This is all the sections 
shown in Axe, in graphic mode, with the complete section of each selected.  
Choose hippo1 in there.  See the grey bar at the bottom of that bit -- where 
there are red, green and blue buttons?  Look along to where it says something
like

Sel: 0x00000000 - 0x0010eb40  and then Row: 0xb0

Right, the first is the amount selected (in the above example, the whole of 
frogflm5).  The only bit that matters is the end bit of it, 10eb40.  The second 
is the number of rows.  Now...  In the BitmapHeaderCorrect.gif, see where there 
is 40EB10 in red?  That's the "selected" part shown above, 10EB40, backwards.  
Don't ask why, just accept the fact that you need to enter these numbers 
backwards, okay?  And then see where there is B0 in red.  That's the place
in the bitmap header where you need to enter the number of rows.

A bit more work to do here.  This is of course why so few toyz are made...
Look at SelectWholeBitmap.gif.  For this, we are finding out the size of the
bitmap including header, and so we select the whole data inside the file, and
you can see on the bottom, grey, bar this: Sel: 10ef76 bytes.  You need to
enter this, backwards, into the top line of the bitmap header, where you see
I have in red 76EF10.

The final thing to do is to calculate the height of the filmstrip.  So, open your
Windows calculator and make sure it's set to "scientific", and tick the hex
radio button.  Go back to the data we got from Axe, and enter from that info
10EB40, then the "divide" sign, and then B0, then hit the equals sign.  This
gives us the total number of bytes in the filmstrip section, divided by the width
in rows.  See Calculateheight.gif; the answer, 189C, needs to be entered -- 
backwards -- into the final part of the header where I have numbers in red (9C18).

I hope this helps you to see how it works, and enables you to figure out putting 
headers on your red chest -- as well as, in future, strip and edit your own filmstrips 
from other toyz etc.

Once you've got all your filmstrip sections prepared with their headers,
open them into your favourite paint package and edit them to your 
heart's content.  If your work is going to look good, you need to keep
your pictures so that they fit into each frame of the filmstrip.  The
pink part is see-through to the game; there's nothing to stop you from
filling up the whole of that see-through background if you wish.  A
simple rectangle of a "chest" can be made by simply flooding the whole 
of each of the four strips with a single colour.  Or you could make an
"invisible" chest by filling the whole set with the background colour,
but that would make an extremely frustrating "chest" -- and yes, I did
try it at first on my "gone" chest before I changed it to a gunk one :-)

When you've finished editing, open redflm1.bmp into a hex editor
and go to the end of the bitmap header.  Look at headerstrip.gif,
it shows you where exactly the bitmap header stops -- it's the same for 
all these bitmaps, the header is 1078 (in decimal) or 0436 (in hexadecimal) 
bytes long.  Now select from that point to the end of the bitmap; this will
be the filmstrip part without the bitmap header.   Choose "copy", open a 
new file in the hex editor and choose "paste".  Go to the end of the new 
file and put the cursor at the very end.

Now open redflm2.bmp in the hex editor.  In the same way find the end of 
the bitmap header and select from there to the end, choose copy, go to the 
new file and choose Paste.  Go to the end of the new file and put the cursor 
at the very end.

Repeat the process five times more, with redflm3.bmp, to redflm7.bmp

Now save the finished filmstrip.  Call it Chest_h3.flm and replace the
one that's in your game's \art\Sprites\Toychestz\Red directory.

Enjoy!

Carolyn Horn


