
This pair of glasses is created so that you can choose the type
of glasses you want without having to have loads of them on the shelf.
You can mix and match, have three babyz in the game wearing three different
versions of the glasses at once!

First of all, put the .clo file in your game's clothes directory.  Now
unpack the included ClzFilesForBlankGlasses.zip into your game's root
directory -- where the babyz.exe is.  If you installed the game to the
default directory, then that place is probably something like
C:\Program Files\P.F. Magic\Babyz

You should now see this directory:

C:\Program Files\P.F. Magic\Babyz\art\Sprites\Toyz\Clot_GlassesBlank

which contains three .clz files.  The important one when the game opens
is Clot_GlassesBlank.clz -- you _must_ have a Clot_GlassesBlank.clz in
that directory when you take the glasses off the shelf or they will
crash the game.  Nothing bad will happen, but the game will close with an
error message, which is irritating.  So, open the game and take out the 
glasses for one of your babyz.  Now, with the game open, go to that 
directory and rename Clot_GlassesBlank.clz to anything you wish, and 
rename any of the other two files to Clot_GlassesBlank.clz.  Take them
off the shelf in the game, and eureka!  One baby is still wearing the
first pair, but this pair looks different.

The .clz files are all text files, just as .lnz files are.  You can
open them in Notepad and edit them to suit yourself -- make a whole range
of glasses for the blank frames, LOL.  The empty hearts glasses have a load of
comments by me that I hope will be helpful to anyone who wants to have a go.

Enjoy!

Carolyn Horn