
This is the golden harem, or belly-dance, dress for your babyz 
to enjoy.  They seem to enjoy dressing up in all my harem gear :-)

Just pop the .clo file into the game's toyz directory, and the
dress will show up in the clothes closet.  You don't need to worry
about putting extra bitmaps anywhere, the gold shimmery stuff is
inside the file.

Enjoy

Carolyn Horn