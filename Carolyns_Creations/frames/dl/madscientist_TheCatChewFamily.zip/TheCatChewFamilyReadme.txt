
This is a little family of cats which is just a tiny bit strange.
Yes, the mad scientist has been at it again...

_Cat_Chew_D1 was cloned from a test .LNZ which is hidden away inside
the Petz 5 .dll files.  I extracted her to give her life in any of
Petz 3, 4 or 5.  Then I felt that she needed a partner, but because
of her "history" I felt that she was one of a kind.  So I copied her,
made the copy fully male, and then bred her with herself.  What you
see in this zipfile is the girl herself, her other half (literally),
and their resulting child.

Oh, and I include the .LNZ from which I made her, for the Petz 3 and
4 games which don't have this unique test file.

Enjoy

Carolyn Horn, Mad Scientist Extraordinaire :-)