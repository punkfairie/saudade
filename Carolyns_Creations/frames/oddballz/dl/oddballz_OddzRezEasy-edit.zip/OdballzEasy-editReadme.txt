
What you have here is the editable parts of the oddballz
Resource files, and the resource files themselves fixed
up to use external files.  This will overwrite your game's
Oddzrez.dll and Oddzrezx.dll, so please please make sure that
you move the originals to a place of safety first.

Or have a separate, new installation of Oddballz which is
an external-file, easy-edit version, LOL.

If you unpacked this zipfile into your game's main directory 
(where the Oddballz.exe file is) it should have made these 
directories off that main directory:

\ptzfiles\grub
\ptzfiles\lollipop
\ptzfiles\odd
\ptzfiles\snowball

and

\art\flmstrps
\art\Playpenz
\art\Textures

The last two probably already exist; they certainly do if you've
actually played the game at all.  It doesn't matter, you can
either choose to overwrite when it asks or not, your choice.

If you unpacked the zip anywhere else, then you're going to have
to move all those directories into the correct place.

You should find inside each of those subdirectories a bunch of files.

Inside the first four, the ptzfiles ones, are a bunch of .lnz and .txt
ones.  Edit those to change the shapes and colours of the grubs,
lollipop, and snowball puff.  The breed ones only seem to be there
to show people who only have the demo what they're missing, but they
are quite handy for a quick study of how the breedz are designed.

Inside the first of the art ones, you'll find the meat of your game's
resource files; it's got all the filmstrips which make up the funnel,
egg-holder, toy-holder and toys.  The 15 .flh files you don't really
want to touch; they tell the game which frame is where in the .flm files
and how wide or long the sections are. It's the 15 .flm files that 
you want to fiddle with to alter the look of your game.

(By the way, you won't find the hand cursor icons here.  If you want 
to edit those, they are in the .wad file and not simple to extract.)

You now have two choices...  

The first choice: If you have Tinker version 1.5 or later,
created by Nicholas and available at various places including my site,
you can use it to edit your filmstrips and change the graphics for
others which you have created.  Nice and simple.

The second choice: for masochists who want to do it the old-fashioned way :-)
In order to edit the filmstrips, you need to split them into sections
because the sections of a filmstrip tend to be different widths.  I use
Axe, in graphic mode, to do this as explained in my filmstrip-editing
tutorial OddballzfilmstripsEditing.txt, included in this zip.  Also you need 
to put a bitmap header on the sections and edit that header to make the 
bitmap viewable correctly.

I am providing in a separate zipfile a bitmap header for Oddballz plus
a set of the filmstrip sections for the egg and toy holder, prepared 
complete with headers so that you can edit them, also one or two of
the other items.  I've not had time to do the same for the Robo Pogo,
the food, or the Atomic Ball.  Once you've edited your resulting bitmaps
suitably, you will need to pop them into a hex editor, strip off the
bitmap headers (1078 bytes, or hexadecimal 0436 bytes) and then join
them up in the correct order -- for instance, shelf001 comes first, then
shelf002 etc.  Then overwrite the original fimpstrip with the one you've
just created, and enjoy.

Cheers

Carolyn Horn


