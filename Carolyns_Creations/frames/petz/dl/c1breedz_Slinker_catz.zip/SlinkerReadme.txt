
This is a new breed, the Slinker Cat, for Catz 
(the original Catz program).

Installation instructions:

I am going to assume that your Catz program has been
installed into the directory D:\Catz.XXX.  The disc
and directory name will probably be different for you,
of course.

Put the two files kslinky.lnz and aslinky.lnz into the
Ptzfiles\Cat\Resource directory.  Put Sandy.cat into
the root Catz directory (Catz.XXX).

Open the file "Lastcat.ini" into a text editor such as
Notepad.  It will look like this:

[Catz]
This Last Cat=D:\CATZ.XXX\Cat0.cat

Where Cat0 is the name of the last cat you played with.
Change this to:

[Catz]
This Last Cat=D:\CATZ.XXX\Sandy.cat

and save the file.

You can now open the game, and Sandy will be there, ready
to play.  At present she is a kitten; she will grow to
be less fluffy, and will have a leaner, longer look.

NOTE:
If you wish to adopt a _brand new_ Slinker kitten, you
must temporarily remove one of the P.F.Magic breeds 
from the Ptzfiles\Cat\Resource directory, and rename 
the files aslinky.lnz and kslinky.lnz to the name of
that breed.  Make sure that there are no .cat files in the
main directory, and open up catz.  The slinker will pop
up out of the basket of whichever breed was replaced.
Simply adopt the cat in the usual manner, ignoring the
fact that the breed name and picture is the old one.
Close the game.

Now, rename the files back to aslinky.lnz and kslinky.lnz
and replace the P.F.Magic files.  You must next open the
.cat file of your newly-adopted kitten into a text editor
(Notepad) and make sure that the line which starts Cat1=
is changed to point to the Slinker file:

Cat1=\ptzfiles\cat\resource\Aslinky.lnz

And that's it!  You can now play with each of your adopted
cats in turn, including your new Slinker.

Enjoy!

Carolyn Horn



