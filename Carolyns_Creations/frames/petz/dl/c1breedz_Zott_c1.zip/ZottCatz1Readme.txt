
This is a new petz breed: the Zott Cat, for Catz (the original Catz 
program).  Zott is one of the "oddpetz" range, which means that it
has come to your game from a later P.F.Magic game -- Oddballz.

Oddballz pets are quirky, madcap creatures which have been stuck
in a time-warp; P.F.Magic never released an improved version of the
game, so Oddballz are fated always to play alone or with grubz.  
I started to do their conversion to the later petz games in order that
they may be able to play with other pets at last; I had no intention
of porting them also to Catz 1 because of the limitation they would
be under in going back to an even earlier game.  They cannot have their
skin-patterns, and they must still play alone.  Except that, in this
game, they have those fun little mice to play with and (if their
owners buy a later Catz game, from Catz II onwards) -- they may 
be imported into those and eventually be able to play and even 
breed with other petz.

The various extras -- transformations and emoticons and some 
behaviours -- which the original Oddballz had are missing, of course,
but in this Zott you will sometimes glimpse a small vestige of its
electrical nature in its antennae.  Those antennae are thinner when
Zott is a kitten, and will fill out as it gets older.

If you want Zott to have its own sounds, you will need to download
the sounds zipfile -- it should be downloadable from the same site
from which you downloaded this breedfile.  Move all the files which
are at present in your game's Sounds directory into a temporary place
for safekeeping.  Make sure that all the files which you will find in
the sounds.zip are placed in the Sounds directory.  

Breed installation instructions:
================================

I am going to assume that your Catz program has been
installed into the directory D:\Catz.XXX.  The disc
and directory name will probably be different for you,
of course.

Put the three files kzott.lnz, azott.lnz, and zottsn.txt 
into the Ptzfiles\Cat\Resource directory.  Put Zotto.cat 
into the root Catz directory (Catz.XXX).

Open the file "Lastcat.ini" into a text editor such as
Notepad.  It will look like this:

[Catz]
This Last Cat=D:\CATZ.XXX\Cat0.cat

Where Cat0 is the name of the last cat you played with.
Change this to:

[Catz]
This Last Cat=D:\CATZ.XXX\Zotto.cat

and save the file.

You can now open the game, and Zotto will be there, ready
to play.  At present he is a kitten; he will grow to
have a leaner, longer look and develop black tips to his ears.

NOTE:
If you wish to adopt a _brand new_ Zott kitten, you
must temporarily remove one of the P.F.Magic breeds 
from the Ptzfiles\Cat\Resource directory, and rename 
the files azott.lnz and kzott.lnz to the name of
that breed.  Make sure that there are no .cat files in the
main directory, and open up catz.  The Ginger-mix will pop
up out of the basket of whichever breed was replaced.
Simply adopt the cat in the usual manner, ignoring the
fact that the breed name and picture is the old one.
Close the game.

Now, rename the files back to azott.lnz and kzott.lnz
and replace the P.F.Magic files.  You must next open the
.cat file of your newly-adopted kitten into a text editor
(Notepad) and make sure that the line which starts Cat1=
is changed to point to the zott file:

Cat1=\ptzfiles\cat\resource\Azott.lnz

And that's it!  You can now play with each of your adopted
cats in turn, including your new Zott.

Enjoy!

Carolyn Horn
