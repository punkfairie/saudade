
This is the Appaloosa breedfile for Catz 2.  It was made at the request
of Sue of the Petz Boardwalk, and was exclusive to that site until, sadly,
it closed.  The site has now re-opened (as of early-mid 2002), but Sue
has kindly agreed that the breed should no longer be exclusive.

Place Appaloosa.cat and AppaloosaX.cat in your Resource\catz directory, 
and you will then be able to adopt three different colours of Appaloosa from it.
You also need to place the three furfiles stripg11.bmp, stripg13.bmp,
stripg14.bmp in that directory if you want your pets to have the
distinctive Appaloosa markings.

If you want your pets to speak "horse", then download the sound
files also, which should be available at the site whence you downloaded
this breedfile.  If you do download the sounds, then make a subdirectory 
off your Resource\catz directory, and call it ap.  Place all the .wav files 
and apsn.txt into this subdirectory.  Next time you bring out your 
Appaloosaz, they should talk to you.

Enjoy!

Carolyn Horn