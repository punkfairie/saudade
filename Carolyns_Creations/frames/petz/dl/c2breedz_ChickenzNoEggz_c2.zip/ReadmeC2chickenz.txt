
NOTE: This version of the breedfile is fixed so that new
adoptees will _not_ "lay eggs" when excited.  Any pets
adopted from the previous version may still do so but if so,
as before, it does them no harm and the extra ballz will
disappear after you put the pet away.  The previous version
is also available for those who like that unusual
Feature :-)

This is the Catz 2 breed file for the Chickenz.

Put the Chickenz.cat, ChickenzX.cat, and Feathers.bmp files in your 
Resource\Catz directory. 

The Chickens will then show up in your 
Adoption Centre the next time you go there.

If you want them to talk "Chicken" to you even as chicks,
then make sure you have downloaded the sound files also
(available from the site whence you downloaded this file),
and create the subdirectory:
Resource\Catz\chk
Put all the .wav files in there, also the chksn.txt file which 
is in this Petz 2 Chickenz zipfile; say "yes" to overwrite if it 
asks you.

Enjoy!

Carolyn Horn

