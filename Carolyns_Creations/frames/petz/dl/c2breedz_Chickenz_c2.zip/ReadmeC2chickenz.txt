
This is the Catz 2 breed file for the Chickenz.

Put the Chickenz.cat, ChickenzX.cat, and Feathers.bmp files in your 
Resource\Catz directory. 

The Chickens will then show up in your 
Adoption Centre the next time you go there.

Note that some chickenz have the tendency to get excited
when they are put in the basket -- and when they are excited,
chickenz try to lay "eggz" ;->  this means they suddenly produce
lots of different-coloured ballz all around them.  Don't worry
about it; the ballz will go away when the chickenz are put away
through their door for a litte bit of peace, and neither they
nor the game are harmed by it.

If you want them to talk "Chicken" to you even as chicks,
then make sure you have downloaded the sound files also
(available from the site whence you downloaded this file),
and create the subdirectory:
Resource\Catz\chk
Put all the .wav files in there, also the chksn.txt file which 
is in this Petz 2 Chickenz zipfile; say "yes" to overwrite if it 
asks you.

Enjoy!

Carolyn Horn

