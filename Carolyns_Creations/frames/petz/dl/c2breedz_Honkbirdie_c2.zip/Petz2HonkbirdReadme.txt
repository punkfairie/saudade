
This is the Honker "birdie" breed for Catz 2.  It is one of the 
Transformations of the Honker Oddball and uses data from the Oddballz
breed, complete with sounds.

For your Honkbirdie to look and sound right, you will have to make sure that 
all its .wav files (available where you downloaded this breedfile) and the 
brdsnd.txt file, feathers.BMP and Ant4.bmp, are in a subdirectory off your 
resource\catz directory, called honk.

Enjoy!

Carolyn Horn



