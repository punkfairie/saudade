

This is the Modvark breed for Catz 2.  It uses data from the Oddballz
breed, complete with sounds.  It has had to leave behind it the 
various Transformations and emoticons that it used when it came out
of the Oddballz egg, but now at last your Modvark can play with and meet 
other petz.  They will also be able to breed with any Catz-based breed.

You cannot import your Oddballz pet directly from the Oddballz game, you will 
have to re-adopt him or her from the Adoption Centre.  But I think you
will find your pet as lovable as ever; even if it has lost its "memory",
it is still the same nervous, intelligent, quirky little thing.

The original Modvark is in the Adoption Centre, of course, with its
hip body-fur and black eyes.  But you will find a whole family of 
Modvarks in there, some with different fur styles and different coloured 
eyes.  Just put back whichever ones come out that you don't want, until the 
right one for you comes out.

Place the Modvark.cat and ModvarkX.cat files in your game's resource\catz
directory, of course.  But also, if you want it to look right, you will
have to put all three of the bitmaps -- Modvo4.BMP, Modvo5.BMP, and Modvo9.BMP
-- in a subdirectory off your resource\catz directory which you will need to
create and name modv.

For your Modvark to sound right, you will have to make sure that all its
.wav files and the modvsn.txt file are also in that resource\catz\modv
directory.  You should be able to download the sounds from the same site 
from which you downloaded this breedfile.  Replace the modvsn.txt which
is with the sound archive with the one that is included with this breedfile.

Enjoy!

Carolyn Horn

