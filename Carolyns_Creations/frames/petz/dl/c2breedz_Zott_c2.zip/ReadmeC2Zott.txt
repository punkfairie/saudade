

This is the Zott breed for Catz 2.  It uses data from the Oddballz
breed, complete with sounds.  It has had to leave behind it the 
various Transformations and Emoticons that it used when it came out
of the Oddballz egg.  Having said that, The Zott is a little different 
from other Oddballz-pets, in that it has a vestige of its Oddballz
electricity still faintly apparent at the base of its antennae :-)

But also, as with other Odd-petz, now at last your Zott can play with and 
meet other petz.

You cannot import your Oddballz pet directly from the Oddballz game, you will 
have to re-adopt him or her from the Adoption Centre.  But I think you
will find your pet as lovable as ever; even if it has lost its "memory",
it is still the same bouncy, electric, quirky little thing.

The original Zott is in the Adoption Centre, of course, with its
red/yellow-spotted body-fur and black eyes.  But you will find a whole 
family of Zottz in there, some with different fur colours and different 
coloured eyes.  So, just put back whichever Zott comes out that you don't 
want, until the right one for you appears.

For your Zott to sound right, you will have to make sure that all its
.wav files and the zottsn.txt file are in a subdirectory off your 
resource\catz directory, called zott.  You should be able to download
the sounds from the same place from which you downloaded this breedfile.
Replace the zottsn.txt which is with the sound archive with the one that 
is included with this breedfile.

Enjoy!

Carolyn Horn

