
I made this breed myself, several years ago, for someone called Amanda
who said that she wanted a breed which looked like a cross between a
Persian and a Lollipop Cat.  When I suggested that she tried to do it
herself, she was very unhappy and I took pity on her.  My Blinka breed
is the result.  I do not make "private" breedz for people and I had no 
idea that this requester had expected the Blinka to be for her alone.
So in case anyone else asks for something and then gives me a hard time
for making it available to everyone, I repeat.  I do not make private
breedz or litterz; breed-making takes too much of my time, and I always 
make the results freely available.  Even when I have made an "exclusive"
for someone's site, I have always made it clear that if it is no longer
downloadable from that site I shall make it available elsewhere.

This is a file which has been sound-stripped to make the download small.  

If you want your pets to have sounds, you will need the Persian
sounds which should be available from the place from which you downloaded this file
or from my site.  When you have downloaded the sounds, if you unzip them into
the game's main directory they should all go into the correct place.

If for some reason the unzipping process doesn't place them into the following
subdirectory which it should have created off your game's main directory:

\ptzfiles\cat\pr

then you will have to create that set of subdirectories yourself, using either
My Computer or Windows Explorer.  Off the game's main directory (where the .exe
file is) create a directory and call it ptzfiles.  Off that one, create another
and call it cat.  Off that one, create another and call it pr. Place all the .wav 
files and the prsnd.txt file in that "pr" directory. Your pets will talk then.

Enjoy!

Carolyn Horn


