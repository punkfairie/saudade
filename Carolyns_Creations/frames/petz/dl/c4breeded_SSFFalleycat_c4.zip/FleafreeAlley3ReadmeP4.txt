
This is the Flea-and-sickness-free Alley cat, for Petz 4.

This breed overwrites the original, so take care to move your original
to somewhere safe before you install this one.  You may want your original
one later on.

This is a way of adopting Alley catz which don't have the excessive fleas
and sickness of the original alley cat.  It also has all the variations 
listed at the Petz Kennel Club
http://petzkennelclub.co.uk/standards/c_alleycatz.shtml
which should make breeding them even more interesting.  You should also be
able to enter alleys from this breed into shows, since they really are
true alley cats -- just without the constant sickness :-)

Alleys adopted from this breedfile will have only a normal catz tendency
towards fleas or sickness, not the constant one of the original alleys.
Unfortunately, pets adopted from the original breedfile will still be
just as flea-ridden and sick whether you use this new file or not; it's
only pets adopted and bred from this breedfile which will be free of
sickness.

If you want your Alleys to have sounds, you can either run your newly-adopted
pets with the original breedfile in place, or you can download the Alley sounds
which should be available from the place from which you downloaded this file
or from my site.  

When you have downloaded the sounds and unzipped the sounds zipfile, you 
should see the following subdirectory which it should have created off 
whichever directory you unzipped it into:

\ptzfiles\cat\ac

all the .wav files and the acsnd.txt file should be in that "ac" directory.
Shift this nest of directories so that they come off your game's main
directory.  Do this using either My Computer or Windows Explorer to drag and
drop it there.  If for some reason the unzipping process doesn't create these 
subdirectories, then you will have to create them yourself, using either My 
Computer or Windows Explorer.  Off the game's main directory (where the .exe 
file is) create a directory and call it ptzfiles.  Off that one, create another
and call it cat.  Off that one, create another and call it ac.

Your Alleys will talk correctly then.

My thanks to Sleepycat for her encouragement and help.  She provided 
the boost to get me to finish my original flealess breed and added a variation 
to it, and she encouraged me to make a version that conforms more to the 
PKC standard and has its own proper alley sounds.  She has also taken time
to test pets adopted from the flealess file to second-generation and beyond,
and has found that even with the original breedfile in place 2nd-gens from
parents which had been adopted from flealess files will also be flealess.
She has a version of the flealess alley with improved eyes up at her Yahoo group
http://groups.yahoo.com/group/sleepycats_petz_space/

Enjoy!

Carolyn Horn


