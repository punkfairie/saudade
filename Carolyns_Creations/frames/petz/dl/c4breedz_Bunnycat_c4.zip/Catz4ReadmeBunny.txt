
This is the Catz 4 breed file for the Bunny Cat.
Put it in your Resource\Catz directory, and it will show
up in your Adoption Centre the next time you go there.

If you want your Bunny catz to speak "bunny", you will
need to make sure that you have the sounds also.  They
should be in the zipfile with this breed.  Put all the
.wav files and the bnsn.txt file into a subdirectory, off
your game's resource\catz directory, called bn.

Enjoy!

Carolyn Horn

