

This is the Catz 4 breed file for the Dalmatian.
Put it in your Resource\Catz directory, and it will show
up in your Adoption Centre the next time you go there.

NOTE: The Dalmatian catz will breed happily.  They have one
unusual feature, however; when the baby is first born to a 
Dalmatian catz couple, it will appear to be all connected up
wrongly.  This is a very temporary condition, as the next time
you open the game the proud mum will bring it out looking
perfectly normal, and the kitten will grow up fine and healthy.  
The reason for this quirk is the name of the breed -- Dalmatian.  
The game is fooled briefly into using the information from the 
dogz part of the resource files, and dogz are connected up
differently from catz.

This is a file which has been sound-stripped to make the download small.  

If you want your pets to have sounds, you will need the Calico cat
sounds which should be available from the place from which you downloaded this file
or from my site.  When you have downloaded the sounds, if you unzip them into
the game's main directory they should all go into the correct place.

If for some reason the unzipping process doesn't place them into the following
subdirectory which it should have created off your game's main directory:

\ptzfiles\cat\ca

then you will have to create that set of subdirectories yourself, using either
My Computer or Windows Explorer.  Off the game's main directory (where the .exe
file is) create a directory and call it ptzfiles.  Off that one, create another
and call it cat.  Off that one, create another and call it ca. Place all the .wav 
files and the casnd.txt file in that "ca" directory. Your pets will talk then.

Enjoy!

Carolyn Horn


