
This is the Honey Bear cat, one of the 10 new official breedz 
which come with Petz 5, converted to Catz 4 for your gaming pleasure.

If others want to change the breed, that's fine by me -- I'm just
giving people who don't have Petz 5 the breedz as designed by Studio Mythos.

In Petz 5, the furfile is in another resource of the game; in the 
conversion, it has to be a separate file.

Please note, in order for your Honey Bear to show up with its
furfile markings, you _need_ to be sure that the honey1.bmp file
is in your game's resource\catz directory.

This is a file which has been sound-stripped to make the download small.  

If you want your pets to have sounds, you will need the Honey Bear
sounds which should be available from the place from which you downloaded this file
or from my site.  When you have downloaded the sounds, if you unzip them into
the game's main directory they should all go into the correct place.

If for some reason the unzipping process doesn't place them into the following
subdirectory which it should have created off your game's main directory:

\ptzfiles\cat\hb

then you will have to create that set of subdirectories yourself, using either
My Computer or Windows Explorer.  Off the game's main directory (where the .exe
file is) create a directory and call it ptzfiles.  Off that one, create another
and call it cat.  Off that one, create another and call it hb. Place all the .wav 
files and the hbsnd.txt file in that "hb" directory. Your pets will talk then.

Enjoy!

Carolyn Horn
