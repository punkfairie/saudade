

This is a sound-stripped breed for Petz 5.  It is an original game
breedfile, just with some parts of it shifted onto your hard drive.

The .lnz files have been shifted to the hard drive so that people who
want to make litterz or overwriting breedz, but cannot bear to use a Hex
editor or Resource editor, will be able to do so using only Notepad. 

The sounds bave been shifted to the hard drive so that you can download 
the sounds just once (they will work with all versions of the Petz games 
3, 4 and 5) and then all the breedfile downloads will be small, for all 
versions of the games. 

This breed overwrites the original, so take care to move your original
to somewhere safe before you install this one.  You may want your original
one back one day.

When you unzip this zipfile, you should see this readme and the breedfile; 
you should also see the following subdirectory which it should have created 
off whichever directory you unzipped it into:

\ptzfiles\cat\em

Inside this "em" directory there should be two .lnz files.  What you need to
do is to shift this nest of directories so that they come off your game's main
directory.  If for some reason the unzipping process doesn't create these 
subdirectories, then you will have to create them yourself, using either My 
Computer or Windows Explorer.  Off the game's main directory (where the .exe 
file is) create a directory and call it ptzfiles.  Off that one, create another
and call it cat.  Off that one, create another and call it em.

If you want your pets to have sounds, you can either run your newly-adopted
pets with the original breedfile in place, or you can download the relevant 
sounds which should be available from the place from which you downloaded this file
or from my site.  When you have downloaded the sounds, if you unzip them into
the game's main directory they should all go into the correct place.  If not, make
sure that the .wav files and .txt file are all moved into the same subdirectory 
as the .lnz files.

Enjoy!

Carolyn Horn


