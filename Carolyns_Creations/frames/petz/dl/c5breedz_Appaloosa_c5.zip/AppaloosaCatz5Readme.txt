
This is the Appaloosa breedfile for Catz 5.  It was made at the request
of Sue of the Petz Boardwalk, and was exclusive to that site until, sadly,
it closed.  The site has now re-opened (as of early-mid 2002), but Sue
has kindly agreed that the breed should no longer be exclusive.

Note that, if you have had problems with breeding pets from the Appaloosa files 
which used to be up at the Petz Boardwalk, you will be able to breed them without
problems using this breedfile.

Place it in your Resource\catz directory.  Make a subdirectory 
off your Resource\catz directory, call it ap, and place the three bitmaps 
into it.  You will then be able to adopt three different colours of Appaloosa 
from it.

If you want your pets to speak "horse", then download the sound
files also, which should be available at the site whence you downloaded
this breedfile.  If you do download the sounds, then place all the .wav files 
and apsn.txt into the "ap" subdirectory.  Next time you bring out your 
Appaloosaz, they should talk to you.

NOTE: If you are importing Appaloosaz from a previous version
of the game, you will be able to do so using this breedfile.
However, Petz 5 does not keep its bitmaps for all breedz
in quite the same place as in those earlier games.  This
means that your pet will import but will have lost its
skin markings.  The only way to fix this is to edit the 
pet itself; I've made this as simple as possible, but 
make sure that you make a copy of your pet somewhere 
safe first!!  I've made it so that you don't need to
bother about the checksum, but unless someone makes a
program to edit petfiles you will need to copy and paste
some text.

Okay, this is what you must do:

Open your pet into a hex editor, or get a friend who
knows how to use a hex editor to do so for you.
Now find the first instance of the words Texture List

Below that you will see some or all of these lines of text:

\art\textures\Plush.bmp
\art\textures\hair10.bmp
\art\textures\hair10.bmp
\ptzfiles\cat\ta\stripg11.bmp
\ptzfiles\cat\ta\stripg13.bmp
\ptzfiles\cat\ta\stripg14.bmp
\art\textures\Plush.bmp
\art\textures\hair10.bmp
\art\textures\hair10.bmp
\ptzfiles\cat\ta\stripg11.bmp
\ptzfiles\cat\ta\stripg13.bmp
\ptzfiles\cat\ta\stripg14.bmp
\art\textures\Plush.bmp
\art\textures\hair10.bmp
\art\textures\hair10.bmp
\ptzfiles\cat\ta\stripg11.bmp
\ptzfiles\cat\ta\stripg11.bmp

You need to replace each instance of

\ptzfiles\cat\ta\stripg
with
\resource\catz\ap\jstri

So, open this readme into the hex editor also.
For each line of text 
\ptzfiles\cat\ta\stripg11.bmp
or
\ptzfiles\cat\ta\stripg13.bmp
or
\ptzfiles\cat\ta\stripg14.bmp
that you see in that texture list, paste
the equivalent line of text that you see below here:

\resource\catz\ap\jstri11.bmp
or
\resource\catz\ap\jstri13.bmp
or
\resource\catz\ap\jstri14.bmp

in other words, you replace:

\ptzfiles\cat\ta\stripg11.bmp
with
\resource\catz\ap\jstri11.bmp

\ptzfiles\cat\ta\stripg13.bmp
with
\resource\catz\ap\jstri13.bmp

\ptzfiles\cat\ta\stripg14.bmp
with
\resource\catz\ap\jstri14.bmp

Save.  You only need to do this once.  Your pet should 
now come out looking as it always did, provided that you put 
the bmp files in that directory called ap.

Enjoy!

Carolyn Horn
