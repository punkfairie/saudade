
NOTE: This version of the breedfile is fixed so that new
adoptees will _not_ "lay eggs" when excited.  Any pets
adopted from the previous Petz 4 version will still do so but,
as before, it does them no harm.

This is the Catz 5 breed file for the the Cow.  

Put the Cow Taurus.cat file in your Resource\Catz 
directory, and create the subdirectory:
Resource\Catz\cowz 
Put the two furfiles Leath.bmp and Spotty.bmp in this "cowz" 
subdirectory.  If you are also downloading the sounds for this
breed, put all the wav files and cowsn.txt in there also. 

The Cowz will then show up in your Adoption Centre the next 
time you go there.

Included in the breed are some variations:

The Holstein cow, which  originated in Europe.  The original
stock were all-white and all-black, and interbreeding of
these two types created the black-and-white variety we know today.

The Brown Swiss breed, which is one of the oldest of the dairy 
breeds in the world.

The "German Yellow", which originated in Bavaria.  The breed
was originally selected for meat, milk and work.  It is red in 
colour, with strong skin pigmentation, and horned.

Being virtual cowz, The Cow Taurus comes with or without horns and with 
or without udders on a random basis, whether they be male or female
-- so just choose whichever combination you want when it comes out 
of the Adoption Centre.

Enjoy!

Carolyn Horn

