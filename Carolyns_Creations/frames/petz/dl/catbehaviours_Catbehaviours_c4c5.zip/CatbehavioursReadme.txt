
A note to anyone who thinks that they are getting the full catz games
with this kit; this is _not_ the case, even though the game is fooled
into thinking that the Catz part is present.  There are several things 
still missing, such as the sounds resource file, but you don't need those
items in order to play with my custom-crafted Oddballz-petz :-)

If you want to play the full Catz 4 or Catz 5, buy the games.

These are most of the behaviour files for catz in the games petz 4 and 5.
I am supplying these so that people who have only the dogz parts of
these Petz games can play with my catz-based Oddballz-to-petz breedz.
I do not wish to convert all of the Oddballz-petz to Dogz-based breedz,
partly because, at heart, Oddballz are more like catz than dogz -- and
partly because converting them all would be a huge task.

However, I did promise some people that I would make it so that they
could play with Oddballz-petz in their dogz games.  So here is a compromise 
that I hope Dogz-games players will accept.

You only need to download these behaviours once, but you will need to 
Install them into the correct place in each of the versions of the games
that you are intending to run.  Also you will need to download the small
Rez zip for the version of the game that you are playing.

How to install
--------------

If you unzipped this Catbehaviours_c4c5.zip into the root directory of your 
game (where the Petz .exe file is), everything should have gone into
the correct place.  If not, you will have to shift the files by dragging
and dropping them in Windows Explorer (or My Computer).  There should be 
a subdirectory off wherever you unzipped it, called ptzfiles.  This 
subdirectory should contain another, called cat.  Inside this cat
directory, you should see 493 files with the extension .bdt.  Drag and
drop the whole thing so that the subdirectory ptzfiles is directly off
your game's root directory.  If you have already installed various of
my "external-lnz" breedz, ptzfiles will already be there; in which case
just drag and drop the cat directory into it.

You also need to download the relevant rez file for your game.  When you
unpack that, there will be a .dll inside as well as a readme similar to this
one. make sure that you place the Catz Rez.dll in your game's Resource 
directory, and create another directory off that one which should be called
Catz.

That's it.  Now you're ready to download one of my Catz-based breedz for
your version of the game, and play!

Enjoy

Carolyn
