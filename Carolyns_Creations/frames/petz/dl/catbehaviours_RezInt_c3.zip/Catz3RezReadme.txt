
This is a part of the behaviour files for catz in the game petz 3,
non-English-language version.

I am supplying this so that people who have only the dogz part of
the Petz game can play with my catz-based Oddballz-to-petz breedz.
I do not wish to convert all of the Oddballz-petz to Dogz-based breedz,
partly because, at heart, Oddballz are more like catz than dogz -- and
partly because converting them all would be a huge task.

However, I did promise some people that I would make it so that they
could play with Oddballz-petz in their dogz games.  So here is a compromise 
that I hope Dogz-games players will accept.

A note to anyone who thinks that they are getting the full catz games
with this kit; this is _not_ the case, even though the game is fooled
into thinking that the Catz part is present.  There are several things 
still missing, such as the sounds resource file, but you don't need those
items in order to play with my custom-crafted Oddballz-petz :-)

How to install
--------------

You should find a .dll inside this zip as well as this readme. Make 
sure that you place the Catz 3 Rez.dll in your game's Resource directory, 
and create another directory off that one which should be called Catz.

You will need also to download the Catbehaviours_c3.zip which should be
available at the same site from which you downloaded this file. It
is a large file, and you should unpack it into the root directory of
your game (where the Petz .exe file is).  Everything should automatically go 
into the correct place.  If not, you will have to shift the files by dragging
and dropping them in Windows Explorer (or My Computer).  There should be 
a subdirectory off wherever you unzipped it, called ptzfiles.  This 
subdirectory should contain another, called cat.  Inside this cat
directory, you should see 493 files with the extension .bdt.  Drag and
drop the whole thing so that the subdirectory ptzfiles is directly off
your game's root directory.  If you have already installed various of
my "external-lnz" breedz, ptzfiles will already be there; in which case
just drag and drop the cat directory into it.

That's it.  Now you're ready to download one of my Catz-based breedz for
your version of the game, and play!

Enjoy

Carolyn
