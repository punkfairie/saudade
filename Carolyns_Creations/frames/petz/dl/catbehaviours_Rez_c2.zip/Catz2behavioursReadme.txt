

These are the behaviour files for catz in the game petz II.
I am supplying this so that people who have only the dogz part of
the Petz game can play with my catz-based Oddballz-to-petz breedz.
I do not wish to convert all of the Oddballz-petz to Dogz-based breedz,
partly because, at heart, Oddballz are more like catz than dogz -- and
partly because converting them all would be a huge task.

However, I did promise some people that I would make it so that they
could play with Oddballz-petz in their dogz games.  So here is a compromise 
that I hope Dogz-games players will accept.

A note to anyone who thinks that they are getting the full catz game
with this zip; this is _not_ the case, even though the game is fooled
into thinking that the Catz part is present.  There are several things 
still missing, such as the sounds resource file, but you don't need those
items in order to play with my custom-crafted Oddballz-petz :-)

Unpack the two .dll files into the Resource directory of your Dogz II
game.  create another directory off that one which should be called
Catz.

That's it.  Now you're ready to download one of my Catz-based breedz for
your version of the game, and play!

It may be that, when you start the game, it thinks that you have Catz
installed and will ask for a serial number.  Here's one that is
available from the Ubisoft solutions site:

3116-4949-9665

Enjoy

Carolyn
