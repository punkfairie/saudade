
This is a special "mouse" for your Catz game.  It is one of the Grubz from Oddballz!

To install, move your mouse.lnz file to somewhere safe from your game's directory

PTZFILES\Mouse\RESOURCE

Now place the mouse.lnz file which is in this zipfile in that directory instead.

Open the game and choose "Restore original colours" from your game's Options menu.
Now play with your catz, put the cheese out to tempt the mouse out of its hole, and
enjoy your new grubz!

Carolyn Horn


