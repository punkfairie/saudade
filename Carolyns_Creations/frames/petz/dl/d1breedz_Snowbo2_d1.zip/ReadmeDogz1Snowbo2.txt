
For Oddballz fans who only have the original Dogz game, here is one
of the remote ancestors of our beloved Oddballz pets.  The breedz
for Dogz 1 are more primitive than the true Oddballz, just as Homo
Sapiens' simian ancestors were more primitive than 21st century Man,
but they are just as lovable and need just as much loving care as
their more modern descendants.

So, this is the Dogz 1 breed file for the Snowbo.  Put the Snowbo2.lnz 
in your game's Data directory, and place the two files sksndlst.txt and 
swsndlst.txt in your game's Sounds directory.

To adopt a brand new puppy from this breedfile, you must temporarily
remove one of the P.F.Magic breeds from the Dogz game's Data directory 
and rename the .lnz that's in this zipfile to the name of that breed.  

If you want to keep your old pet to play with at some other time, you first 
need to make sure that Brain.pbt, Brain.bak, Tricks.tdt, Dogz.ini and Saved.lnz 
are copied away from the main directory (I keep mine safe in a subdirectory
named after the breed).

If you have a version of the game that doesn't allow for activating 
the adoption kit, or you want to make work for yourself and have it like 
the day you first adopted your pet, make sure that you have the serial
number for your Dogz program handy (!!) and that Brain.pbt, Brain.bak,
Tricks.tdt, Dogz.ini and Saved.lnz are not in the main directory at all, 
and open up dogz.  Your new breed will pop up out of the door of whichever 
breed was replaced, if you tap on it. Simply adopt the dog and enter the 
serial number in the usual manner, ignoring the fact that the breed name 
is the old one.

Otherwise, go to Options and choose "Activate Adoption Kit".  The new 
pup will pop up out of the door of whichever breed was replaced, as above. 
Simply adopt the dog in the usual manner, ignoring the fact  that the breed 
name is the old one.

Close the game. Now if you want to, you can rename the pup's .lnz file 
back to the correct new breedname and put the P.F.Magic file back into the 
Data directory.  If you do this, you also have to open the  Dogz.ini  file 
into Notepad and make sure that the line which starts "Your Pet=" is changed 
to read

Your Pet=.\data\<name of breed>.lnz

where <name of breed> is of course the correct name of the puppy's breed,
or the pup will look like the P.F.Magic original when he comes out to play.

If you want it to speak, and in true "Snowbo", then you will also need 
to download the sounds, which should be available at the same site 
where you found this breedfile.  You must make a subdirectory off the 
game's Sounds directory and call it "Snow".  Put all the .wav files in 
there.

Your new Snowbo will then ho-ho-ho and generally be seasonally genial 
at you :-)

Enjoy!

Carolyn Horn

