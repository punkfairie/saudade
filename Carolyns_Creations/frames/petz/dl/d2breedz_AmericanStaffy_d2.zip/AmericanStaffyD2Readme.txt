
This is the Petz 2 version of my American Staffy breed.

Place it in your Resource\Dogz directory.  Then make a copy of your
Great DaneX.dog file in the same directory, and rename the copy 
American StaffyX.dog.

You will now be able to adopt and play with your staffyz :-)

Enjoy

Carolyn Horn