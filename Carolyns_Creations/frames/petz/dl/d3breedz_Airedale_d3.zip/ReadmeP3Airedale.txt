
Airedale Terrier breed

This is not perhaps the best Airedale; however, it's cute enough.
I made it at the request of Tom (previously of Tom's Petz), who
asked that I make a version for Petz 4 that was like the Petz 3
pet available at MPAC:
http://www.geocities.com/EnchantedForest/Tower/8004/newbreedz/new_breedz.htm
In fact I made it reasonably similar but made a few adjustments.  I felt
that the original's hind quarters looked wrong.

My Petz 4 version has now been converted to Petz 3, thanks to Sue
of the Petz Boardwalk http://petzboardwalk.bravepages.com/
So it comes full circle -- from Petz 3 pet, to Petz 4 breed, and back
to a proper Petz 3 breed :-)

This is a file which has been sound-stripped to make the download small.  
If you want your pets to have sounds, you will need the Scottie
sounds which should be available from the place from which you downloaded this file
or from my site.  When you have downloaded the sounds, if you unzip them into
the game's main directory they should all go into the correct place.

If for some reason the unzipping process doesn't place them into the following
subdirectory which it should have created off your game's main directory:

\ptzfiles\dog\sc

then you will have to create that set of subdirectories yourself, using either
My Computer or Windows Explorer.  Off the game's main directory (where the .exe
file is) create a directory and call it ptzfiles.  Off that one, create another
and call it dog.  Off that one, create another and call it sc. Place all the .wav 
files and the scsnd.txt file in that "sc" directory. Your pets will talk then.

Enjoy!

Carolyn Horn


