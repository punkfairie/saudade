
This is the Dogz 4 breed file for the Great Bearz.
Put it in your Resource\Dogz directory, and it will show
up in your Adoption Centre the next time you go there.

This version of the bear file now uses external sounds.  
Download the Great Bear sounds for Dogz II and unpack them
into your game's dogz directory.  A subdirectory called g
should thus be created, which contains the gbsnd.txt file,
and off that a directory called soun, which contains all the
wav files.  For this Petz 4 version of the breed, you need 
to move all those wav files into the "g" directory, and you
need to replace that gbsnd.txt file (which is for Petz II)
with the one that's in the zip with this breedfile.

The bear will ahve a deep growly voice even as a pup.
It will grow from a cute cuddly bear pup to a large, powerful 
bear. Don't worry, though, it is as friendly and eager to please 
as your other petz.

There are various colours of Great Bear in this breed;
just choose the one you want when it comes out of the
Adoption centre.

Enjoy!

Carolyn Horn

