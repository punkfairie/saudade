
This is a sound-stripped breed for Petz 5.  It is an original game
breedfile, just with the sounds shifted onto your hard drive so that
you can download the sounds just once (they will work with all versions
of the Petz games 3, 4 and 5) and then all the breedfile downloads will 
be small, for all versions of the games. 

This breed overwrites the original, so take care to move your original
to somewhere safe before you install this one.  You may want your original
one back one day.

If you want your pets to have sounds, you can either run your newly-adopted
pets with the original breedfile in place, or you can download the relevant 
sounds which should be available from the place from which you downloaded this file
or from my site.  When you have downloaded the sounds, if you unzip them into
the game's main directory they should all go into the correct place.

If for some reason the unzipping process doesn't place them into the following
subdirectory which it should have created off your game's main directory:

\ptzfiles\dog\jr

then you will have to create that set of subdirectories yourself, using either
My Computer or Windows Explorer.  Off the game's main directory (where the .exe
file is) create a directory and call it ptzfiles.  Off that one, create another
and call it dog.  Off that one, create another and call it jr. Place all the .wav 
files and the jrsnd.txt file in that "jr" directory. Your pets will talk then.

Enjoy!

Carolyn Horn


