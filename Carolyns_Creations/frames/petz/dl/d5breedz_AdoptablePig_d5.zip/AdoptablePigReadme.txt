
This breedfile is identical to the Petz 5 default breed except that it will show up at the Adoption Centre.  With this breedfile in place you will be able to adopt pigz and you will be able to play with the Pigz Hosts in the game, but you will probably not be able to breed them unless you use my "breedable" pig at the correct moments.

You will also probably not be able to import pigz and pigz mixes from the previous versions of the game using this breedfile; if you do have problems with that, you will have to download my "importable" version of the pig.

Enjoy!

Carolyn Horn

