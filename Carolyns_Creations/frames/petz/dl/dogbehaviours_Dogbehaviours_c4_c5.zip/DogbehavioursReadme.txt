
I did not intend to produce dogz behaviours for catz games, but I am
getting too many requests for conversions of my dogz-based breedz to catz,
so I changed my mind in order to get a little peace :-)

A note to anyone who thinks that they are getting the full dogz games
with this kit; this is _not_ the case, even though the game is fooled
into thinking that the Dogz part is present.  There are several things 
still missing, such as the sounds resource file, but you don't need those
items in order to play with my custom-crafted Dogz-based speciez :-)

These are most of the behaviour files for dogz in the games petz 4
and Petz 5. I am supplying these so that people who have only 
the catz parts of these Petz games can play with my dogz-based petz species and
fantasy breedz. I do not wish to convert all of them to Catz-based breedz,
largely because converting them all would take me too long, but I keep getting
pleading requests, so here is a compromise that I hope Catz-games players will accept.

You only need to download these behaviours once, but you will need to 
Install them into the correct place in each of the versions of the games
that you are intending to run.  Also you will need to download the small
Rez zip for the version of the game that you are playing.

How to install
--------------

If you unzipped this Dogbehaviours_c4_c5.zip into the root directory of your 
game (where the Petz .exe file is), everything should have gone into
the correct place.  If not, you will have to shift the files by dragging
and dropping them in Windows Explorer (or My Computer).  There should be 
a subdirectory off wherever you unzipped it, called ptzfiles.  This 
subdirectory should contain another, called dog.  Inside this dog
directory, you should see 445 files with the extension .bdt.  Drag and drop 
the whole thing so that the subdirectory ptzfiles is directly off your game's 
root directory.  If you have already installed various of my "external-lnz" 
breedz, ptzfiles will already be there; in which case
just drag and drop the dog directory into it.

You also need to download the relevant rez file for your game.  When you
unpack that, there will be a .dll inside as well as a readme similar to this
one. make sure that you place the Dogz Rez.dll in your game's Resource 
directory, and create another directory off that one which should be called
Dogz.

In the case of Petz 5 particularly, grab the pig breedfile from somewhere; 
I have a version at my site, but other people probably have backup copies for 
download too.  You could try Daniel Wright's Petz Archive for a true original.
If you don't have the pig in your dogz directory, it's likely that some of the
other breedz won't show up.  It's one of the many bugs in Petz 5 :-)

That's it.  Now you're ready to download one of my Dogz-based breedz for
your version of the game, and play!

Enjoy

Carolyn
