
This is a part of the behaviour files for Dogz in the game petz 3,
non-English-language version.

I did not intend to produce dogz behaviours for catz games, but I am
getting too many requests for conversions of my dogz-based breedz to catz,
so I changed my mind in order to get a little peace :-)

A note to anyone who thinks that they are getting the full dogz games
with this kit; this is _not_ the case, even though the game is fooled
into thinking that the Dogz part is present.  There are several things 
still missing, such as the sounds resource file, but you don't need those
items in order to play with my custom-crafted Dogz-based speciez :-)

How to install
--------------

You should find a .dll inside this zip as well as this readme. Make 
sure that you place the Dogz 3 Rez.dll in your game's Resource directory, 
and create another directory off that one which should be called Dogz.

You will need also to download the Dogbehaviours_d3.zip which should be
available at the same site from which you downloaded this file. It
is a large file, and you should unpack it into the root directory of
your game (where the Petz .exe file is).  Everything should automatically go 
into the correct place.  If not, you will have to shift the files by dragging
and dropping them in Windows Explorer (or My Computer).  There should be 
a subdirectory off wherever you unzipped it, called ptzfiles.  This 
subdirectory should contain another, called dog.  Inside this dog
directory, you should see 445 files with the extension .bdt, one .bhd and 
a .scp.  Drag and drop the whole thing so that the subdirectory ptzfiles is 
directly off your game's root directory.  If you have already installed various of
my "external-lnz" breedz, ptzfiles will already be there; in which case
just drag and drop the dog directory into it.

That's it.  Now you're ready to download one of my Dogz-based breedz for
your version of the game, and play!

Enjoy

Carolyn
