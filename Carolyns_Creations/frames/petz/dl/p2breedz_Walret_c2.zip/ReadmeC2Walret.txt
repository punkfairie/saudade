

This is the Walret breed for Catz II.  It uses data from the Oddballz
breed, complete with sounds.  It has had to leave behind it the 
various Transformations and emoticons that it used when it came out
of the Oddballz egg, but now at last your Walret can play with and meet 
other petz.

You cannot import your Oddballz pet directly from the Oddballz game, you will 
have to re-adopt him or her from the Adoption Centre.  But I think you
will find your pet as lovable as ever; even if it has lost its "memory",
it is still the same bouncy, friendly, emotive little thing.

The original Walret is in the Adoption Centre of course, with its
brown body-fur, black eyes, and two front eye-teeth.  But you will find a 
whole family of pets in there, with various fur colours.
Some of its family members have different fur styles and different 
coloured eyes.  Just put back whichever ones come out that you don't 
want, until the right one for you appears.

Place the Walret.cat and WalretX.cat file in your game's resource\catz directory
and Walret should come out of the Adoption Centre to greet you.

For your Walret to sound right, you will have to make sure that all its
.wav files and the wlsn.txt file are in a subdirectory off your 
resource\catz directory, called walr.  You should be able to download
the sounds from the same place from which you downloaded this breedfile.
When you've installed the sounds, replace that wlsn.txt with the one which
is in this breedfile's zip.

Enjoy!

Carolyn Horn

