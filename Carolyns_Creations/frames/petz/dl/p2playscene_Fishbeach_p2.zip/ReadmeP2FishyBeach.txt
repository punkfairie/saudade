
This is a Petz II playscene backdrop, edited from the Petz 3 beach playscene 
so as to give a fish-eye veiw of that beach.  Place it in your game's Wallpaper 
directory and choose it as you would any backdrop for your game.  It is
1024x768 pixels in size, so if you can resize your game screen to that size
it will look at its best.

I made this especially to go with my new goldfish tank toyz, but petz enjoy 
it too, especially the fishie ones!

Yes, I know that in Real Life, goldfish are supposed to be freshwater fish.  
The ones I "liberated" from the goldfish tank are ambiguous virtual types 
and can enjoy salt water :-)

Enjoy!

Carolyn Horn
