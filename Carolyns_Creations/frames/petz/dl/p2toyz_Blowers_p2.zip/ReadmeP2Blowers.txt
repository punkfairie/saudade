
This is a different-coloured Petz 2 toy for your game.  It is a
pot of exotic flowers, which attracts blue-coloured butterflies
if you put it in the playpen. Your petz will enjoy chasing the 
butterflies :-)

Put it in your Resource\Toyz directory, and it will show
up in your Toyz Cupboard the next time you go there.

Enjoy!

Carolyn Horn