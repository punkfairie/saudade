
NOTE: This _will_ overwrite your Hair Ball.toy, so make sure you have
moved the original to somewhere safe if you think you'll want it back.

Here's what dragonz cough up instead of that squishy, gross hairball.
What is it?  Why, a sapphire of course.  And if you put this in your
game instead of the Hair Ball.toy, all your catz will make you rich
with beautiful gems instead of sickened with yucky balls :-)

Enjoy!

Carolyn Horn

