
This is a Petz II toy.

The Goldfish Tank is a brand new toy for Petz II.  It brings my Goldfish
Tank from Petz 4 into your game, with the bous that the fish are free to roam 
if they want to, swimming in and out of the tank.  It's best used with my
"Fishbeach" scene background, or any other watery scene, and the fish play
well with my Fishie breed.

There isn't any fish food to go with this tank, but since the fish can roam
free they can of course pick up food from anywhere :-)

Enjoy!

Carolyn Horn