
This is a Flea-and-sickness-free Alley cat breed, for Petz 3 Non-English
versions of the game.  It should work with all other European-langage Petz 3.
This particular version of the breedfile should have Alley behaviour
also; this is tested and works on my machine.

This breed overwrites the original, so take care to move your original
to somewhere safe before you install this one.  You may want your original
one later on.

This is one of my Alley catz which have genuine Attitude but which don't 
have the excessive fleas and sickness of the original alley cat.  It contains
all the variations listed at the Petz Kennel Club, but it also a whole load of 
tail and ear variations for all those mad breeders out there :-)

In fact I intended it as an example breed for a "yet more ear and variations"
tutorial, but I can't face writing it up right now so here is the breed
itself for hexers to study.

Alleys adopted from this breedfile will have only a normal catz tendency
towards fleas or sickness, not the constant one of the original alleys.
Unfortunately, pets adopted from the original breedfile will still be
just as flea-ridden and sick whether you use this new file or not; it's
only pets adopted and bred from this breedfile which will be free of
sickness.

If you want your Alleys to have sounds, you can either run your newly-adopted
pets with the original breedfile in place, or you can download the Alley sounds
which should be available from the place from which you downloaded this file
or from my site.  When you have downloaded the sounds, make sure that the following
subdirectories have been created off your game's main directory:

\ptzfiles\cat\ac

and that all the .wav files and the acsnd.txt file are in that "ac" directory.
Your Alleys will talk correctly then.

My thanks to Sleepycat for her encouragement and help.  She provided 
the boost to get me to finish my original flealess breed and added a variation 
to it, and she encouraged me to make a version that conforms more to the 
PKC standard and has its own proper alley sounds.  She has also taken time
to test pets adopted from the flealess file to second-generation and beyond,
and has found that even with the original breedfile in place 2nd-gens from
parents which had been adopted from flealess files will also be flealess.
She has a version of the original flealess alley with improved eyes up at 
her Yahoo group http://groups.yahoo.com/group/sleepycats_petz_space/

Enjoy!

Carolyn Horn


