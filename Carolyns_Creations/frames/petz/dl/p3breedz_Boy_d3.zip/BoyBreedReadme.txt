
This "Boy" breed is intended as a partner for Jess' Girl breed which
should be available at Abnormality.
http://abnormality.purpleflowers.net/index.htm

If you want your pets to have sounds,  you can download the relevant 
sounds which should be available from the place from which you downloaded this file
or from my site.  When you have downloaded the sounds, if you unzip them into
the game's Resource directory they should all go into the correct place.

If for some reason the unzipping process doesn't place them into the following
subdirectory which it should have created off your game's main directory:

\resource\boy

then you will have to create that subdirectory yourself, using either
My Computer or Windows Explorer.  Off the game's Resource directory, create a 
directory and call it boy. Place all the .wav files and the bysnd.txt file in 
that "boy" directory. Your pets will talk then.

Enjoy!

Carolyn Horn


