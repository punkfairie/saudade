

This is the Wetterhoun breed for Dogz 3.

It was made at the request of Puk, whose selectively-bred Matty pet formed
the basis for the data in this breedfile.  It includes some variations
in colour that meet the official Standard for the Wetterhoun breed.

This version has been sound-stripped.  

If you want the Great Dane sounds for it, I shall shortly be making a
set of sound files available at my site for people to use with
all my sound-stripped breedfiles.

Enjoy!

Carolyn Horn