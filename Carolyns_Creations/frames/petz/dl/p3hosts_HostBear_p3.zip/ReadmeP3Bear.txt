
Now available for you in Petz 3, thanks to Carol (Minibyte)
who took the time and effort to convert my Petz 4 versions of 
the clothes to Petz 3.  She did a great job!

I have since added modifications to the filmstrips so that you 
can see the clothes looking as they should do in the closet.

This is the Dog Host from the Petz 4 Snow scene -- Bear!
Put Bear in your Adopted Petz folder and the .clo files,
Plaidal.bmp and Redrib.bmp in your Resource\clothes directory.  
Bear will then be ready to come out and play in any playscene, 
and his clothes will be available for all petz in the clothes
closet.

Note that Bear himself may look a little strange without his
special clothes.  He is an exact clone of the Bear Host who 
is in the Petz 4 game, so that really is the way he's supposed 
to look.

If you don't have the Dogz part of Petz 3, of course, you will
not be able to have Bear in your game, but the clothes
will work.


Enjoy!

Carolyn Horn
