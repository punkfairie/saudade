
Now available for you in Petz 3, thanks to Carol (Minibyte)
who took the time and effort to convert my Petz 4 versions of 
the clothes to Petz 3.  She did a great job!

I have since added modifications to the filmstrips so that you 
can see the clothes looking as they should do in the closet.

This is the Cat Host from the Petz 4 Snow scene -- Mitzy!
Put Mitzy in your Adopted Petz folder and the .clo files
in your Resource\clothes directory.  Mitzy will then
be ready to come out and play in any playscene, and her
clothes will be available for all petz in the clothes
closet.

Note that Mitzy herself may look a little strange without her
special clothes.  She is an exact clone of the Mitzy Host who 
is in the Petz 4 game, so that really is the way she's supposed 
to look.

If you don't have the Catz part of Petz 3, of course, you will
not be able to have Mitzy in your game, but the clothes
will work.

Enjoy!

Carolyn Horn
