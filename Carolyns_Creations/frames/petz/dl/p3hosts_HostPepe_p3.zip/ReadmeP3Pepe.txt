
Now available for you in Petz 3, thanks to Carol (Minibyte)
who took the time and effort to convert my Petz 4 versions of 
the clothes to Petz 3.  She did a great job!

I have since added modifications to the filmstrips so that you 
can see the clothes looking as they should do in the closet.

This is the Dog Host from the Petz 4 Wild West scene -- Pepe!
Put Pepe in your Adopted Petz folder and the .clo files
and Mexi03.bmp in your Resource\clothes directory.  Pepe 
will then be ready to come out and play in any playscene, 
and his clothes will be available for all petz in the clothes
closet.

My original P4 versions of the clothes were usually exact conversions 
of the  P.F.Magic Hosts' originals for other Petz to use.  P.F.Magic 
intended them only for use by Hosts, so there were some funny
little "quirks". But In the case of Bailey's clothes, there was an
interesting texture which was just not used, which seemed a shame.  
I made it so that this texture _is_ used when the shirt is worn by 
catz, but left it as an exact conversion when worn by dogz, so that
they could all pretend to be "Pepe" :-)

Note that Pepe himself may look a little strange without his
special clothes.  He is an exact clone of the Pepe Host who 
is in the Petz 4 game, so that really is the way he's supposed 
to look.

If you don't have the Dogz part of Petz 3, of course, you will
not be able to have Pepe in your game, but the clothes
will work.

Enjoy!

Carolyn Horn
