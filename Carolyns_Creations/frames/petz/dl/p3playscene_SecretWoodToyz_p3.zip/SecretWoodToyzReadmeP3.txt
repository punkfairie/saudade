
These are the toyz for the Petz 3 version of my Secret Wood playscene.

Unzip the SecretWoodToyz zipfile into your game's Resource\Toyz directory.  

This should cause a subdirectory called Birdiehouse and another one, off that one, called Sound, to be created; but if not, you will need to create by hand the Resource\Toyz\Birdiehouse\Sound directory, and place into it all five .wav files.  

The four .toy files of course should be in the Toyz directory, and they will not clash with any of the P.F.Magic original toyz.  

Although they were created specifically for this playscene, they will show up also in the toy closet.  All of them will show up in the closet with their own graphics.  As regards the dung beetle, once you've taken it off the shelf you won't be able to put it back on there.  I made it so that you can get it off the shelf because actually I like to see the little things running around in the toy room :-)

Enjoy!

Carolyn Horn

