
This is the Butterfly Attractor for Petz 3.

When you take it out of the toy closet, put it straight into your
carry-case or else it will not show up.  Butterflies never appear
in the toy-closet area anyway.  Take your Attractor out to an
outdoor scene such as the Backyard or Beach, take it out of the
case, and wait for a while.  Soon some butterflies will start to
come, although it will still look like a dull twig.  After a while,
lift it up and move it.  do this a few times until suddenly you will
see it change into a full-flowered attractor!

The flowerpot butterflies all love it; if you have the originals, and
my blooms and blowers in the game, you will have many different types
of butterflies.  Enjoy!

Carolyn