
This is a conversion of the official Petz 3 Love Potion download.
There was no version of this which would work in the non-english
version of the game so, at a special request, I made this one.
It may not be quite as potent as the one for the English-language
game, but it will still be fairly useful in getting your pets to
concentrate on each other.

I made it a couple of years ago, but have now made some slight 
improvements to it.

Enjoy!

Carolyn Horn
