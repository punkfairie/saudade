
This "Fish" breed was inspired by Laura's brilliant fish for dogz games, 
which is available at her site
http://www.geocities.com/naturenutlm/


If you want your pets to have sounds,  you can download the relevant 
sounds which should be available from the place from which you downloaded this file
or from my site.  When you have downloaded the sounds, if you unzip them into
the game's Resource directory they should all go into the correct place.

If for some reason the unzipping process doesn't place them into the following
subdirectory which it should have created off your game's main directory:

\resource\fsh

then you will have to create that subdirectory yourself, using either
My Computer or Windows Explorer.  Off the game's Resource directory, create a 
directory and call it fsh. Place all the .wav files and the fssnd.txt file in 
that "fsh" directory. Your pets will talk then.

Enjoy!

Carolyn Horn
