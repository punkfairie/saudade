
Here's a pair of wingz for your Petz 4 petz.  They show up separately
in the clothes closet; the left one shows as red on the shelf and 
the right one as blue, although the wingz themselves are white
with pastel markings.  They will work on dogz and catz, and
will re-size themselves to fit small and large alike.

Enjoy!

Carolyn Horn