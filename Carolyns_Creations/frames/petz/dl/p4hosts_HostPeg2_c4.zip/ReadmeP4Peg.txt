
It has come to my attention that in some people's games, Peg
has different-coloured wrists from the one in mine.  This version
of Peg is for people who want that other Peg :-)

She is also fully mature now, so that people whose pets have
developed a full relationship with her in their games can, I hope,
see their petz carrying on the same relationship with her without
having to wait for her to grow up.

This is the Cat Host from the Petz 4 South Seas scene -- Peg!
Put Peg in your Adopted Petz folder and the .clo files
in your Resource\clothes directory.  Peg will then
be ready to come out and play in any playscene, and her
clothes will be available for all petz in the clothes
closet.

I have now added modifications to the filmstrips so that you 
can see the clothes looking as they should do in the closet; I
have also provided an eye patch, even though Peg never takes
her own off (she obviously needs to keep it on <g>). You'll
have to do without the wooden leg, as I don't think any pet would
want to saw off their own leg to put a wooden one in place!

My Petz 4 versions of these clothes are exact conversions of the
P.F.Magic Hosts' originals, for other Petz to use.  But P.F.Magic 
intended them only for use by Hosts, so there are some funny
little "quirks" which some clothes have when worn by other pets.
In the case of Peg's clothes, Host Peg's ankles are actually the 
cuffs for her shirt, so other pets won't have any cuffs, plus 
the scarf doesn't show up when dogs wear the shirt.

Note that Peg herself looks a little strange without her
special clothes.  She is an exact clone of the Peg Host who 
is in the Petz 4 game, so that really is the way she's supposed 
to look.

If you don't have the Catz part of Petz 4, of course, you will
not be able to have Peg in your game, but the clothes
will work.

Enjoy!

Carolyn Horn


NOTE: there should be no problems running the game with
the clothes and pet from this zipfile together. However,
if you are:
a) bringing in a "host" pet which has been in
the Petz 3 game wearing its clothes, or if you are 
b) replacing previously-downloaded Host's clothes of mine 
with these, and you bring the pet from that previously-
downloaded zip into the game with these clothes in place, 
you will possibly get an error message.
Don't panic; just remove all my "host" clothes from the game's
Clothes directory, re-open the game and bring the pet out.
It won't have any clothes on but it won't crash the game.
Now you can put the clothes back into the clothes directory
and put them back onto the pet.
