This is the Petz 4 version of this toy.

The Blooms are a variation of the original white potted flowers.  Just put
them in your game's Toyz directory, and they will show up separately on the shelf.

They are a separate toy, with pale blue flowers and red-tinted butterflies,
and they show up on the toy shelf with their own red pot.

You can have my Blooms and the original flowers blooming in your game together,
and your catz and dogz will enjoy chasing all the butterfiles.

Enjoy!

Carolyn Horn