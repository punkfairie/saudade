
This is a brand-new Petz 4 toy for your game.  It is a
bag of carrots for those of you with vegetarian petz :-)
They will enjoy eating these treats and will perform tricks 
to get them, in the same way as for other treats in your game.

Put it in your Resource\Toyz directory, and it will show
up in your Toy Cupboard the next time you go there.

Enjoy!

Carolyn Horn

