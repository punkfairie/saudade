
This is a Petz 4 toy.

The Goldfish Bowl will overwrite the one that's already in your game.  Make sure
that you have the original moved somewhere safe in case you want the poor fish
to go back into it.

I made this because that bowl seemed just plain cruel, with nothing in it for the 
fish to play in or hide  around.  _Not_ a good way to teach people how to look after 
animals!

Your little fish can now play around in an interesting environment; he has all the
fun of the circus in his "tank".  The glass and water in of this tank are so clean
that you cant see them, so he's a healthy little fish too :-)

You can still feed these little fishes; just hold the food at the centre of the circus.

If you'd rather give your fish a better freedom and chance to play with others of
his kind, download my other version and take a bunch of those "fishbowls" to my
Fishy playscene at the beach...  Yes, I know that in Real Life, goldfish are supposed 
to be freshwater fish.  These ones of mine are sometimes saltwater varieties of fish :-)

Enjoy!

Carolyn Horn