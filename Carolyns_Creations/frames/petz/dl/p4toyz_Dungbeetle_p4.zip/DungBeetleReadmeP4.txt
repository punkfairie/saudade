
Here is the Dung Beetle toy for Petz 4.

Although this was created specifically for my Secret Wood playscene, 
it will show up also in the toy closet.  Once you've taken 
the Dung Beetle off the shelf you won't be able to put it 
back on there.  I made it so that you can get it off the 
shelf because actually I like to see the little things 
running around in the toy room :-)

Enjoy!

Carolyn Horn

