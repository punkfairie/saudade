
This is the Arthropodz breed for Catz 4.  The butterfly idea
was inspired by Smarti's wonderful butterflies for Dogz; you
can get those from Dome Kua.   
http://www.rainypony.net/dkp/
Go there, they are beautiful and varied wee butterflies, and
the first ever ones for Petz games!

Meanwhile, you can adopt butterflies, winged insects, and spiders
from this Arthropodz breedfile.  They will breed together
without difficulty and produce some interesting babies.  Petz
is one place where the butterfly and spider can play together
without danger :-)

SOUNDS:
=======

Also included in this zipfile you should find two .txt files, one
of which is called spdsn.txt and goes in a subdirectory called spdr
off your catz directory, and the other of which is called bfsnx.txt
and goes in a subdirectory off your catz directory called bfly.

These are for sounds.  you may want your pets to sound like flying 
insects and spiders.  If so, download the "butterfly" sounds _and_ 
the "spider" sounds which should be available a the site from which
you got this breedfile or from my site.  If you only get the 
butterfly sounds, the spiders will be mute and if you only get the 
spider sounds, the flying insects will be mute.

When you've downloaded them, the spider sounds go in the spdr 
directory and the butterfly ones go in the bfly directory.

Enjoy!

Carolyn Horn