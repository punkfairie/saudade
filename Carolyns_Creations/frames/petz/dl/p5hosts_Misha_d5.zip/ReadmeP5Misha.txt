
This is the Dog Host from the Petz 5 Circus scene -- Misha!

Note that Misha himself may look a little strange without his
special clothes.  He is an exact clone of the Misha Host who 
is in the game, so that really is the way he's supposed 
to look.

These Host petz that I've given to you are the Hosts, exactly as 
they were made by the game's creators.  They were of course never 
intended to have a "normal" petz life in the game, without their 
special clothes.  I wanted you to have the _real_ Hosts, so I made no 
changes.  If you don't like Bear's back legs, or Wyatt's ears and 
wrists, or the way Peg and Pharaoh look, then I suggest that you either
adopt a different pet instead or always keep their proper clothes on.

Enjoy!

Carolyn Horn

