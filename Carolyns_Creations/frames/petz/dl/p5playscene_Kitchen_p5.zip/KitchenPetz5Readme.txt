
This is a version of the Petz 5 kitchen which has the Petz 4
backdrop, for those of us who prefer the look and colours of
the earlier game.  The fridge and cupboard doors will look
a little strange when you open them, because Studio Mythos
made the shapes a little different, but everything still works
as it should. 

There has been some interest in this from downloaders and people 
who want to edit the backdrops in their own game, so I've 
updated it to have a "night" version of the scene even though
Petz 4 didn't have that, and I've got a note here as to how to
do it yourself.  Don't forget to keep backup copies of the
original scene before you start editing, though!

This will overwrite your game's original kitchen, so make sure
that you keep the original somewhere safe when you put this into
the game's Resource\Area directory.

Okay, for hexers:

If you want to change your backdrops in Petz 5 original scenes,
either use ResHacker to change them (I don't supply ResHacker
tutorials, sorry) or use your hex editor as I did with this scene.
If you're using a hex editor, you need to locate the two big 
bitmaps.  There is another bitmap, a small one, which is the icon;
of course you can change that also.  Search for the uppercase 
letters BM and you should be taken to the first bitmap, which is
directly below the scene's ID number.  If you don't know what I'm
talking about, please read one of my basic hexing tutorials.
Each backdrop is 2,359,352 bytes long (hexadecimal 240038), so if 
you copy your own over it in a hex editor, make sure that you don't 
make yours any bigger than 2,359,352.  You can make it smaller of
course, and fill out the remainder of the bitmap space with null 
bytes.  The icons vary in size in different scenes, so you're going 
to have to be careful in finding the start of the backdrop, but
the backdrops are all the same size.

Some scenes have no "night" backdrop, such as the Haunted Mansion,
which also happens to have the backdrop _before_ the icon, so if
you're editing that one you need to be aware of that. Arabia also 
has the icon after the backdrops. And some scenes have a third 
backdrop, such as the Salon and South Seas which have a different 
one also for a rainy day.  The Adoption Centre has a rainy day one; 
it also, curiously, has an old Petz 4 one tucked away in there which 
is in 256 colour and 787,510 (hex C0436) bytes long after the icon.

A list of which scenes have the icons after the backdrops, the size 
of the icons in hexadecimal, and in which order they have their 
bitmaps:

Fantasy Castle: backdrop, night back, icon size hex 06F8
Wild West: Icon size 07A2, backdrop, night back
Snowscene: Icon size 06F2, backdrop, night back
South Seas: Icon size 06F0, backdrop, night back, rainy back
Haunted Mansion: backdrop, Icon size 06F8
Nursery: Icon size 06F8, backdrop, night back
Salon: Icon size 06F8, backdrop, night back, rainy back
Adoption Centre: backdrop, night back, rainy back, Icon size 06F0, oldadopioncentre
Backyard: backdrop, night back, rainy back, icon size 06F0
Beach: backdrop, night back, rainy back, icon size 06F0
Family Room: backdrop, night back, rainy back, icon size 06F0
Arabia: backdrop, night back, icon size 06F0
Asian Temple: backdrop, night back, rainy back, icon size 06F8
Circus: backdrop, night back, icon size 06F2
Kitchen: Icon size 06F0, backdrop, night back


Enjoy

Carolyn Horn

