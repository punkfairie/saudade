
This is the Petz 5 version of my Secret Wood playscene.

This scene comes with extra sounds and toyz.  In order to enjoy 
it as it was intended, you need to download and install all these 
items, so please read the "readme" files very carefully.

The scene is based on the huge central stone lion.  This is one of 
the giant granite sculptures created by Scottish sculptor Ronald Rae.  
He carved it, using hand tools similar to those used by the ancient 
Egyptians, out of a 20-ton granite block.  You can see pictures of 
his works, and information about him, at his site
http://www.ronaldrae.co.uk/

Place the Secret Wood.env file in your game's Resource\Area directory.  

If you have downloaded the sounds also, make sure that the env_roundabtloop.wav 
file is in the correct subdirectory.  If you unzip  the SecretWoodSounds.zip 
into your game's area directory, it should go automatically into the right 
place, but if not, you will need to make sure to create a subdirectory, 
off your Resource\Area directory, called SecretWood, and then another 
one off this subdirectory, called NewSounds.  The env_roundabtloop.wav, 
therefore, should end up in Resource\Area\SecretWood\NewSounds

If you have downloaded the toyz also, unzip the SecretWoodToyz zipfile 
into your game's Resource\Toyz directory.  This should cause a subdirectory 
called Birdiehouse and another one, off that one, called Sound, to be 
created; but if not, you will need to create by hand the 
Resource\Toyz\Birdiehouse\Sound directory, and place into it all 
five .wav files.  The four .toy files of course should be in the 
Toyz directory, and they will not clash with any of the original toyz. 
Although they were created specifically for this playscene, they will 
show up also in the toy closet if you use Tinker's File, Modify Carrying Case
feature (Tinker is downloadable from my Nicholas Tools pages).  Don't
add the Dung Beetle to your carrying case, though, because if you take
it out again it will crash the game.  Leave it where it's meant to be --
in the Secret Wood scene :-)

Note -- if you install the scene and play with it before installing the toyz,
they won't show up in the scene until you re-set the registry by holding
down the Ctrl and Shift keys.

If you want my carry-case also, it's downloadable from my Petz 5 Skinz
page, or you can get another version from Daniel Wright's Odd-petz site.

Enjoy!

Carolyn Horn

