
The included zipfile contains the birdsounds for the Adoption Centre
and Family Room easy-edit kits, also the window and fire sounds for the
Family Room one.  Unpack it into the root directory of your game (where 
the Petz .exe file is).  Everything should automatically go into the 
correct place.  If not, you will have to shift the files by dragging
and dropping them in Windows Explorer (or My Computer).  There should be 
a subdirectory off wherever you unzipped it, called art.  This 
subdirectory should contain another, called sprites.  This 
sprites subdirectory should contain another, called Sounds. This 
Area subdirectory should contain a bunch of wav files.

Drag and drop the whole nest of directories so that the subdirectory "art"
is directly off your game's root directory.  Since you will probably have 
already installed various of my "external-lnz" scenes, art\sprites
will already be there; in which case just drag and drop the Sounds directory 
into it.


Enjoy

Carolyn
