
This is the Petz II demo "fooler"; follow these instructions and
you should be able to play properly with Catz II and Dogz II petz.
You won't have all the sounds, but the game will work.  If XP
users follow the extra instructions for them, it should even work
for you.

First of all, download the demo for Petz II.  Either download the
Dogz II demo and Catz II demo files from a place such as Daniel Wright's 
petz sites http://www.petz.ws/ or, if you've got an unsupported
Operating System such as ME or win 2000 or XP, grab my PetzIIdemo 
zipfile. Mine is the two demo files which have simply been unpacked 
and installed and then zipped up.

Install the ones from Daniel's site or unpack the one from mine.
If you've downloaded mine, it will have created the directory PetzII
and the Petz II.exe will be in there with a directory called Resource
off that one.  Run Petz II.exe to check that it works.  Even if you
have Windows XP, this should work for you also.

Now download my "Catz in dogz II" and "Dogz in catz II" files and
install them.  

Place the two .dll files that are in this PetzIIdemoFooler.zip 
file into the game's Resource directory.

Download a bunch of Petz II breedfiles.  I strongly recommend you
to download the original breedfiles, and if you have Windows XP please 
at least grab the backup breedz for Siamese and Great Dane or my fix 
won't work for you.  Install the breedz.  If you've downloaded them
from my fooler page, unzip them into the game's catz and dogz folders.

Start the game.  You should get through to the point where it asks
for serial numbers.  You can get serial numbers from the UbiSoft
site, but here are the two that I use:

For Dogz II, 211239479588
For Catz II, 311649499665

If you are running Windows XP, exit when you get through to the
Adoption Centre.  Everyone else should be able to go ahead and
adopt a pet of your choice.

If you want the screensaver also, move the .scr file which is in my
demo zipfile into your Windows or System directory.

For Windows XP, please put the two pets that are in this zip into
the game's Adopted Petz folder.  Now double-click on the little .reg
file which is also included in this zip.  Open the game; a Siamese
cat and a Great Dane dog will come out of the door and play with you.
XP users, don't put away the pets and try to bring them out or the
game will crash.  If you want petz which look different from these 
in the game, download the breedfile of your choice and rename the
files to either Great Dane.dog and Great DaneX.dog (in the case of a
dog breed) or Siamese.cat and SiameseX.cat (in the case of a cat breed),
put them into the Catz or Dogz directory instead of the originals,
and see how your pet has changed shape when it comes out of the door :-)

Enjoy

Carolyn Horn



