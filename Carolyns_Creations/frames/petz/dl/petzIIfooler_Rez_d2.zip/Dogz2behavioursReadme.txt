

These are the behaviour files for dogz in the game petz II.

I did not intend to produce dogz behaviours for catz games, but I am
getting too many requests for conversions of my dogz-based breedz to catz,
so I changed my mind in order to get a little peace :-)

A note to anyone who thinks that they are getting the full dogz games
with this kit; this is _not_ the case, even though the game is fooled
into thinking that the Dogz part is present.  There are several things 
still missing, such as the sounds resource file, but you don't need those
items in order to play with my custom-crafted Dogz-based speciez :-)

Unpack the two .dll files into the Resource directory of your Catz II
game.  Create another directory off that one which should be called
Dogz.

That's it.  Now you're ready to download one of my Dogz-based breedz for
your version of the game, and play!

It may be that, when you start the game, it thinks that you have Dogz
installed and will ask for a serial number.  Here's one that is
available from the Ubisoft solutions site:

2112-3947-9588

Enjoy

Carolyn
