
This file is intended for the use of hexers and anyone who wants to
change their Petz 3 Kitchen.

This Kitchen.env file for Petz 3 will overwrite your game's original, and unless
you put everything in the correct place it _will_ crash your game, so please
please please make sure that you have your original safe somewhere and copies of
all your petz somewhere safe.

Place the Kitchen.env in your game's resource\Area directory.

Now unpack the included zipfile, called KitchenFilesP3.zip, into your game's
main directory (the directory which contains the Petz 3.exe file)

The unzipping process _should_ create a set of subdirectories with the needed files in

\art\Sprites\Area\Kitchen

What you should get are a bunch of .flm and .flh files -- these are the filmstrip
and filmstrip-info for the game.  You can edit them using Tinker, available
from my "Nicholas' Tools" page, or if you're a masochist you can do it the
old way, manually splitting and headering the frames.

Also in there are the  icon and the backdrop bitmaps.  These are simple
bitmaps and you can change these to whatever you wish in a paint program.

The text files can be changed too of course; the "bevent" one is just the on-screen
tip for the scene and the others are sounds lists.  Nothing to stop you from redirecting
them to a directory on your hard drive and putting wavs into that directory if you want
different noises in your scene

Have fun giving your petz nice new kitchens!


Cheers

Carolyn Horn


