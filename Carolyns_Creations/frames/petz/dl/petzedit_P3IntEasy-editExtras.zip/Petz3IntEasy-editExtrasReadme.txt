
This zipfile contains the special files that you need, along with the 
"Easy-edit Case, AC door, and mice etc for petz 3", to enable players of 
non-English Petz 3 to customise your game's carrycase and its door, 
the Adoption Centre doors, and the mice.

First, make sure that you have moved your game's Petz 3 Rez.dll to a safe place.

Please download the full "Easy-edit Case, AC door, and mice etc for petz 3"
file and install it as per the instructions.

Now unpack this "extras" zipfile into your game's main directory (where
the Petz 3.exe file is).  This should place the two included bitmap files
into the correct place.  If it doesn't, find wherever on your hard drive
the two files ICON_BEENDEN.BMP and ICON_LAUFSTALL.BMP were unpacked to,
and move them into the game's directory

\art\sprites\Area

Now place the version of the Petz 3 Rez.dll which is in this zipfile into
your game's Resource directory.  When you start the game, it should run as
normal, and you will be able to edit the appearance of your game in the
same way as players of the English-language easy-edit version :-)

Enjoy!

Carolyn Horn