
This set of Babyz sounds is made available for people who wish to make
"Baby" breedz for petz games.  The sounds .txt files are optimised for
breedz based on the Sheepdog (a nice soft cuddlesome breed of dogz) or 
the Alley Cat (not in the least soft and cuddlesome but I like them).

Unpack the zipfile directly into your game's Resource directory, and you
should then find that a new directory has been created, called babyz, which
contains a load of .wav files and two .txt files bbzsnd.txt and bbzcsnd.txt

For those who wish to edit them, bbzsnd.txt is the sounds text for dogz, and
bbzcsnd.txt is the one for catz.

If you want to hear the sounds in your game, you can do this by changing the
sounds pointer in your Sheepdog .LNZ thusly:

[Sounds]
\resource\babyz\bbzsnd.txt

and in your Alley Cat .LNZ thusly:

[Sounds]
\resource\babyz\bbzcsnd.txt

Enjoy.

Carolyn Horn

