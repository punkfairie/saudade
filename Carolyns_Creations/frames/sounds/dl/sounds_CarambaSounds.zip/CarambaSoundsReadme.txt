
This zipfile contains the sound files for my Caramba! breed.
Create a subdirectory off the Eggz\Caramba! directory and call it Soundsss.

Put all the .wav files into this subdirectory, and your Caramba!
will find its voice.

Enjoy!

Carolyn Horn

