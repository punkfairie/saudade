
These are the sound files for the Chickenz.

Make a subdirectory off your Resource\catz directory, and call it chk.

Place all the .wav files, and chksn.txt, into this subdirectory.

Next time you bring out your Chickenz, they should talk to you.

Enjoy!

Carolyn Horn