
This zipfile contains the sound files for my Deardear breed.
Create a subdirectory off the Eggz\Deardear directory and call it Soundsss.

Put all the .wav files into this subdirectory, and your Deardear
will find its voice.

The Deardear has a certain amount in common with its cousin, the Zott,
but you will find that it has its own individual needs, its own speech
patterns, and has a few surprises hidden inside.

Enjoy!

Carolyn Horn

