
These are the sound files for the Guineapigs.

Make a subdirectory off your Resource\dogz directory, and call it gpig.

Place all the .wav files, and gpigsnd.txt from the breedfile archive, into this subdirectory.

Next time you bring out your Guineapigz, they should talk to you.

Enjoy!

Carolyn Horn