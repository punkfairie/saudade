
These are the sound files for the Catz 3 and 4 Pegasicorn.

Make a subdirectory off your Resource\catz directory, and call it up.

Place all the .wav files and upsn.txt into this subdirectory.

Next time you bring out your Pegasicornz, they should talk to you.

Enjoy!

Carolyn Horn