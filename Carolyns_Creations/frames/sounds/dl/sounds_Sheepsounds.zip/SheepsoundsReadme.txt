
These sheep sounds were made by me at the request of Barnett Landing's
Kathy, way back when she made her sheep breed, in August 2000.  

They are my own work; I am making them available at my own site now because 
I intend to release a "sheep" for catz games, as part of my Oddballz-in-petz series 
-- some of the Oddballz breedz have a sheep as a Transformation, you see.

When you download the sheep-sounds version of my Sheepoddz breed, please
follow the instructions that come with the breedfile if you want these sounds
to work.

Enjoy!

Carolyn Horn