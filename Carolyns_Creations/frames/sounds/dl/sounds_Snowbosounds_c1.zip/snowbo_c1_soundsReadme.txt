
These sounds all go into your game's Sounds directory.
They will overwrite your game's originals, so be sure to put
those somewhere safe!

Enjoy

Carolyn