
These are the sound files for the Catz breedz Unicorn.

Make a subdirectory off your Resource\catz directory, and call it un.

Place all the .wav files and unsn.txt into this subdirectory.

Next time you bring out your Unicornz, they should talk to you.

Enjoy!

Carolyn Horn