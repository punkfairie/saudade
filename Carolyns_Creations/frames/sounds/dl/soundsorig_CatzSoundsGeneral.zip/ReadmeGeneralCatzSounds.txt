
This contains the General Catz Sounds zipfile which you will need
if you do not have the Catz part of your petz game and you want 
to hear all the sounds in "cat" dogz breedz (such as Vickie's 
PersianDog.dog).  It also contains four small zipfiles, each
of which contains a .dll file.

NOTE you do not need this at all if you already have the catz
part of the game complete.

Choose the .dll zip which fits your game (the catz 3 one for Petz 3,
Catz 4 one for Petz 4, Catz 5 one for Petz 5).  Unpack it into
your game's Resource directory.

Now unpack the General Catz Sounds zipfile into your game's main directory
(typically C:\Program Files\PF.Magic\Petz 4)

It should place a whole load of .wav files into a subdirectory,
off your game's main directory, called ptzfiles.  They should unpack
complete with their own subdirectories, which should be:

\ptzfiles\cat\sharedsnd\all
\ptzfiles\cat\sharedsnd\kitten
\ptzfiles\cat\Mouse\Sounds

Enjoy

Carolyn Horn