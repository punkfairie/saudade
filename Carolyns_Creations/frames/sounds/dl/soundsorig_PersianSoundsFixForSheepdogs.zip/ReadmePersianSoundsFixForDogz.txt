
This is a fix which allows you to have sheepdog-based breedz use
the persian cat external sounds.  You should already have downloaded
the Persian sounds zipfile and installed the contents.  Now
place the prsnx.txt from this zip into your ptzfiles\cat\pr
directory.

If you do not have the Catz part of your petz game and you want
to hear all of the sounds in your Sheepdog Persian, download
also my General Cat Sounds zipfile and install the contents.

Enjoy

Carolyn Horn