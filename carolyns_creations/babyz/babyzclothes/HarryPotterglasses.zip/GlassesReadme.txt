
These are my "Harry Potter" glasses for Babyz.  They are as close as I could get to the Potter shape, anyway :-)

They will show up separately on the clothes closet shelf.

Enjoy

Carolyn Horn
