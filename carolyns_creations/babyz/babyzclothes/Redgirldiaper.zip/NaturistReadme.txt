
This is one of my special naturist "diaper" skins for your babyz.  All these special skins will show up separately on the diaper-shelf, in a colour as close to that of the baby it's supposed to belong to as I can get.  In the case of the furry babyz (my monkey or ape-type babyz), the on-shelf colour is approximate owing to the lack of on-shelf fur-texture, but in the case of the other babyz it should look identical.

You will find that the original tails supplied by P.F.Magic, in the main clothes closet, will disappear if you try to place them on a baby which is wearing one of these skins.  If you want to use tails, either use my special monkey-tails from the diaper shelf or use one of my specially-altered P.F.M originals, downloadable from various sites including ABC.

Enjoy

Carolyn Horn
