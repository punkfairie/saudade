
This is the dark tail for your monkey babyz.

It will show up separately on your Diaper-shelf and will look like a diaper until it is on the baby.  Place it on your baby _before_ you try putting the appropriate monkey-fur diaper on.  If you put it on after one of my special Naturist baby or monkey-creature diapers, it will seem to disappear.  Do not panic -- just put the baby back on the changing-table and click on it until the tail re-appears in your hand.

Enjoy

Carolyn Horn
