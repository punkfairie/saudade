
NOTE:
These are tails which overwrite the P.F.Magic originals --
so make sure that you move the originals to somewhere safe first!

These tails are for the P.F.Magic game Babyz and are designed 
specifically to be usable with any babyz that are wearing my "naturist" 
nappies (diapers), or for those few which I have created with no diapers at all.  
The default originals disappear when placed on those babyz.  If you have this 
problem, just close the game, replace the original nappy with the relevant one 
from this pack, and open the game again.  You will then see the tail.

Enjoy

Carolyn Horn


