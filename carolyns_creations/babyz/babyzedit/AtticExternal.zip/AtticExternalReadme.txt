
This file is intended for the use of hexers and anyone who wants to
change their Babyz Attic.

This Attic.env file for Babyz will overwrite your game's original, and unless
you put everything in the correct place it _will_ crash your game, so please
please please make sure that you have your original safe somewhere and copies of
all your babyz somewhere safe.

Place the Attic.env in your game's resource\Area directory.

Now unpack the included zipfile, called AtticFilmstripsEtc, into your game's
main directory (the directory which contains the babyz.exe file)

The unzipping process _should_ create a set of subdirectories like the
ones shown in the included AtticfilesWhere.jpg picture, with the needed files in

\art\Sprites\Area\Attic

If the unzipping process did not do that, then you will have to create the
directories manually, using Windows Explorer or My Computer, and place the files
in there.

What you should get are a load of .flm and .flh files -- these are the filmstrips
and filmstrip-info for the game.

A Sounds directory should be there as well, off the Attic one, containing the
.wav files for the scene.  You can edit these of course, but keep the names the same.

Also in the Attic directory are the Attic icon and the Attic backdrop.  These are 
simple bitmaps and you can change these to whatever you wish in a paint program.
The Window and closet filmstrips will still be in the same places; they will 
look the same.

So, also included in the zip, are ATTIC_CLOSETFLM1.bmp, ATTIC_CLOSETFLM2.bmp,
closetbuttonsflm1.bmp, closetbuttonsflm2.bmp, and ATTIC_WINDOWFLM.bmp. These are the
filmstrips, prepared by me with bitmap headers so that you can edit them.  If you 
want to change the window or closet to something that looks different, take care to 
put the new items in the same place as before in the backdrop, then edit these .bmp 
files of mine in your favourite paint package.  When you've finished editing and saving 
these open them into a hex editor and strip off the bitmap headers.  What needs to be 
removed is the first 1078 bytes of each .bmp file.  Save.  Then you will need to stick together
the two ATTIC_CLOSETFLM bitmaps and the two closetbuttonsflm bitmaps; do this by opening
the first of the closet ones, ATTIC_CLOSETFLM1, in your hex editor.  Put the cursor at
the end.  Now open the second one, ATTIC_CLOSETFLM2, in the hex editor and select the
whole of it, and choose Copy.  Now go back to the first one and choose Paste.  Save.
Stick the two closetbuttonsflm bitmaps together in the same way.

Finally, rename them to ATTIC_CLOSET.FLM, ATTIC_CLOSET_BUTTONS.FLM, and ATTIC_WINDOW.FLM.  
You'll have to remove or rename the originals first of course.

Have fun giving your babyz nice new attics!

Cheers

Carolyn Horn


