
This is a little "kit" which I hope will help you to make your
own Toy chests.  It overwrites the Frog.chest.  In order to have the
fullest easy-edit facilities, you should download two zips; one is
that which contains this readme and is the chest with external files.
People who understand how to chop and strip the filmstrips, or are 
able to download and understand my tutorials on doing that, don't need
anything else; the kit is "easy-edit" because you don't need to fool
around with the Frog.chest file if you don't want to because all
filmstrips, sounds and texts are external.

The second zip contains the filmstrips split up for your convenience,
with bitmap header info and an explanation for those who are not familiar
with filmstrips.

There is a third zipfile, which contains the filmstrip sections already
provided with their correct bitmap headers.  This is for people who don't
give a toss as to how to do it themselves, but want me to do everything
for them.  Well, I can't do _everything_, you're going to have to strip
off the headers yourself after editing the pics and then stitch 'em together,
but that's the best I can do for you anyway :-)

How to use this first package
=============================

Unpack this BabyzFrogChestEasy-edit.zip file into the root directory of your 
babyz game -- where the babyz.exe is -- and it should put all the files except 
for the frog.chest itself into the correct places.  The frog.chest will
overwrite the one in your game's ToyChestz directory, so move the original
to somewhere safe before moving the one from this zipfile in there.
The rest of the files should have ended up here, off your main babyz dir:

\art\Sprites\Toychestz\Frog

with the wav files in here:

\art\Sprites\Toychestz\Frog\Sounds

If they aren't there, then you will have to create the subdirectories, 
using My Computer or Windows Explorer, find where the files were placed 
on your hard drive, and place the files in those directories.

First off, remember to always, always keep a safe copy of any file that
you are going to edit.  Also always keep safe copies of your precious
.baby files; you should do that even if you are not going to edit anything,
as the game can corrupt them.

The Toychest is made up mostly of filmstrips.  If you are just replacing 
your chest, all you need to do is to edit those filmstrips and, if you
wish, give it new sounds.

If you're making an extra toychest, you will need to rename the chest 
and give it a unique ID number so that it will show up separately
in the "choose a toychest" dialogue. For an explanation of ID numbers, 
look at my howto on Un-hiding and giving shelf graphics to difficult toyz.  
Re-naming the toychest is simple, especially if you keep the name the 
same length as the original.  Take a look at my tutorial on hexing 
babyz clothes, I explain there how to rename a file.  One thing to
note with a Toychest, however, is that the ID number can be tricky
to find; it's sandwiched between two copies of the thumbnail bitmap.
I attach a screengrab of where you can find it in the Frog toychest.
If you want to change the thumbnail, you will have to either use a
hex editor to change the bitmap which is above the ID number -- it
is lacking the first 14 bytes of the header, which you might find a
bit tricky to deal with, but if you save out the second of the two
bitmaps and edit it, you can copy/paste it (minus the first 14 bytes)
over the first one.

00035040 4E00 3400 0900 4600 5200 4F00 4700 4F00 N.4...F.R.O.G.O.
00035056 5000 4500 4E00 3500 0000 0000 0000 0000 P.E.N.5.........
00035072 2800 0000 7000 0000 6000 0000 0100 1800 (...p...`....... <--first one starts with (...p
00035088 0000 0000 007E 0000 120B 0000 120B 0000 .....~..........
00035104 0000 0000 0000 0000 FFFF FFFF FFFF FFFF ................


00067344 FFFF FFFF FFFF FFFF FFFF FFFF FFFF FFFF ................     and ends with
00067360 FFFF FFFF FFFF FFFF 0100 0000 546F 7963 ............Toyc <-- the last FFFF here
00067376 6865 7374 7A5F 4672 6F67 0000 0000 0000 hestz_Frog......
00067392 0000 0000 0000 0000 0000 0000 4672 6F67 ............Frog
00067408 0000 0000 0000 0000 0000 0000 0000 0000 ................
00067424 0000 0000 0000 0000 0000 0000 204E 0000 ............ N..
00067440 0300 0000 0000 0000 424D 367E 0000 0000 ........BM6~.... <-- 2nd one starts with BM
00067456 0000 3600 0000 2800 0000 7000 0000 6000 ..6...(...p...`.


00099728 FFFF FFFF FFFF FFFF FFFF FFFF FFFF FFFF ................     and ends with
00099744 FFFF FFFF FFFF FFFF FFFF FFFF FFFF 0000 ................ <-- the last FFFF here
00099760 6500 0000 2C00 B000 E800 0000 CF00 1701 e...,...........
00099776 7D01 CB01 0000 0000 5802 5802 4472 6F70 }.......X.X.Drop

Or you can use Resource Hacker to replace it.

The BabyzFrogChestFilmstripSections.zip contains five sections to which
you will need to add the bitmap headers properly before editing.  It's not 
as hard as you may think. I include a bitmap header in the zip, also a 
screengrab of the header, as seen in a hex editor, with the bytes that
will need to be changed highlighted in red.  I include a readme in that
zip which should help.

For those who don't really want to understand filmstrips but just want to
make lots of toychests from the frog one, The BabyzFrogChestFilmstripBitmaps.zip 
contains all five sections already fixed up so that you can edit them
in a paint package.  What you will need to do after that is to strip
off the headers and stitch the sections together in a hex editor.  I
include a readme in that zip which explains more clearly.

Save.  Run the game.  Gasp in delight at your very own Toy Chest in the game!


Enjoy!

Carolyn Horn

