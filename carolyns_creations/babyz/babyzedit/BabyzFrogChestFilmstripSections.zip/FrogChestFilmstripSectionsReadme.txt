
This is part of a little "kit" which I hope will help you to make your
own Toy chests.  It overwrites the Frog.chest.  In order to have the
fullest easy-edit facilities, you should download two zips; one is
the chest with external files. People who understand how to chop and 
strip the filmstrips don't need anything else.

The second zip is the one with this readme; it contains the filmstrips 
split up for your convenience, with bitmap header info and an explanation 
for those who are not familiar with filmstrips.

There is a third zipfile, which contains the filmstrip sections already
provided with their correct bitmap headers.  This is for people who don't
give a toss as to how to do it themselves, but want me to do everything
for them.  Well, I can't do _everything_, you're going to have to strip
off the headers yourself after editing the pics and then stitch 'em together,
but that's the best I can do for you anyway :-)

How to use this second package
=============================

This zipfile contains the five sections of the filmstrip for the Babyz frog
toychest.  It also includes a basic bitmap header.  Open each of the filmstrip
sections in your hex editor, also the bitmap header, which you should copy/paste 
onto the beginning of each filmstrip section.  Save them as

frogflm1.bmp, frogflm2.bmp, frogflm3.bmp, frogflm4.bmp, frogflm5.bmp

Now you need to do a bit of work on the headers.  Look at BitmapHeaderCorrect.gif
-- this shows, highlighted in red, the numbers that had to be changed to make
the header on frogflm5.bmp correct.  Now look at FrogFilmstripSizesInfo.jpg
and Don't Panic.  This is all the sections shown in Axe, in graphic mode, with
the complete section of each selected.  Check out the top one, frogflm5.
See the grey bar at the bottom of that bit -- where there are red, green and
blue buttons?  Look along to where it says 

Sel: 0x00000000 - 0x0010eb40  and then Row: 0xb0

Right, the first is the amount selected (in this case the whole of frogflm5.
The only bit that matters is the end bit of it, 10eb40.  The second is the
number of rows.  Now...  In the BitmapHeaderCorrect.gif, see where there is
40EB10 in red?  That's the "selected" part shown above, 10EB40, backwards.  
Don't ask why, just accept the fact that you need to enter these numbers 
backwards, okay?  And then see where there is B0 in red.  That's the place
in the bitmap header where you need to enter the number of rows.

A bit more work to do here.  This is of course why so few toyz are made...
Look at SelectWholeBitmap.gif.  For this, we are finding out the size of the
bitmap including header, and so we select the whole data inside the file, and
you can see on the bottom, grey, bar this: Sel: 10ef76 bytes.  You need to
enter this, backwards, into the top line of the bitmap header, where you see
I have in red 76EF10.

The final thing to do is to calculate the height of the filmstrip.  So, open your
Windows calculator and make sure it's set to "scientific", and tick the hex
radio button.  Go back to the data we got from Axe, and enter from that info
10EB40, then the "divide" sign, and then B0, then hit the equals sign.  This
gives us the total number of bytes in the filmstrip section, divided by the width
in rows.  See Calculateheight.gif; the answer, 189C, needs to be entered -- 
backwards -- into the final part of the header where I have numbers in red (9C18).

I hope this helps you to see how it works, and enables you to put headers on
the rest -- as well as, in future, strip and edit your own filmstrips from other
toyz etc.

Once you've got all your filmstrip sections prepared with their headers,
open them into your favourite paint package and edit them to your 
heart's content.  If your work is going to look good, you need to keep
your pictures so that they fit into each frame of the filmstrip.  The
pink part is see-through to the game; there's nothing to stop you from
filling up the whole of that see-through background if you wish.  A
simple rectangle of a "chest" can be made by simply flooding the whole 
of each of the four strips with a single colour.  Or you could make an
"invisible" chest by filling the whole set with the background colour,
but that would make an extremely frustrating "chest" -- and yes, I did
try it at first on my "gone" chest before I changed it to a gunk one :-)

When you've finished editing, open frogflm1.bmp into a hex editor
and go to the end of the bitmap header.  Look at headerstrip.gif,
it shows you where exactly the bitmap header stops -- it's the same for 
all these bitmaps, the header is 1078 (in decimal) or 0436 (in hexadecimal) 
bytes long.  Now select from that point to the end of the bitmap; this will
be the filmstrip part without the bitmap header.   Choose "copy", open a 
new file in the hex editor and choose "paste".  Go to the end of the new 
file and put the cursor at the very end.

Now open frogflm2.bmp in the hex editor.  In the same way find the end of 
the bitmap header and select from there to the end, choose copy, go to the 
new file and choose Paste.  Go to the end of the new file and put the cursor 
at the very end.

Repeat the process three times more, with frogflm3.bmp, frogflm4.bmp, and
frogflm5.bmp.

Now save the finished filmstrip.  Call it CHEST_H2.flm and replace the
one that's in your game's \art\Sprites\Toychestz\Frog directory -- you
must have that in place already since you've installed the Frog Easy-edit 
kit, haven't you :-)

Enjoy

Carolyn Horn








