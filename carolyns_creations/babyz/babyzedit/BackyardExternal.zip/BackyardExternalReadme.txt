
This file is intended for the use of hexers and anyone who wants to
change their Babyz Back yard.

This Back Yard.env file for Babyz will overwrite your game's original, and unless
you put everything in the correct place it _will_ crash your game, so please
please please make sure that you have your original safe somewhere and copies of
all your babyz somewhere safe.

Place the Back Yard.env in your game's resource\Area directory.

Now unpack the included zipfile, called BackyardFilmstripsEtc, into your game's
main directory (the directory which contains the babyz.exe file)

The unzipping process _should_ create a set of subdirectories like the
ones shown in the included BackyardfilesWhere.jpg picture, with the needed files in

\art\Sprites\Area\Backyard

If the unzipping process did not do that, then you will have to create the
directories manually, using Windows Explorer or My Computer, and place the files
in there.

What you should get are a load of .flm and .flh files -- these are the filmstrips
and filmstrip-info for the game.

Also in there are the Backyard icon and the Backyard backdrop.  These are simple
bitmaps and you can change these to whatever you wish in a paint program.
The Dino filmstrip will still be in the same place; it will look the same.
And there will be a Sounds subdirectory, off the Backyard one, which contains
the sounds for the scene.  These can be edited of course!

Also included in the zip is BACKYARD_DINOFLM.bmp, which is the filmstrip with
a bitmap header that I attached to it. If you want to change the Dino slide
to something that looks different, take care to put the new item in the same 
place in the backdrop, and edit the .bmp file in your favourite paint package.  
When you've finished editing and saving it, open it into a hex editor and strip 
off the bitmap header.  What needs to be removed is the first 1078 bytes of the dino's
.bmp file.  Then rename it to BACKYARD_DINO.FLM.  You'll have to remove or rename 
the original first of course.

Have fun giving your babyz nice new backyards!

Cheers

Carolyn Horn


