
This is the Carrots Treats from my Petz games for your babyz 
to enjoy.  They seem to like this healthy alternative :-)
This version is the external-filmstrip one to go with my
Howto "MakingCrackersShowSeparately.txt"

The Carrots bag.toy goes in the toyz directory of course. But
you will need to unpack the enclosed zip CarrotsbagFilmstrips.zip
into the root directory of your game -- where the babyz.exe
file is -- in a typical installation that would probably be

c:\Program Files\P.F.Magic\babyz
or
c:\Program Files\Mindscape\babyz

The files should all then go into the correct places.

Enjoy

Carolyn Horn