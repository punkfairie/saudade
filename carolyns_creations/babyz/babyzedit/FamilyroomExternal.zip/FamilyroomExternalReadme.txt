
This file is intended for the use of hexers and anyone who wants to
change their Babyz Family Room.

This Family Room.env file for Babyz will overwrite your game's original, and unless
you put everything in the correct place it _will_ crash your game, so please
please please make sure that you have your original safe somewhere and copies of
all your babyz somewhere safe.

Place the Family Room.env in your game's resource\Area directory.

Now unpack the included zipfile, called FamilyroomFilmstripsEtc, into your game's
main directory (the directory which contains the babyz.exe file)

The unzipping process _should_ create a set of subdirectories like the
ones shown in the included FamilyroomFilesWhere.jpg picture, with the needed files in

\art\Sprites\Area\FamilyRoom

If the unzipping process did not do that, then you will have to create the
directories manually, using Windows Explorer or My Computer, and place the files
in there.

What you should get are a load of .flm and .flh files -- these are the filmstrips
and filmstrip-info for the game.

Also in the FamilyRoom directory are the Family Room icon and the Family Room backdrop.  
These are simple bitmaps and you can change these to whatever you wish in a paint program.

The Window, fire and closet filmstrips will still be in the same places; they will 
look the same.

So, also included in the zip, are FAMILY_ROOM_CLOSET_BUTTONSFLM.bmp, FAMILYROOM_FIREFLM.bmp,
FAMILY_ROOM_CLOSETFLM.bmp, FAMILYROOM_FIREPLACE_KEYFLM.bmp, FAMILYROOM_SOFAFLM.bmp, 
FAMILYROOM_WINDFLM.bmp, and RECORD_CLOSET_MASKFLM.bmp.  These are the filmstrips, prepared 
by me with bitmap headers so that you can edit them.  If you want to change the window or 
closet or fireplace to something that looks different, take care to put the new items in 
the same place as before in the backdrop, then edit these .bmp files of mine in your 
favourite paint package.  When you've finished editing and saving these open them into a 
hex editor and strip off the bitmap headers.  What needs to be removed is the first 1078 
bytes of each .bmp file.  Save.

Finally, rename them to FAMILY_ROOM_CLOSET_BUTTONS.FLM, FAMILYROOM_FIRE.FLM, etc --
You'll have to remove or rename the originals first of course.

Note that the closet filmstrip has a strip of red and yellow along the top; this is
the bit which, when you have a new item in the closet, pops up with the little "new"
flag under it.  You can either leave it as it is, or replace it with the see-through
magenta colour so it never shows, or re-do the filmstrip bitmap from scratch, chopping the
thing into two and giving each their own headers as per my filmstrip tutorials.  I
simply couldn't be bothered :-)

No sounds have been extracted for this particular playscene.  In case you are interested,
the sounds that the scene contains are the crackling and hissing of the fire, the
window opening and closing, and birds chirping.  I haven't had the time or inclination
to extract them, sorry.

Have fun giving your babyz nice new Family Rooms!

Cheers

Carolyn Horn


