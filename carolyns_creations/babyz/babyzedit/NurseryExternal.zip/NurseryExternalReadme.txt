
This file is intended for the use of hexers and anyone who wants to
change their Babyz nursery or see the Bear or Animal mobiles.

This Nursery.env file for Babyz will overwrite your game's original, and unless
you put everything in the correct place it _will_ crash your game, so please
please please make sure that you have your original safe somewhere and copies of
all your babyz somewhere safe.

Place the Nursery.env in your game's resource\Area directory.

Now unpack the included zipfile, called Nursery Filmstrips, into your game's
main directory (the directory which contains the babyz.exe file)

The unzipping process _should_ create a set of subdirectories like the
ones shown in the included NurseryfilesWhere.jpg picture, with the needed files in

\art\Sprites\Area\Nursery

If the unzipping process did not do that, then you will have to create the
directories manually, using Windows Explorer or My Computer, and place the files
in there.

What you should get are a load of .flm and .flh files -- these are the filmstrips
and filmstrip-info for the game.  You can rename NURSERY_ANIMAL_MOBILE.flh to
NURSERY_SPACE_MOBILE.FLH and vice versa, but make sure that you do the same with
swapping the flm files NURSERY_ANIMAL_MOBILE.FLM and NURSERY_SPACE_MOBILE.FLM also, 
or they will not work and may crash the game.

Also in there are the nursery icon and the Nursery backdrop.  You can change these 
to whatever you wish.  The Window, closet, crib-front and mobile filmstrips will still be
in the same places; they will look the same.

Also included in the zip are nursery_cribflm.bmp and nursery_cribflmheader.bmp.
If you want to change the crib to a different model, take care to put the new model 
in the same place in the backdrop, and edit the nursery_cribflm.bmp in your favourite
paint package.  When you've finished editing and saving it, open it into a hex editor
and strip off the bitmap header.  The nursery_cribflmheader.bmp is included so that
you can look at that also in the hex editor and see exactly what needs to be removed.
It is the first 1078 bytes of the nursery_cribflm.bmp.

Have fun changing the mobiles around and giving your babyz nice new nurseries!

Cheers

Carolyn Horn


