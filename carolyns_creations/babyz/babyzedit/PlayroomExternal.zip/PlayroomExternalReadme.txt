
This file is intended for the use of hexers and anyone who wants to
change their Babyz Playroom.

This Playroom.env file for Babyz will overwrite your game's original, and unless
you put everything in the correct place it _will_ crash your game, so please
please please make sure that you have your original safe somewhere and copies of
all your babyz somewhere safe.

Place the Playroom.env in your game's resource\Area directory.

Now unpack the included zipfile, called Playroom Filmstrips, into your game's
main directory (the directory which contains the babyz.exe file)

The unzipping process _should_ create a set of subdirectories like the
ones shown in the included PlayroomfilesWhere.jpg picture, with the needed files in

\art\Sprites\Area\Playroom

If the unzipping process did not do that, then you will have to create the
directories manually, using Windows Explorer or My Computer, and place the files
in there.

What you should get are a load of .flm and .flh files -- these are the filmstrips
and filmstrip-info for the game.

Also in there are the playroom icon and the Playroom backdrop.  These are simple
bitmaps and you can change these to whatever you wish in a paint program.
The Windows and closet filmstrips will still be in the same places; they will 
look the same.

Also included in the zip are PLAYROOM_CLOSET_BUTTONSFLM.bmp, PLAYROOM_WINDFLM.bmp,
PLAYROOM_STATIC_WINDOWFLM.bmp, and PLAYROOM_CLOSETFLM.bmp. If you want to change the 
windows or closet to something that looks different, take care to put the new items 
in the same place in the backdrop, and edit the .bmp files in your favourite
paint package.  When you've finished editing and saving these four, open them into a 
hex editor and strip off the bitmap headers.  What needs to be removed is the first 
1078 bytes of each .bmp file.  Then rename them to PLAYROOM_CLOSET_BUTTONS.FLM,
PLAYROOM_WIND.FLM, PLAYROOM_STATIC_WINDOWFLM, and PLAYROOM_CLOSET.FLM.  You'll have
to remove or rename the originals first of course.

Have fun giving your babyz nice new playrooms!

Cheers

Carolyn Horn


