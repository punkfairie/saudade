
This file contains the "jungle" playroom, special filmstrips and bitmap.

The "jungle" Playroom will overwrite the relevant Playroom .env, 
also (if you have my "easy-edit playroom" installed), the .flm, .flh and 
backdrop .bmp items will overwrite the ones you've alredy installed, so 
make sure that you've got the originals stored safely before you move these 
into the correct directory.

The unzipping process _should_ create a set of subdirectories off wherever
you unpacked the zipfile:

\art\Sprites\Area\Playroom

With the needed files in there.  You need to move the art directory so that
it comes directly off the game's main directory (where the Babyz.exe file is).
If the unzipping process did not do that, then you will have to create the
directories manually, off the game's main directory and using Windows Explorer 
or My Computer, and place the files in there.  

What you should get are a load of .flm and .flh files -- these are the filmstrips
and filmstrip-info for the game.  Also in there are the playroom icon and the 
Playroom backdrop.  These are simple bitmaps.

Enjoy!

Carolyn Horn


