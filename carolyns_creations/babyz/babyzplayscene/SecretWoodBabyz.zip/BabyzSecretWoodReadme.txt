
This file contains the "secret wood" special filmstrips and bitmap.

You need to already have the basic "External Nursery" package installed in
your game before you can use the files that are inside this zipfile.

These "secret wood" Nursery files will overwrite the relevant Nursery window 
and crib .flm, .flh and backdrop .bmp items, so make sure that you've got the 
originals stored safely before you move these into the directory:

\art\Sprites\Area\Nursery  

Click on the door, you might like what happens...

You can put your babyz to bed on the soft lichen-covered bedding which is on
the lion's back leg.

Enjoy!

Carolyn Horn


