
This file contains the sounds for the "secret wood" Babyz Nursery.

You need to already have the basic "External Nursery" package installed in
your game before you can use the files that are inside this zipfile. You
also need to have the main "secret wood" package; both should be
downloadable from the same place at which you downloaded this zip.

The Nursery.env file will overwrite the one which is already in your
game's Resource\area directory, so put that one somewhere safe before
you put this one in its place.  Put the nurs_windowopen.wav and 
Sounds_Area_Nursery_Window.txt files in the directory:

\art\Sprites\Area\Nursery  

Next time you click on the door, you will get the correct sound.

Enjoy!

Carolyn Horn


