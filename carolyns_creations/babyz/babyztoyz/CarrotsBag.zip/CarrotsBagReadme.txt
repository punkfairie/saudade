
This is the Carrots Treats from my Petz games for your babyz 
to enjoy.  They seem to like this healthy alternative :-)

Just pop the .toy file into the game's toyz directory, and the
treats will show up in the kitchen closet.

Enjoy

Carolyn Horn