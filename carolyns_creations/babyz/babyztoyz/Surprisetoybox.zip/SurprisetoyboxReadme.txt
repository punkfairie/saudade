
This will overwrite the Surprise.toy which is in your
game's toyz directory.  It simply makes the toy show
up and allows you to use it.  I have fixed the pproblem
of the oddly coloured lid too. The reason that it is called
"Surprise" is because in the Petz games it contained a
surprise, which was the bubble machine.  Of course, in
Babyz, we have a separate bubble machine but it seems that
the creators forgot about the box and left it, half-finished,
instead of either finishing it as a different toy or removing it.  
Well, I've fixed it up for you and now you can use it to put things in.

Getting things into the box can be tricky, but once you've got
the knack it works fine.

One neat trick with this is that you can use it to carry more
items in your toychests!  You can put several items in each box,
and you can put the full number of filled boxes in the chest.
So for instance if you're using the frog chest, you can have
six surprise boxes in it, each one containing maybe four toyz...

Enjoy!

Carolyn Horn

P.S.
If you are a hexer who wants to edit this box with the surprise
already in it, I'm afraid that isn't guaranteed to work.  You
can put the toy inside the box in your game, and you can extract
the Registry entry and Key, but this cannot be guaranteed to work
as desired on someone else's machine -- sorry.  I know there are
a bunch of bubble-machine filmstrips in there, but the game engine
doesn't pick them up because the bubble machine is separate in this
game.
