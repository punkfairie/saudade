
This is an alternative version of the toy, for people who find that the original TV won't
work in their game.

The idea, music and basic graphics for this were sent to me by Kittycat of Waterfall Heaven
http://www.geocities.com/xxwaterfallheavenxx/index.html
A site with lots of goodies when it opens -- go there, you know you want to!

I made various alterations to the graphics, and fixed the Record Player and Record toyz so
that your Babyz can enjoy the Teletubbies :-)  

This overwrites your game's Record and Record player, so put the originals somewhere safe.
Place the two .toy files from this zip in your game's Toyz directory, and the .mid file in
your game's Songz directory.

The plus side of this toy is that the babyz dance to the teletubbies tape.  The minus side
is that the TV turns on to view teletubbies even if you're listening to a rachmaninov
disc or similar, LOL...

Enjoy!

Carolyn Horn

