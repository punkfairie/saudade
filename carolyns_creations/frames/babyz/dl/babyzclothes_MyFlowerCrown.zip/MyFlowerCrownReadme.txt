
This Flower Crown is for all your Babyz who don't have the
winged flower-crowns but would like to wear them.  Just
put it in your game's Clothes directory.

My new Flower-crowned babyz don't need it of course :-)

Enjoy!

Carolyn Horn