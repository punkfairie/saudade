
If you have a Preemie babyz, or indeed any babyz on which my normal
oxygen tube looks huge, then this is the file that you need.  It shows
up separately from the one for "normal" babyz, so that if you have
the two types of babyz with breathing problems they can each have help.

This was made at special request.  It is intended to portray
a plastic oxygen tube such as chronic asthma cases or other people
with breathing difficulties need to use; the ends are loose because
the baby doesn't actually need to use the oxygen while it is crawling
around, and you may see it flapping a bit, the tape which attaches
it to the cheeks working loose etc.  I'm sure the nurse will fix
that when it comes time to attach the oxygen :-)

Put the file in your game's clothes directory, and it will show up
in the clothes closet provided you have no other items of clothing
which use the same ID number.

Enjoy

Carolyn Horn