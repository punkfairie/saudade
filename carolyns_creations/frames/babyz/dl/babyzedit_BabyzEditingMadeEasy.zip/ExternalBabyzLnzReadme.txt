

Please read this carefully; it tells you how to make sure that 
your external, easy-edit .lnz files are installed correctly.

First of all you need to make your BabyzRez.dll file visible
in your Babyz Resource directory in Windows Explorer (or My 
Computer) if it isn't already.  You do this by choosing View 
from the W. E. or M. C. menu bar and then Options.  When the 
dialogue box opens, choose the View tab and make sure that 
"Show all files" is ticked.  Make a copy of the BabyzRez.dll 
and store it somewhere safe.  Also of course you do always make 
sure that your precious adopted .baby files are copied somewhere 
safe, don't you?  It would also be wise to keep this zipfile 
Okay, now that you have everything safe, you can go ahead with 
this installation.

If you unzip the zipfile Babyzlnzfiles.zip into your game's root 
directory (where the babyz.exe is), then all the .lnz files 
should be in the correct place, in subdirectories off a new 
directory called PtzFiles.  If you unzipped it to somewhere 
else, find the PtzFiles directory and move it (using Windows 
Explorer or My Computer) and drag-and-drop it to your Babyz 
directory.  Take a look in the ptzFiles directory now; there 
should be several subdirectories:

Baby
bunny
clothes
doll
Dropper
Foodblob
milk
rattle
Sipcup
spoon

In all of them you should see .lnz files.  In the Baby 
Subdirectory you should see all the .lnz files which 
are used by the game to make new babyz.  When you want 
to make a new baby, find out which .lnz you want to edit, 
open it in Notepad and edit to your heart's content.

Now you have two options; one involves unzipping the file
BabyzRezPatch.zip into your game's Resource directory and
following the included instructons.  Nice and easy <happy-dance>

If for some reason that doesn't work right, then you will
have to use the alternative option, which (aaargh, yes I know,
but I did my best to avoid you having to do it!) involves
opening the file into a hex editor and changing one small
letter.

Open the BabyzRez.dll file in your hex editor.  Search for 
the hex string:

4C004E005A

This will take you straight away to something which looks
like this

L.N.Z

if it has other characters instead of dots, it doesn't 
matter; it's the L and N and Z which are important.  Change 
any one of those three letters to any other letter that you 
like; this will make the game look elsewhere for its .lnz 
files.  Save.  Breathe a sigh of relief; you won't need the
hex editor again for making new babyz :-)

There you go.  You've got your .lnz files in the crrect place,
your BabyzRez.dll with that one small change, and Notepad at
the ready (also maybe Wordpad).  Hurray!  Now read the 
BabyzEasy-editHowto.txt which you should have found in the
zipfile that you downloaded.

Have fun!

Carolyn Horn
