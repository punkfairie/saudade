
This is the Norvil breed for Catz 2.  It uses data from the Oddballz
breed, complete with sounds.  It has had to leave behind it the 
various Transformations and emoticons that it used when it came out
of the Oddballz egg, but now at last your Norvilz can play with and meet 
other petz.

You cannot import your Oddballz pet directly from the Oddballz game, you will 
have to re-adopt him or her from the Adoption Centre.  But I think you
will find your pet as lovable as ever; even if it has lost its "memory",
it is still the same sensitive, intelligent, quirky little thing.

The original Norvil is in the Adoption Centre, of course, with its little
blue chest and arms, its black antennae, and its all-black irises.  But you
will find a whole family of Norvils in there, some with different coloured
coats and some with different coloured eyes.  Some even have a set of 
whiskers :-) Just put back whichever ones come out that you don't want, 
until the right one for you comes out.

For your Norvil to sound right, you will have to make sure that all its
.wav files and the nv_snd.txt file are in a subdirectory off your 
resource\catz directory, called norv.  You should be able to download
the sounds from the same place from which you downloaded this breedfile.
If there is already a nv_snd.txt file in the norv directory, overwrite it
with the one that's in this Petz 2 Norvil archive or yoru pets will make the
wrong noises at the wrong times. That other nv_snd.txt file is intended for
Petz 3 and Petz 4 Norvils.

Enjoy!

Carolyn Horn



