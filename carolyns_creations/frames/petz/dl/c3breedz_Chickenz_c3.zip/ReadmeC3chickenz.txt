
This is the Catz 3 breed file for the Chickenz.

Put the Chickenz.cat and Feathers.bmp files in your 
Resource\Catz directory. 

The Chickens will then show up in your 
Adoption Centre the next time you go there.

Note that some chickenz have the tendency to get excited
when they are put in the basket -- and when they are excited,
chickenz try to lay "eggz" ;->  this means they suddenly produce
lots of different-coloured ballz all around them.  Don't worry
about it; the ballz will go away when the chickenz are put away
through their door for a litte bit of peace, and neither they
nor the game are harmed by it.

If you want them to talk "Chicken" to you even as chicks,
then make sure you have downloaded the sound files also
(available from the site whence you downloaded this file),
and create the subdirectory:
Resource\Catz\chk
Put all the .wav files and chksn.txt in this "chk" 
subdirectory.

Enjoy!

Carolyn Horn

