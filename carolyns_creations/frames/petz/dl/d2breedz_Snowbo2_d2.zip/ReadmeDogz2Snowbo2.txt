
For Oddballz fans who only have a Dogz version of the Petz games,
Oddballz pets can now at last be adopted :-)  In Dogz II, they
can meet and play with other petz, including the Catz II versions
if you have those breedz also.

So, this is the Dogz II breed file for the Snowbo.  Put it in your 
Resource\Dogz directory, and it will show up in your Adoption Centre 
the next time you go there.  Some of the pets will come out wearing
various of Snowbo's special extras, such as his bowler hat and candy
cane.  If you adopt one of these, it will continue to wear those items
for as long as it is in the Petz II game; you'll only ever be able
to remove them if you import it one day into one of the later Petz
games.  So be careful to only adopt the pet which looks right for you;
put any others back.

If you want it to speak, and in true "Snowbo", then you will also need 
to download the sounds, which should be available  at the same site 
where you found this breedfile.  You must make a subdirectory off the 
dogz directory and call it "Snow".  Put all the .wav files, and the
"swsn.txt" which is with this breedfile, into that directory.  

If you already have the catz version of Snowbo with its sounds, then 
you don't need to re-download the sounds -- but you do need to copy them
into a directory off the "dogz" one as mentioned above.

Your new Snowbo will then ho-ho-ho and generally be seasonally genial 
at you :-)

Enjoy!

Carolyn Horn

