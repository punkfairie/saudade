

NOTE: This breed was originally made at the request of David Shiponi 
who ran the grandly-named "Petz Central".  It was released with one 
of his free "expansion packs".  When the breed was no longer available 
at his site, I placed it here for those of the Community who wanted 
it to download.  I believe it is now back up there, but this breed
is no longer exclusive.

Don't ask me to make available the playscenes etc from those Petz 
Central packs, as I had nothing to do with making them.  I also 
had nothing whatsoever to do with the pack for which that site was 
charging money.  At no time will any of my Petz/ Oddballz/ 
Babyz creations ever require payment from anyone with my consent.

This is a file which has been sound-stripped to make the download small.  


If you want your pets to have sounds, you will need the Dalmatian
sounds which should be available from the place from which you downloaded this file
or from my site.  When you have downloaded the sounds, if you unzip them into
the game's main directory they should all go into the correct place.

If for some reason the unzipping process doesn't place them into the following
subdirectory which it should have created off your game's main directory:

\ptzfiles\dog\dm

then you will have to create that set of subdirectories yourself, using either
My Computer or Windows Explorer.  Off the game's main directory (where the .exe
file is) create a directory and call it ptzfiles.  Off that one, create another
and call it dog.  Off that one, create another and call it dm. Place all the .wav 
files and the dmsnd.txt file in that "dm" directory. Your pets will talk then.

Enjoy!

Carolyn Horn


