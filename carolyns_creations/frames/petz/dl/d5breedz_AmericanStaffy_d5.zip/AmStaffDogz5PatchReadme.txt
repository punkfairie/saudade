
This is a file which has been sound-stripped to make the download small.  


If you want your pets to have sounds, you will need the Great Dane 
sounds which should be available from the place from which you downloaded this file
or from my site.  When you have downloaded the sounds, if you unzip them into
the game's main directory they should all go into the correct place.

If for some reason the unzipping process doesn't place them into the following
subdirectory which it should have created off your game's main directory:

\ptzfiles\dog\gd

then you will have to create that set of subdirectories yourself, using either
My Computer or Windows Explorer.  Off the game's main directory (where the .exe
file is) create a directory and call it ptzfiles.  Off that one, create another
and call it dog.  Off that one, create another and call it gd. Place all the .wav 
files and the gdsnd.txt file in that "gd" directory. Your pets will talk then.

Enjoy!

Carolyn Horn

