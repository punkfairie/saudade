This is the Catz 2 breed file for the Bunny,
which is a copy of the bunny which comes with Petz 4
but with added variations especially for you :-)

Put the Bunny.cat and BunnyX.cat files in your Resource\Catz 
directory, and create the subdirectory:

Resource\Catz\bn 

Put all the .wav files, bnsn.txt, and the two furfiles
grey.bmp and white.bmp in this "bn" subdirectory.

The Bunny will then show up in your Adoption Centre 
the next time you go there, and will talk "bunny" to you.
Of course, rabbits don't say much that we can hear, but 
they do make some noises.  They have a little grinding sound 
that serves instead of a purr, for instance.

Enjoy!

Carolyn Horn

P.S. It is not quite the same as my Cotton Bunny; if you
eventually import the pet into Petz 4 or Petz 5, it
will be treated as a genuine original P.F.Magic breed,
and will be imported using the original bunny breedfile.
The downside of this is that, unless you used one of
my special P4 or P5 "fixed" breedfiles, the bunny will
import with white fur and in a neutered state.
