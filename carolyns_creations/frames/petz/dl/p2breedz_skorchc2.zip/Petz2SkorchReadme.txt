
This is the Skorch breed for Catz II.  It uses data from the Oddballz
breed, complete with sounds.  It has had to leave behind it the 
various Transformations and emoticons that it used when it came out
of the Oddballz egg, but now at last your Skorch can play with and meet 
other petz.  It will also be able to breed with any Catz-based breed,
although resulting babies may turn out to be a little strange.

You cannot import your Oddballz pet directly from the Oddballz game, you will 
have to re-adopt him or her from the Adoption Centre.  But I think you
will find your pet as lovable as ever; even if it has lost its "memory",
it is still the same affectionate, lively, quirky little thing.

For your Skorch to sound right, you will have to make sure that all its
.wav files and the sksnd.txt file are in a subdirectory off your 
resource\catz directory, called sk.  Put the .bmp files in there too
-- Snake1.bmp, sk.bmp, lava.bmp -- or your Skorch will come out with no skin!

The sound files are downloadable separately, from my species sounds page

Enjoy!

Carolyn Horn

