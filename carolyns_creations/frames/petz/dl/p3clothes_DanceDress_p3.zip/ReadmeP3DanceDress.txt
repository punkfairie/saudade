
This is a pair of dresses for your petz.  For them to look right,
you will have to put the two .clo files and the blup.bmp in your game's
Resource\Clothes directory.  

They will show up separately in the Clothes Closet, one being a
bright yellow and black leopard-look item and the other a more classy, 
autumnal green effect.

Enjoy!

Carolyn Horn

