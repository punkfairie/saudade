
It has come to my attention that in some people's games, Peg
has different-coloured wrists from the one in mine.  This version
of Peg is for people who want that other Peg :-)

She is also fully mature now, so that people whose pets have
developed a full relationship with her in their games can, I hope,
see their petz carrying on the same relationship with her without
having to wait for her to grow up.

Now available for you in Petz 3, thanks to Carol (Minibyte)
who took the time and effort to convert my Petz 4 versions of 
the clothes to Petz 3.  She did a great job!

I have since added modifications to the filmstrips so that you 
can see the clothes looking as they should do in the closet; I
have also provided an eye patch, even though Peg never takes
her own off (she obviously needs to keep it on <g>). You'll
have to do without the wooden leg, as I don't think any pet would
want to saw off their own leg to put a wooden one in place!

This is the Cat Host from the Petz 4 South Seas scene -- Peg!
Put Peg in your Adopted Petz folder and the .clo files
in your Resource\clothes directory.  Peg will then
be ready to come out and play in any playscene, and her
clothes will be available for all petz in the clothes
closet.

My original P4 versions of the clothes were exact conversions of the
P.F.Magic Hosts' originals for other Petz to use.  But P.F.Magic 
intended them only for use by Hosts, so there were some funny
little "quirks" which some clothes had when worn by other pets.
In the case of Peg's clothes, Host Peg's ankles are actually the cuffs
for her shirt, plus the scarf didn't show up when dogs wore the
shirt.  So Carol decided to alter the shirt in this zip so as to
look the same on all pets.

Note that Peg herself looks a little strange without her
special clothes.  She is an exact clone of the Peg Host who 
is in the Petz 4 game, so that really is the way she's supposed 
to look.

If you don't have the Catz part of Petz 3, of course, you will
not be able to have Peg in your game, but the clothes
will work.

Enjoy!

Carolyn Horn
