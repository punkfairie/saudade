
Now available for you in Petz 3, thanks to Carol (Minibyte)
who took the time and effort to convert my Petz 4 versions of 
the clothes to Petz 3.  She did a great job!

I have since added modifications to the filmstrips so that you 
can see the clothes looking as they should do in the closet.

This is the Cat Host from the Petz 4 Arabian scene -- Pharaoh!
Put Pharaoh in your Adopted Petz folder and the .clo files
in your Resource\clothes directory.  Pharaoh 
will then be ready to come out and play in any playscene, 
and his clothes will be available for all petz in the clothes
closet.

Note that Pharaoh himself looks a little strange without his
special clothes.  He is an exact clone of the Pharaoh Host who 
is in the Petz 4 game, so that really is the way he's supposed 
to look.

If you don't have the Catz part of Petz 3, of course, you will
not be able to have Pharaoh himself in your game, but the clothes
will work.

Also kudos to Carol (Minibyte) for producing a pair of 
formal footwear for other catz to wear who wish to dress up in 
Pharaoh's clothes, since Pharaoh himself will never take off his 
sandals. In fact, these new "sandals" are special socks, and Pharaoh 
himself can wear them over his own sandals.  Carol's original version 
of these socks is provided in this zipfile.

Also, in a separate zip, you will find a more flamboyant modification
of the socks made by myself.  It will overwrite her version, so make
sure that you keep hers safe.  For the sandals in my version to look
right, make sure that the file called sphinx.bmp is in the game's 
clothes directory.

Enjoy!

Carolyn Horn
