

This is my Babyz Doll for Petz 3 non-English.  It is made to look as 
close as possible to the Babyz rag doll so that Petz players can enjoy 
that toy in their games.

To make it show up in your game just put it in your game's Toyz
directory. Next time you open your game you should see my Doll in 
your Toy Closet.

NOTE: any hexer who wants to port their own Babyz hexed dolls to 
Petz 3 can use this for that purpose.  There are some differences 
to take into account -- there are only 7 base balls instead of 17, 
and the xyz positions are very different due to the Petz defaults 
being different from the Babyz ones.  Note that the Petz 3 version 
is a little different from the Petz 4 and Petz 5 versions, so to 
convert your own hexed dollz to work in all games you'll need to 
make some alterations to your .LNZ files.

Enjoy

Carolyn Horn
