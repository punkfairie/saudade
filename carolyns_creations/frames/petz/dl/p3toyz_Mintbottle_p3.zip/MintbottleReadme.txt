
This is the Mint Bottle for Petz 3.

Place the Mint Bottle.toy in your game's Toyz directory, of course.
But also -- and this is very important -- make sure that the four other
Mint files are in a subdirectory, off your game's root directory, that is
called Ptzfiles\Mint

You may have to create this directory for yourself.  If so, it's pretty
simple.  In Windows Explorer or My Computer, navigate to the game's main
directory.  Now from the menu bar choose File, New, Folder.  Name the new
folder Ptzfiles.  Open that new directory and repeat the process, this time
calling the new folder or directory Mint.  Place the four files
Mint0.bdt, Mint.bhd, Mint.scp and Mint.lnz in there.

Next time your game opens you should see a Mint Bottle on the shelf.

Enjoy!

Carolyn Horn


