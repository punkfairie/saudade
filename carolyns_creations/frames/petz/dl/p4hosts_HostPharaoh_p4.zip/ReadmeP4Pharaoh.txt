

This is the Cat Host from the Petz 4 Arabian scene -- Pharaoh!
Put Pharaoh in your Adopted Petz folder and the .clo files
in your Resource\clothes directory.  Pharaoh 
will then be ready to come out and play in any playscene, 
and his clothes will be available for all petz in the clothes
closet.

I have now added modifications to the filmstrips so that you 
can see the clothes looking as they should do in the closet.

Note that Pharaoh himself looks a little strange without his
special clothes.  He is an exact clone of the Pharaoh Host who 
is in the Petz 4 game, so that really is the way he's supposed 
to look.

If you don't have the Catz part of Petz 4, of course, you will
not be able to have Pharaoh himself in your game, but the clothes
will work.

My thanks to Carol (Minibyte) for the idea of producing a pair of 
formal footwear for other catz to wear who wish to dress up in 
Pharaoh's clothes, since Pharaoh himself will never take off his 
sandals. In fact, these new "sandals" are special socks, and Pharaoh 
himself can wear them over his own sandals.  For the sandals to look
right, make sure that the file called sphinx.bmp is in the game's 
clothes directory.

Carol's original version of these socks is provided also, in a separate
zipfile.  Her more sophisticated black ones will overwrite this more 
flamboyant version.


Enjoy!

Carolyn Horn
