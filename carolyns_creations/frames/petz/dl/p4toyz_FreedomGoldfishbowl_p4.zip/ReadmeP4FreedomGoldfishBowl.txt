
This is a Petz 4 toy.

The Goldfish Bowl will overwrite the one that's already in your game.  Make sure
that you have the original moved somewhere safe in case you want the poor fish
to go back into it.

I made this because that bowl seemed just plain cruel, with nothing in it for the 
fish to play in or hide  around.  _Not_ a good way to teach people how to look after 
animals!

Your little fish can now float freely around; he'll still not stray far from where
you place him, but he is free of the restraint of glass.  Load up your carry-case
with little fishes from the Toy closet and take them to my special "fishy" playscene, 
which is a fish-eye view of the beach, and let them play with each other and your petz.
Yes, I know that in Real Life, goldfish are supposed to be freshwater fish.  These ones 
of mine are saltwater varieties of fish :-)

You can still feed these little fishes; just hold the food over the centre point that
he swims around.

If this total fishy freedom is too much for you, download my other version, which
will give your fish plenty of space and a miniature circus to swim around.

Enjoy!

Carolyn Horn