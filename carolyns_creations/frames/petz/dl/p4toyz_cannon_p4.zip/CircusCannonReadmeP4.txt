
Please please read these notes carefully.

This is the Circus Cannon for Petz 4, made to show up in the Toy Closet.

It will overwrite the one that's in your game's toyz directory, so please make sure 
that you have that one somewhere safe before putting this one in place.

When you look for it in the closet, it will look a bit like a small cannon.  When
the hand clicks on it, you will see nothing in the hand, but you _will_ have
grabbed it, I promise you.  Do not let the invisible wotsit go until you have placed
it where you want it to be because you _cannot_ move it after it is placed, and it will
not go back into the toy closet once you've clicked on it.  It will still be invisible 
after you have released it from the hand.

Now close the game and re-open it at the Toy Closet.  Your cannon will be where
you put the invisible wotsit.  If you panicked and kept grabbing it from the shelf,
you will have _lots_ of cannon, LOL!

You can now place the confetti ball in the cannon, click on the fuse, and watch it
fire for you :-)

When you get tired of having the cannon in the game, you can do "clean up toy closet"
and it will disappear.  You cannot put it in your case to carry elsewhere, sorry about
that, but it doesn't crash the game or cause any other problem that I've come across.

Enjoy

Carolyn Horn




