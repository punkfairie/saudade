

This is the "102" breed for Catz 5.  It uses data from the Oddballz
breed, complete with sounds.  It has had to leave behind it the 
various Transformations and emoticons that it used when it came out
of the Oddballz egg, but now at last your 102 can play with and meet 
other petz.  He or she will also be able to breed with any Catz-based breed.

You cannot import your Oddballz pet directly from the Oddballz game, you will 
have to re-adopt him or her from the Adoption Centre.  But I think you
will find your pet as lovable as ever; even if it has lost its "memory",
it is still the same bouncy, friendly, happy little thing.  The young
Dynaroo is a little chubbier than its Oddballz counterpart, but it
soon grows out of its "puppy-fat" :-)

The original 102 is in the Adoption Centre of course, with its
white, Dalmatian-spotted body-fur and its black eyes.  
But you will find a whole family of pets in there.
Some of its family members have different fur styles and different 
coloured eyes.  Just put back whichever ones come out that you don't 
want, until the right one for you appears.

Place the 102.cat file in your game's resource\catz directory, as 
usual.  But also, if you want it to look right, you will have to put 
all three of the bitmaps -- dalmat1.BMP, dalmat2.BMP, and dalmat4.BMP
-- in a subdirectory off your resource\catz directory which you will 
need to create and name rov.

For your 102 to sound right, you will have to make sure that all its
.wav files and the rosn.txt file are in that "rov" subdirectory off your 
resource\catz directory.  You should be able to download the sounds 
from the same place from which you downloaded this breedfile.

Enjoy!

Carolyn Horn

