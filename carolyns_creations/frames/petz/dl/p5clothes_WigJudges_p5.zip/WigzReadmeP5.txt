
Here's a wig for your Petz 5 petz.  It shows up separately
in the clothes closet, where it looks like a Confetti-ball toy
Although the wigz themselves look like dreadlocks or a Judge's
wig, depending on which one you downloaded.  They will work on 
dogz and catz, and will re-size themselves to fit small and 
large alike.

Enjoy!

Carolyn Horn