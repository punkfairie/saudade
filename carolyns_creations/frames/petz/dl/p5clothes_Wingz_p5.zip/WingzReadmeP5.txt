
Here's a pair of wingz for your Petz 5 petz.  They show up separately
in the clothes closet; the left one shows as a blue feather on the shelf 
and the right one as a red feather, although the wingz themselves are 
white with pastel markings.  They will work on dogz and catz, and
will re-size themselves to fit small and large alike.

Enjoy!

Carolyn Horn