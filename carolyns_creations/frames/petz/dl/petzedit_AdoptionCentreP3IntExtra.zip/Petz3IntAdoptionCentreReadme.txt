
This zipfile contains the special file that you need, along with the 
"easy-edit Adoption Centre for petz 3", to enable players of 
non-English Petz 3 to customise your game's Adoption Centre backdrop etc.

You need to download also the "easy-edit Adoption Centre for petz 3", but
use the Adoptionszentrum.env in this zipfile instead of the 
Adoption Center.env file in that one.

Enjoy!

Carolyn Horn