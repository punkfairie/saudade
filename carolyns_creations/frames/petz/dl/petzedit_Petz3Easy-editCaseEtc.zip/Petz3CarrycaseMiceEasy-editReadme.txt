
This zipfile contains all that you need to enable you to customise your game's
carrycase and its door, the Adoption Centre doors, and the mice.

First of all, move your Petz 3 Rez.dll file -- it will be in your 
game's Resource directory -- and put it somewhere very safe.  Then place the
Petz 3 Rez.dll file which is in this zip in its place.  Now unzip the included
P3Easy-editFiles.zip into your game's main directory, where you see the Petz 3.exe
file.  It should unpack everything into the correct places.  See the included
screengrab GIFs to see where everything should have gone.  If it isn't all in the
right places, find the files wherever they were unpacked on your hard drive and
put them in the correct places, using My computer or Windows Explorer.  

The game should now start with no problems.

In order to edit your mice or cockroaches, open the relevant .LNZ files into
Notepad, edit them as you would a breed's .lnz, and enjoy.  See my various "howtos"
on editing breedz if you have no idea what all the numbers etc mean.

You can change the sounds that your game uses for calling petz etc; just replace
any of the .wav files with others of your choice, named correctly of course.

You can change the .bmp files for any of your own choosing also; but be careful
if you're planning on distributing litterz which use altered furfile bmps because
the people adopting them won't see the pet as you do.

You can of course change the .txt files to suit yourself, and the .FLM files
can all be edited to make things like case doors of your choice or to give your
Adoption Centre a new look.

To edit the filmstrips you'll need to understand something about filmstrip
editing.  I have tutorials about that also, and I have conveniently split
the main filmstrips so that you can edit them in a paint program if you wish.  They
are available in a separate zipfile called Petz3SplitFilmstrips.zip.  For the
Case filmstrips, I've also provided them with bitmap headers so that all you need to
do is edit them, strip off the headers and put them together again as Case.flm
to overwrite the one in your game's \art\sprites\case directory.

Enjoy!

Carolyn Horn