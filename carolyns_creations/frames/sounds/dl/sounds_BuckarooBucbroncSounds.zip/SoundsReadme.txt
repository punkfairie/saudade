
This zipfile contains the sound files for my Bucbronc and Buckaroo Oddballz breedz.
Create a subdirectory off the Eggz\Bucbronc or Eggz\Buckaroo directory and call it 
Soundsss.

Put all the .wav files into this subdirectory, and your Buckaroo or Bucbronc
will find its voice.

You will find that your new pet has its own individual needs, its own speech
patterns, and has a few surprises hidden inside.

Enjoy!

Carolyn Horn

