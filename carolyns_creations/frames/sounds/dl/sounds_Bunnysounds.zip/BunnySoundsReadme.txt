
These are the bunny sounds.  They are included in my own Cotton
Bunny and breedable game-bunny files, but owing to popular
demand (well a polite request from Minibyte actually, LOL) -- here 
they are separated also.  Unpack them into your game's \Resource\Catz
directory and they should go in the correct place.  If they don't, 
you need to put bnsn.txt and all the .wav files into a subdirectory, 
off the Resource\Catz directory, called bn

\Resource\Catz\bn

Enjoy!

Carolyn
