
These are the sound files for the Dragon.

Make a subdirectory off your Resource\dogz directory, and call it dr.

Place all the .wav files, and drsn.txt from the breedfile archive, into this subdirectory.

Next time you bring out your Dragonz, they should talk to you.

Enjoy!

Carolyn Horn