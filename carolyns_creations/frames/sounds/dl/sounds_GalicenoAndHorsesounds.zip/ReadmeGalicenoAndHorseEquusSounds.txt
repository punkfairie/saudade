
These are the Galiceno sounds for Dogz 2, 3 and 4, and the Horse Equus sounds for Dogz 2 and 4.

If you want your pets to speak "horse",  make a subdirectory 
off your Resource\dogz directory, and call it h.  Place hesnd.txt in there,
and make a subdirectory off that one and call it sound.  Put all the .wav 
files into this subdirectory.  Next time you bring out your Galiceno
or Horse Equus, they should talk to you.

For the Dogz 2 versions, you will need to replace this hesnd.txt with the one
included in the breedfile zip.

Enjoy!

Carolyn Horn