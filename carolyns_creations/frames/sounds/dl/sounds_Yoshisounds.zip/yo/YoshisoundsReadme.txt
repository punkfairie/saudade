
These are the sound files for the Dogz breedz Yoshi.

Make a subdirectory off your Resource\dogz directory, and call it yo.

Place all the .wav files and yosn.txt into this subdirectory.

Next time you bring out your Yoshiz, they should talk to you.

Enjoy!

Carolyn Horn