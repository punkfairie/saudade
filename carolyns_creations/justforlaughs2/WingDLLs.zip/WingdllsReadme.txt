
These WinG dll files etc are required by some of the early Petz games.

They should be unzipped and go in your Windows\System32 folder.
If that doesn't work, try putting them in your Windows\system folder.

Enjoy


