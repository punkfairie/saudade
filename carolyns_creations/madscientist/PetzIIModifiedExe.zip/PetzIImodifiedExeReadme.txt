
This Petz II exe file has been modified so that the Brain Slider
makes more sense if you have it turned on.  The most important
sliders have been given names, so that you can better control
your pet's health and happiness.

The Petz II.exe will overwrite the one that's in your game,
so either move or rename your original before putting this one
in its place.  Once you have replaced your original with my 
modified one, you will want to enable the sliders if you haven't
already.  If you already have them appearing on screen, ignore
the little .reg file included in this zip, but if you haven't,
double-click on it.  This enters the value into your game's
Registry.

If you want to turn the brain-sliders off, open the little .reg file
in Notepad and, where it says 

"Show Slider Brain"=hex:01

change that to

"Show Slider Brain"=hex:00

save, and double-click on it.

Enjoy

Carolyn Horn