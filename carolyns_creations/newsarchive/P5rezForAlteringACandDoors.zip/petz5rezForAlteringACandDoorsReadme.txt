
This is a version of my cut-down Petz 5 rez.dll file which, along with my 
Easy-edit kit, is for people who want to use Tinker to edit the case door 
and the Adoption Centre filmstrips.  It allows you to export, edit, re-import
and then save the rez, and you can easily then share with others -- but they
must also have my "Easy-edit kit".  This Petz 5 rez.dll replaces the smaller
one which is in my kit; install the kit and then overwrite the one in there
with this one.

Enjoy

Carolyn Horn

