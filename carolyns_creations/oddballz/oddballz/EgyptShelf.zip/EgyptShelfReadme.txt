
This package is intended for use with my OddzRez Easy-edit zip.
Download and install that Easy-edit package as per the included
instructions first.  These two files overwrite the FUNL.flm
and SHLF.flm files in your \art\flmstrps directory, so
keep safe copies of those somewhere.

I made this Egyptian "shelf" for my Oddballz game in order to
test that my external filmstrips and instructions work properly.
They may be a little rough, but I like them, so I thought I'd share.
You will surely be able to make some much more exciting re-vamps of 
the toy/egg "shelf" and all the various toyz.

Cheers; have fun!

Carolyn Horn


