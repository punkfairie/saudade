
This is a mouse replacement for one of the grubz in your Oddballz game.
It was created by Joshua of Joshua's Petz Laboratory 
http://mysite.freeserve.com/petzlaboratory

You will need to have my "Oddballz easy-edit kit" installed in your game
before you can use this replacement grubz.  If you don't, the instructions
below will mean nothing to you.

In this zipfile you should see, apart from this readme, a file called GRUB3.lnz
Open Windows Explorer or My Computer and navigate to your game's ptzfiles\grub
directory.  In there you will see that there is already a GRUB3.lnz.  Move or
rename this, so that you can bring it back into your game again in the future
if you wish.  Now move the GRUB3.lnz from this zipfile into ptzfiles\grub and
start the game.  One of the grubz will now be a mouse.

Enjoy!

Carolyn
