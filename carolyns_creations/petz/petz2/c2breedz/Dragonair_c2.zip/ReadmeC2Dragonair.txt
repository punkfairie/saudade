
This is the Dragonair breed for Catz 2.  

It was originally made for Catz 3 at the request of Racie of "Meow Corp. Petz".  
She put together the sound files for this breed, and she's a talented hexer 
with a site full of her wonderful breedz (plus another, less complicated version 
of my Catz 3 Dragonair) at:
http://www.angelfire.com/art2/racieb/petz/
Up there she has several other Pokemon as well as some excellent Species,
Catz, Dogz, and clothes.

The original Dragonair is in the Adoption Centre; but there are also 
some with different fur colours and different coloured eyes, as well as
some that are more slimline than others.  Just put back whichever Dragonairz 
come out that you don't want, until the right one for you appears.

For your Dragonair to look right, you will have to make sure that its 
two bitmap files -- Drac1.BMP and Drac3.BMP -- are in a subdirectory off 
your resource\catz directory, called da.  You may have to create this
subdirectory yourself in Windows Explorer or My Computer.

For your Dragonair to sound right, you will have to make sure that all its
.wav files and the dsnd.txt file are also in the new directory called da.  
You should be able to download the sounds from the same place from which 
you downloaded this breedfile.  Replace the dsnd.txt which is with the 
sound archive with the one that is included with this breedfile.

NOTE:
If you adopt a pet from this breedfile, and you eventually get one of the later
Catz games and wish to import it using the relevant Dragonair breedfile, you
may perhaps find that your pet's earwing colours are slightly different.

Enjoy!

Carolyn Horn

