

This is the Dynaroo breed for Catz 2.  It uses data from the Oddballz
breed, complete with sounds.  It has had to leave behind it the 
various Transformations and emoticons that it used when it came out
of the Oddballz egg, but now at last your Dynaroo can play with and meet 
other petz.  He or she will also be able to breed with any Catz-based breed.

You cannot import your Oddballz pet directly from the Oddballz game, you will 
have to re-adopt him or her from the Adoption Centre.  But I think you
will find your pet as lovable as ever; even if it has lost its "memory",
it is still the same bouncy, friendly, quirky little thing.  The young
Dynaroo is a little chubbier than its Oddballz counterpart, but it
soon grows out of its "kitten-fat" :-)

The original Dynaroo is in the Adoption Centre of course, with its
purple, green-spotted body-fur, black eyes, and two front teeth.  
But you will find a whole family of pets in there, including ones
with Dynaroo's cheerful big grin complete with the gold tooth.
Some of its family members have different fur styles and different 
coloured eyes.  Just put back whichever ones come out that you don't 
want, until the right one for you appears.

Place the Dynaroo.cat and DynarooX.cat files in your game's resource\catz
directory, as usual.  But also, if you want it to look right, you will
have to put all three of the bitmaps -- dznar4.bmp, dznar5.bmp, and dznar9.bmp
-- in a subdirectory off your resource\catz directory which you will need to
create and name dyna.

For your Dynaroo to sound right, you will have to make sure that all its
.wav files and the dsn.txt file are in a subdirectory off your 
resource\catz directory, called dyna.  You should be able to download
the sounds from the same place from which you downloaded this breedfile.
Replace the dsn.txt which is with the sound archive with the one that 
is included with this breedfile.

Enjoy!

Carolyn Horn

