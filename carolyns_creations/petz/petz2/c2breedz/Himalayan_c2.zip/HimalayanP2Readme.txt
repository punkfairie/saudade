
This is the Petz 2 version of my Himalayan Cat breed, with
improvements.

Place it in your Resource\Catz directory.  Then make a copy of your
SiameseX.cat file in the same directory, and rename the copy HimalayanX.cat.

You will now be able to adopt and play with a variety of Himalayan kittens :-)

Enjoy

Carolyn Horn