
This is the Honker breed for Catz 2.  It uses data from the Oddballz
breed, complete with sounds.  It has had to leave behind it the 
various Transformations and emoticons that it used when it came out
of the Oddballz egg, but now at last your Honkerz can play with and meet 
other petz.

You cannot import your Oddballz pet directly from the Oddballz game, you will 
have to re-adopt him or her from the Adoption Centre.  But I think you
will find your pet as lovable as ever; even if it has lost its "memory",
it is still the same affectionate, food-loving, quirky little thing.

For your Honker to sound right, you will have to make sure that all its
.wav files and the hk_snd.txt file are in a subdirctory off your 
resource\catz directory, called honk.  Put honker.BMP in there too, as 
that is a classy furfile for one of the Honker adoptees.

Enjoy!

Carolyn Horn



