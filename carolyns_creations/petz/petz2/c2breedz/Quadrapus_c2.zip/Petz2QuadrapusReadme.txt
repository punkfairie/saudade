
This is the Quadrapus breed for Catz 2.  It uses data from the Oddballz
breed, complete with sounds.  It has had to leave behind it the 
various Transformations and emoticons that it used when it came out
of the Oddballz egg, but now at last your Quadrapus can play with and meet 
other petz.

Place the nose.bmp file in a subdirectory which you can make off your 
Resource\catz directory; this subdirectory must be called quad.  If you
don't do this, Quadrapus will have no "shine" on its nose :-)

You cannot import your Oddballz pet directly from the Oddballz game, you will 
have to re-adopt him or her from the Adoption Centre.  But I think you
will find your pet as lovable as ever; even if it has lost its "memory",
it is still the same nervous, intelligent, quirky little thing.

The original Quadrapus is in the Adoption Centre, of course, with its 
coal-black eyes and yellow ankles etc.  But you will find a whole family of 
Quadrpussies in there, some with different colouring and different coloured eyes.  
Just put back whichever ones come out that you don't want, until the right one 
for you comes out.

For your Quadrapus to sound right, you will have to make sure that you have 
downloaded the sounds also.  You should find them at the same site from which
you downloaded this breedfile.  Make sure that all its .wav files are in the 
subdirectory, off your resource\catz directory, which you have called quad.  
Make sure that you also put in there the particular qpsnx.txt file which 
is included with this breedfile, or your Quadrapus won't talk correctly.

Enjoy!

Carolyn Horn



