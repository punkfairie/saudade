
This contains the Reindeerz breedfiles for Catz 2 -- 
Reindeerz.cat and ReindeerzX.cat.

Place the two files in your Resource\catz directory, and you will then be
able to adopt two different colours of reindeer from it.

If you want your pets to speak "reindeer", then download the sound
files also, which should be available at the site whence you downloaded
this breedfile.  If you do download the sounds, then make a subdirectory 
off your Resource\catz directory, and call it rd.  Place all the .wav files 
and into this subdirectory.  Place also the rdsn.txt file which is in this 
Petz 2 reindeer zipfile in there; say "yes" to overwrite if it asks you.
Next time you bring out your Reindeerz, they should talk to you.

Enjoy!

Carolyn Horn