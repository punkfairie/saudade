
This is the Snowbo breed for Catz 2.  It uses data from the Oddballz
breed, complete with sounds.  It has had to leave behind it the 
various Transformations and most emoticons that it used when it came out
of the Oddballz egg, but now at last your Snowbo can play with and meet 
other petz.

Place the Ant.bmp file in a subdirectory which you can make off your 
Resource\catz directory; this subdirectory must be called Snow.  If you
don't do this, Snowbo will have no "fur" :-)

You cannot import your Oddballz pet directly from the Oddballz game, you will 
have to re-adopt him or her from the Adoption Centre.  But I think you
will find your pet as lovable as ever; even if it has lost its "memory",
it is still the same cheerful, intelligent, quirky little thing.

The original Snowbo is in the Adoption Centre, of course, with its little
red gloves and coal-black eyes etc.  But you will find a whole family of 
Snowbos in there, some with different coloured gloves and different coloured eyes
and some with accessories -- various emoticons made solid.  Just put back whichever 
ones come out that you don't want, until the right one for you comes out.

Choose carefully because, in the Petz 2 version of Snowbo, whatever the pet comes
out wearing (whether it's the antlers, the candy cane, the red nose, etc) it will
keep for as long as it is in the Petz 2 game.  However, if you ever get either
Petz 3 or Petz 4 and you download those versions of the breedfile, you will be
able to import your Petz 2 pet and he (or she) will then be able to take off
or put on any of the Snowbo extras.

For your Snowbo to sound right, you will have to make sure that you have 
downloaded the sounds also.  You should find them at the same site from which
you downloaded this breedfile.  Make sure that all its .wav files are in the 
subdirectory, off your resource\catz directory, which you have called Snow.  
Make sure that you also put in there the particular sm_snd.txt file which 
is included with this breedfile, or your Snowbo won't talk correctly.

Enjoy!

Carolyn Horn



