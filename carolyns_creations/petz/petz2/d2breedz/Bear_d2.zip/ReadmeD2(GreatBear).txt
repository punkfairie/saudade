

This is the Dogz 2 breed file for  the Great Bear.
Put it in your Resource\Dogz directory, and it will show
up in your Adoption Centre the next time you go there.

If you want your Bearz to speak "Bear", you will need to make sure that 
you have downloaded the sounds also.  Put the gbsnd.txt 
file into a subdirectory, off your game's resource\dogz directory, 
which must be called g (just the letter g), and put all the .wav files 
in a subdirectory off that one, which must be called soun.

Enjoy!

Carolyn Horn

