
This is the Guinea Pig2 breedfile for Dogz 2.

Dawn Deale made the original Guinea Pigs, for Petz 3, and I gave them their sounds.
I have now ported the breedz to Petz 2 and Petz 4, as well as having made a small 
alteration to allow the baby guineapigs to speak (not just the adults).
Also I have corrected a problem which caused adult guineapigs' eyes and ears to 
float a little way above their heads.

Place the breedfiles in your Resource\dogz directory, and you will then be able to 
adopt some sweet Guinea Pigz. 

They have their own special ways of communicating, of course; but if you want to hear
them, you will have to download the sound files also, available from the site whence you
downloaded this breedfile.  Make a directory off the Resource\Dogz directory, and call it
gpig.  Put the .wav files in there, and the gpigsnd.txt file from this Petz 2 Guineapig 
zipfile.  Next time you take out your Guinea Pigz, they will speak to you in their own language.

Enjoy!

Carolyn Horn