

This is the Dogz 2 breed file for  the Horse Equus.
Put it in your Resource\Dogz directory, and it will show
up in your Adoption Centre the next time you go there.

If you want your Horsez to speak "Horse", then download the sound
files also, which should be available at the site whence you downloaded
this breedfile.  If you do download the sounds, then make a subdirectory 
off your Resource\dogz directory, and call it h (just the letter h, nothing 
more) and put all the .wav files in a subdirectory off that one, which
must be called sound. Put the hesnd.txt from this HorseEquus zipfile
in the "h" directory; say "yes" to overwrite if it asks you.
Next time you bring out your Horsez, they should talk to you. 

Enjoy!

Carolyn Horn

