

This is the Dogz 2 breed file for  the Pig-hog.
Put it in your Resource\Dogz directory, and it will show
up in your Adoption Centre the next time you go there.

If you want your Hogz to speak "Pig", then download the sound
files also, which should be available at the site whence you downloaded
this breedfile.  If you do download the sounds, then make a subdirectory 
off your Resource\catz directory, and call it pighog. Put all the .wav 
files into this subdirectory.  Place also the phsn.txt file which is in this 
Petz 2 Pighog zipfile in there; say "yes" to overwrite if it asks you.  
Next time you bring out your Pighogz, they should talk to you.

Enjoy!

Carolyn Horn

