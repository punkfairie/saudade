

This is the Dogz 2 breed file for  the Turkey.
Put the Turkey.dog, TurkeyX.dog, and feathers.bmp in your Resource\Dogz 
directory, and it will show up in your Adoption Centre the next time you 
go there.

If you want your Turkeys to speak "Turkey", then download the sound
files also, which should be available at the site whence you downloaded
this breedfile.  If you do download the sounds, then make a subdirectory 
off your Resource\dogz directory, and call it chk.  Place all the .wav files 
into this subdirectory.  Place also the chksn.txt file which is in this 
Petz 2 Turkey zipfile in there; say "yes" to overwrite if it asks you.
Next time you bring out your Turkeyz, they should talk to you.

Enjoy!

Carolyn Horn

