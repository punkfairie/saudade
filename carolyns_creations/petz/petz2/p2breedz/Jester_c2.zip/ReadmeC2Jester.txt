

This is the Jester breed for Catz II.  It uses data from the Oddballz
breed, complete with sounds.  Although it has had to leave behind it the 
various in-game Transformations and emoticons that it used when it came out
of the Oddballz egg, you will find that you can adopt its various 
Transformations separately at the Adoption Centre -- and also of course at 
last your Jester can play with and meet other petz, including itself
which of course it loves the most :-)

You cannot import your Oddballz pet directly from the Oddballz game, you will 
have to re-adopt him or her from the Adoption Centre.  But I think you
will find your pet as lovable as ever; even if it has lost its "memory",
it is still the same bright, bouncy, quirky little thing.  It can't do
the juggling and similar tricks that it did in Oddballz, but I think that
you'll find it a lot of fun to play with anyway.

The original Jester is in the Adoption Centre, of course, with its
red and yellow motley and black eyes.  But you will find a whole family of 
Jesters in there, some with different fur styles, Transformed faces, and 
different coloured eyes.  Just put back whichever ones come out that you 
don't want, until the right one for you comes out.

For your Jester to sound right, you will have to make sure that all its
.wav files and the jssn.txt file are in a subdirectory off your 
resource\catz directory, called Jester.  You should be able to download
the sounds from the same place from which you downloaded this breedfile.
When you've installed the sounds, replace that jssn.txt with the one which
is in this breedfile's zip.

Enjoy!

Carolyn Horn

