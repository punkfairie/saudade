
This is the Butterfly Attractor for Petz 2.  It's also a strange
mystery toy, and will cause some interesting effects in your game...

When you take it out of the toy box, don't worry about the fact that
you cannot see it in the hand.  Just put it straight into your
carry-case. Take your Attractor out, and wait for a while.  Soon 
some butterflies will start to come.  After a while, lift it up and 
move it; at some point, your attractor will become more flexible.
When you put it away, you may see an oblong of your playscene's
background.  Don't worry about it, it does no harm.  

Its mystery effects will sometimes occur if, after it has become flexible, 
you close the game without putting it away.  Next time you open the game 
it may have disappeared -- but the butterflies will still come to see 
your pet.  If you go to the toybox and find that everything has 
disappeared into a magenta background, the closet itself will re-appear 
if you click on where the shelves should be, and then you can see to go 
back to the playpen.  This is when it can really get intriguing :-)  

The flowerpot butterflies all love this toy; if you have the originals, and
my blooms and blowers in the game, you will have many different types
of butterflies.  Enjoy!

Carolyn