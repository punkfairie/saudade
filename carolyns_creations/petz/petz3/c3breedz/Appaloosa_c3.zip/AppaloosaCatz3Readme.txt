
This is the Appaloosa breedfile for Catz 3.  It was made at the request
of Sue of the Petz Boardwalk, and was exclusive to that site until, sadly,
it closed.  The site has since re-opened, in 2002, but Sue has kindly agreed
that the breed no longer is exclusive.

Note that, if you have had problems with breeding pets from the Appaloosa files 
which used to be up at the Petz Boardwalk, you will be able to breed them without
problems using this breedfile.

Place it in your Resource\catz directory, and you will then be
able to adopt three different colours of Appaloosa from it.

If you want your pets to speak "horse", then download the sound
files also, which should be available at the site whence you downloaded
this breedfile.  If you do download the sounds, then make a subdirectory 
off your Resource\catz directory, and call it ap.  Place all the .wav files 
and apsn.txt into this subdirectory.  Next time you bring out your 
Appaloosaz, they should talk to you.

Enjoy!

Carolyn Horn
