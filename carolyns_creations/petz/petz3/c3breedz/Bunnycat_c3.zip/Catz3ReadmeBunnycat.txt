
This is the Catz 3 breed file for the Bunny Cat.
Put it in your Resource\Catz directory, and it will show
up in your Adoption Centre the next time you go there.

Your Bunny catz are a little unusual; sometimes they will
be silent, sometimes their peacefulness will cause other
catz who are playing with them to be silent, and sometimes
they will talk "cat" along with your other catz :-)

Enjoy!

Carolyn Horn

