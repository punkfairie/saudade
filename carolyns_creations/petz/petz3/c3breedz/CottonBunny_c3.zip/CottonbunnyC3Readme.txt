This is the Catz 3 breed file for the Cotton Bunny,
which is a copy of the bunny which comes with Petz 4.

Put the Cotton Bunny.cat file in your Resource\Catz 
directory, and create the subdirectory:
Resource\Catz\bn 
Put all the .wav files, bnsn.txt, and the two furfiles
grey.bmp and white.bmp in this "bn" subdirectory.

The Cotton Bunny will then show up in your 
Adoption Centre the next time you go there, and
will talk "bunny" to you even as a youngster.
Of course, rabbits don't say much that we can
hear, but they do make some noises.  They have a
little grinding sound that serves instead of a
purr, for instance.

Enjoy!

Carolyn Horn

