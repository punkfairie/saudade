
This is the Scottish Fold cat, one of the 10 new official breedz 
which come with Petz 5, converted to Catz 3 for your gaming pleasure.

If others want to change the breed, that's fine by me -- I'm just
giving people who don't have Petz 5 the breedz as designed by Studio Mythos.

In Petz 5, the furfile is in another resource of the game; in the 
conversion, it has to be a separate file.

Please note, in order for your Scottish Fold to show up with its
furfile markings, you _need_ to be sure that the Scott1.bmp file
is in your game's resource\catz directory.

This is a sound-stripped breed for Petz 3.  It is an original game
breedfile, just with the sounds shifted onto your hard drive so that
you can download the sounds just once (they will work with all versions
of the Petz games 3, 4 and 5) and then all the breedfile downloads will 
be small, for all versions of the games. 

This breed overwrites the original, so take care to move your original
to somewhere safe before you install this one.  You may want your original
one back one day.

If you want your pets to have sounds, you can either run your newly-adopted
pets with the original breedfile in place, or you can download the relevant 
sounds which should be available from the place from which you downloaded this file
or from my site.  When you have downloaded the sounds, if you unzip them into
the game's main directory they should all go into the correct place.

If for some reason the unzipping process doesn't place them into the following
subdirectory which it should have created off your game's main directory:

\ptzfiles\cat\sf

then you will have to create that set of subdirectories yourself, using either
My Computer or Windows Explorer.  Off the game's main directory (where the .exe
file is) create a directory and call it ptzfiles.  Off that one, create another
and call it cat.  Off that one, create another and call it sf. Place all the .wav 
files and the sfsnd.txt file in that "sf" directory. Your pets will talk then.

Enjoy!

Carolyn Horn


