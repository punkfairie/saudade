

This is the Lips breed for Catz 3, Intenational version (for non-English games).

It uses data from the Oddballz breed, complete with sounds.  Although it 
cannot perform the in-game Transformations that it used when it came out of 
the Oddballz egg, you will find that you can adopt its various Transformations 
separately at the Adoption Centre -- and also of course at last your Lips can 
play with and meet other petz, including the one that it loves the most :-)  
The Lips will also be able to breed with any Catz-based breed.  Having 
said that, I have no idea what kind of odd babies the Lips will have, 
even when bred with another Lips!

You cannot import your Oddballz pet directly from the Oddballz game, you will 
have to re-adopt him or her from the Adoption Centre.  But I think you
will find your pet as lovable as ever; even if it has lost its "memory",
it is still the same bright, lippy, quirky little thing.  It cannot show
you its emotions as it used to with the Oddballz Emoticons, but I think you'll 
be able to figure out how it's feeling in Petz.

The original Lips is in the Adoption Centre, of course, with its
black body and black eyes.  But you will find a whole family of 
Lips in there, some with different coloured bodies and different coloured 
eyes.  Just put back whichever ones come out that you don't want, until 
the right one for you comes out.

For your Lips to sound right, you will have to make sure that all its
.wav files and the Lpsn.txt file are in a subdirectory off your 
resource\catz directory, called Lips.  You should be able to download
the sounds from the same place from which you downloaded this breedfile.

Enjoy!

Carolyn Horn

