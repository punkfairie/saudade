

My thanks to Carol (Minibyte) for the idea of producing a pair of 
formal footwear for other catz to wear who wish to dress up in 
Pharaoh's clothes, since Pharaoh himself will never take off his 
sandals. In fact, these new "sandals" are special socks, and Pharaoh 
himself can wear them over his own sandals.  For the sandals to look
right, make sure that the file called sphinx.bmp is in the game's 
clothes directory.

Carol's original version of these socks is provided with her Petz 3 
conversions of my Petz 4 Pharaoh clothes.  This more flamboyant version
of mine will overwrite her more sophisticated black ones.

Enjoy!

Carolyn Horn
