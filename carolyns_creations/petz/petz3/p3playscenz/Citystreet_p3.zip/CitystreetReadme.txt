
City Street is a Petz 3 playscene made by Terri of Terri's Petz 3.
Terri made a lot of lovely breedz and clothes.  She also made
several scenes, mostly with the assistance of Birgit of the PetzGallery, 
and all her scenes were of high quality.

The scene has its own extra internal sounds.

Enjoy!