
Egypt, or "Nile in Egypt" is a Petz 3 playscene made by "Tabi's SBAC".

There is the remains of an SBAC site, owned by Jade Bailey, still existing at
http://perso.wanadoo.fr/jade.bailey/home.html
but it appears to have been inactive since August 1999.  Jade made a lot of 
interesting items, and some helpful tutorials are still up at that site.

The scene was made available at the Playscene Paradise, and here's the blurb
which went with it: "Take your Petz on a tour of EGYPT with this nice scene 
from SBAC! Make sure to bring sunglasses and watch out for the flooding Nile 
waters that splash up onto the shore! This scene is bug-free! Well, almost! Watch 
out for the little scarabs that your Petz will love to chase about as well. ;-)"

To get the best out of this scene, put the included Tropical Bug.toy in your game's
toyz directory.  The scene originally came with this toy, but was incorrectly set up
in such a way that the toy never appeared; also the toy clashed with the game's
Auto-Rolling Ball.  I have fixed up the scene to work correctly with it, and to stop
it from clashing.  

An apology here to Carol Gortat (Minibyte) who I believe renamed the toy to fit the
info inside the scene as well as giving it a new offset etc; I cannot find her altered
version, so I went back to the SBAC originals to fix toy and scene.

This version also works best if you already have my Dung Beetle.toy in your game;
if you've got them, they'll turn up in the scene and be _real_ scarabs, doing
what Scarabs do naturally :-)

Enjoy!

Carolyn Horn