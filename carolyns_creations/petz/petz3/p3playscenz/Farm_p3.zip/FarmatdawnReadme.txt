
Farm at Dawn is a Petz 3 playscene made By Alexa of 
"Jester's Playscene Paradise" and Birgit of the PetzGallery.

It has its own internal sounds; extra sounds done by Birgit.

Alexa said: "Yes, ANOTHER farm scene! I made
this one manipulating several graphics and photos
(all my sunrise/sunset pictures in scenes are from my
missions trip to Haiti!) -- when I saw this image of a
farm, I just HAD to make it into a scene! Listen to
the sounds of daybreak in this beautiful new scene!"

Birgit said: "This is the Farm at Dawn Scene of
Alexa from Playscene Paradis which you perhaps
allready know, but with some new more 'farm like'
sounds" 

Enjoy!