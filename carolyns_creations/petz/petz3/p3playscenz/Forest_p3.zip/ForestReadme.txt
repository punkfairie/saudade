
Forest is a Petz 3 playscene made By Birgit of the 
PetzGallery; it is the first ever 3rd-party playscene 
to have been made.

It has its own internal sounds.

To quote Birgit: "This was the
first 'not official' playscene, the first one
that was not made by PF.Magic. Have a
little walk with your petz to the forest. Let
them play on this peaceful place with a lot
of birds and butterflies. And calm them,
when they hear suddenly a bear roar out
of the forest - the bears never come
out..." She gave special thanks to Terri
for her help in testing the scene. 
Contains its own internal sounds. 

Enjoy!