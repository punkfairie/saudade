
Mars was made by Terri of "Terri's Petz".
Terri made a lot of lovely breedz and clothes.  She also made
several scenes, mostly with the assistance of Birgit of the PetzGallery, 
and all her scenes were of high quality.  This one is best if you
have the Red Toy Car in your game.

Enjoy!