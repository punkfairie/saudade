
This playscene is one of the great collaborations between Lyrra of Pride Kennels and Cattery and Birgit of the PetzGallery.

It's best if you have the official download of the snowball toy in your game

Please read; this tells you how to use the patch.  For this scene, you need to have the official download of the Snow Scene, which you can download from various sites such as Daniel Wright's petz archive.

1. Open your windows explorer (or My Computer if it suits you better), and navigate your way through your files to the proper resource directory (or folder); for Petz 3 this would typically be on your C drive and would be in the directory (or folder):
c:\program files\pfmagic\petz 3\resource\area

2. Unzip the .zip file and place the Patch .exe file that was in it into the resource\area directory.

3. Make a copy of your Snow Scene.env file and put it somewhere safe. (copy and paste method works well, or right-click, drag and drop)

4. Now rename your Snow Scene.env to Northern Wilderness.env. (right-click on the name and choose "rename", then type the new name in its place)

5. Now double-click the patch. A window will pop up, last line reading: patching ... OK!

6. Now click enter. Your new playscene should be available next time you open your game. 

7. Replace your original Snow Scene.env into the resource\area directory.

Enjoy!


