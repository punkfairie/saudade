This is the Petz 3 version of this toy.

The "Blowers" are a variation of the original white potted flowers.  Just put
them in your game's Toyz directory, and they will show up separately on the shelf.

They are a separate toy, with pink and blue flowers and blue-tinted butterflies,
and they show up on the toy shelf with their own blue pot.

You can have my "blowers" and the original flowers blooming in your game together,
and your catz and dogz will enjoy chasing all the butterfiles.

Enjoy!

Carolyn Horn