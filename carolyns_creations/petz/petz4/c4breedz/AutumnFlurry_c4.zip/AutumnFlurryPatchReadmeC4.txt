
The Autumn Flurry was created at the request of Miranda, whose 
delightful "Autumn" pet was the basis for this breedfile.  I have 
included variations to make future breeding interesting.

NOTE: for the pet to look right, you must have all three .bmp files 
in a subdirectory, off your game's resource\catz directory, which 
must be named mc

This is a file which has been sound-stripped to make the download small.  

Because people with windows ME, XP etc have trouble with my small 
patches, I am now supplying all my breedz in this form, not just
my "species" (which have mostly been stripped, with external sounds).


If you want your pets to have sounds, you will need the Calico cat
sounds which should be available from the place from which you downloaded this file
or from my site.  When you have downloaded the sounds, if you unzip them into
the game's main directory they should all go into the correct place.

If for some reason the unzipping process doesn't place them into the following
subdirectory which it should have created off your game's main directory:

\ptzfiles\cat\ca

then you will have to create that set of subdirectories yourself, using either
My Computer or Windows Explorer.  Off the game's main directory (where the .exe
file is) create a directory and call it ptzfiles.  Off that one, create another
and call it cat.  Off that one, create another and call it ca. Place all the .wav 
files and the casnd.txt file in that "ca" directory. Your pets will talk then.

Enjoy!

Carolyn Horn


