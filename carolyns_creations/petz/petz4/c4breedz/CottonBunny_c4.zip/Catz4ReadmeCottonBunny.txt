This is the Catz 4 breed file for the the Cotton Bunny,
which is a copy of the bunny which comes with Petz 4,
but is fertile -- it will breed with other Cotton
Bunnies, or any catz-based breed! -- and it has its 
own bunny sounds.

Put the Cotton Bunny.cat file in your Resource\Catz 
directory, and create the subdirectory:
Resource\Catz\bn 
Put all the .wav files, bnsn.txt, and the two furfiles
grey.bmp and white.bmp in this "bn" subdirectory.

The Cotton Bunny will then show up in your 
Adoption Centre the next time you go there, and
will talk "bunny" to you even as a leveret.

Enjoy!

Carolyn Horn

