

Here is the Pug, one of the 10 new breedz which come with 
the Petz 5 game.

It has been converted by me for use in your Dogz 4 game; its appearance  
is identical to that of the Petz 5 version, and if you adopt a pet from
this breedfile and wish to play with it in Petz 5 later, you will be
able to import your pet.

NOTE: The tongue is supposed to be like that; in fact, there was
a small bug in the original which caused the end of the tongue to float 
about unattached.  I fixed it so that it is now attached properly -- 
but the shape and placing of it is exactly as originally designed.

If others want to change the breed, that's fine by me -- I'm just
giving people who don't have Petz 5 the breedz as designed by Studio Mythos.

This is a file which has been sound-stripped to make the download small.  


If you want your pets to have sounds, you will need the Pug
sounds which should be available from the place from which you downloaded this file
or from my site.  When you have downloaded the sounds, if you unzip them into
the game's main directory they should all go into the correct place.

If for some reason the unzipping process doesn't place them into the following
subdirectory which it should have created off your game's main directory:

\ptzfiles\dog\pu

then you will have to create that set of subdirectories yourself, using either
My Computer or Windows Explorer.  Off the game's main directory (where the .exe
file is) create a directory and call it ptzfiles.  Off that one, create another
and call it dog.  Off that one, create another and call it pu. Place all the .wav 
files and the pusnd.txt file in that "pu" directory. Your pets will talk then.

Enjoy!

Carolyn Horn