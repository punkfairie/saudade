
This is the Pilgrim Sweater which was in the Petz 3 game but was unaccountably
missing from the Petz 4 game's Pilgrim set.  Just put it in your game's Clothes 
directory, and it will show up separately on the shelf.

Enjoy!

Carolyn Horn