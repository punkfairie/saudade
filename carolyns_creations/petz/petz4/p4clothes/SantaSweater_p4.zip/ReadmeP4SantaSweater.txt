
This is the Santa Sweater which was in the Petz 3 game but was unaccountably
missing from the Petz 4 game's Santa set.  Just put it in your game's Clothes 
directory, and it will show up separately on the shelf.

Enjoy!

Carolyn Horn