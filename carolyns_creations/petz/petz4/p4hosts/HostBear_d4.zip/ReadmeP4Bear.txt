

This is the Dog Host from the Petz 4 Snow scene -- Bear!
Put Bear in your Adopted Petz folder and the .clo files,
Plaidal.bmp and Redrib.bmp in your Resource\clothes directory.  
Bear will then be ready to come out and play in any playscene, 
and his clothes will be available for all petz in the clothes
closet.

I have now added modifications to the filmstrips so that you 
can see the clothes looking as they should do in the closet.

Note that Bear himself may look a little strange without his
special clothes.  He is an exact clone of the Bear Host who 
is in the Petz 4 game, so that really is the way he's supposed 
to look.

If you don't have the Dogz part of Petz 4, of course, you will
not be able to have Bear in your game, but the clothes
will work.


Enjoy!

Carolyn Horn


NOTE: there should be no problems running the game with
the clothes and pet from this zipfile together. However,
if you are:
a) bringing in a "host" pet which has been in
the Petz 3 game wearing its clothes, or if you are 
b) replacing previously-downloaded Host's clothes of mine 
with these, and you bring the pet from that previously-
downloaded zip into the game with these clothes in place, 
you will possibly get an error message.
Don't panic; just remove all my "host" clothes from the game's
Clothes directory, re-open the game and bring the pet out.
It won't have any clothes on but it won't crash the game.
Now you can put the clothes back into the clothes directory
and put them back onto the pet.
