
This is the Cat Host from the Petz 4 Circus scene -- Bailey!
Put Bailey in your Adopted Petz folder and the .clo files
and fleks3.bmp in your Resource\clothes directory.  Bailey 
will then be ready to come out and play in any playscene, and 
his clothes will be available for all petz in the clothes
closet.

I have now added modifications to the filmstrips so that you 
can see the clothes looking as they should do in the closet.

My Petz 4 versions of these clothes are exact conversions of the
P.F.Magic Hosts' originals, for other Petz to use.  But P.F.Magic 
intended them only for use by Hosts, so there are some funny
little "quirks" which some clothes have when worn by other pets.
In the case of Bailey's clothes, when dogz wear the shirt it
is black; also if you try putting his sox on the front paws 
of your pets, the sox will simply disappear.  If you want to
try it and find that you end up unable to put any socks on
front paws after that, just close the game, remove Bailey's
sox from your game's clothes directory, and re-open the game.
The pet's sock status is then re-set to none :-)

Note that Bailey himself may look a little strange without his
special clothes.  He is an exact clone of the Bailey Host who 
is in the Petz 4 game, so that really is the way he's supposed 
to look.

If you don't have the Catz part of Petz 4, of course, you will
not be able to have Bailey himself in your game, but the clothes
will work.

Enjoy!

Carolyn Horn

NOTE: there should be no problems running the game with
the clothes and pet from this zipfile together. However,
if you are:
a) bringing in a "host" pet which has been in
the Petz 3 game wearing its clothes, or if you are 
b) replacing previously-downloaded Host's clothes of mine 
with these, and you bring the pet from that previously-
downloaded zip into the game with these clothes in place, 
you will possibly get an error message.
Don't panic; just remove all my "host" clothes from the game's
Clothes directory, re-open the game and bring the pet out.
It won't have any clothes on but it won't crash the game.
Now you can put the clothes back into the clothes directory
and put them back onto the pet.
