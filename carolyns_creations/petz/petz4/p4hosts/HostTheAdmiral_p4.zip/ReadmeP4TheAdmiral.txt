

This is the Dog Host from the Petz 4 South Seas scene -- The Admiral!
Put The Admiral in your Adopted Petz folder and the .clo files
in your game's Resource\clothes directory.  The Admiral
will then be ready to come out and play in any playscene, 
and his clothes will be available for all petz in the clothes
closet.

I have now  added modifications to the filmstrips so that you 
can see the clothes looking as they should do in the closet.

Note that The Admiral himself may look a little strange without his
special clothes.  He is an exact clone of the Admiral Host who 
is in the Petz 4 game, so that really is the way he's supposed 
to look.

If you don't have the Dogz part of Petz 4, of course, you will
not be able to have the Admiral in your game, but the clothes
will work.

Enjoy!

Carolyn Horn
