

This is the Cat Host from the Petz 4 Wild West scene -- Wyatt!
Put Wyatt in your Adopted Petz folder and the .clo files
in your game's Resource\clothes directory.  Wyatt
will then be ready to come out and play in any playscene, 
and his clothes will be available for all petz in the clothes
closet.

I have now added modifications to the filmstrips so that you 
can see the clothes looking as they should do in the closet.

My Petz 4 versions of these clothes were exact conversions of the
P.F.Magic Hosts' originals, for other Petz to use.  But P.F.Magic 
intended them only for use by Hosts, so there are some funny
little "quirks" which some clothes have when worn by other pets.
In the case of Wyatt's clothes, if you try putting the spurs
on a dog, to quote Minibyte, "They became giant "alien" spurs which 
the dog appeared to be chasing.  ROFL!"  Also, the vest does not 
appear in the correct colours when worn by dogz.

Note that Wyatt himself looks a little strange without his
special clothes.  He is an exact clone of the Wyatt Host who 
is in the Petz 4 game, so that really is the way he's supposed 
to look.

If you don't have the Catz part of Petz 4, of course, you will
not be able to have Wyatt in your game, but the clothes
will work.

Enjoy!

Carolyn Horn


NOTE: there should be no problems running the game with
the clothes and pet from this zipfile together. However,
if you are:
a) bringing in a "host" pet which has been in
the Petz 3 game wearing its clothes, or if you are 
b) replacing previously-downloaded Host's clothes of mine 
with these, and you bring the pet from that previously-
downloaded zip into the game with these clothes in place, 
you will possibly get an error message.
Don't panic; just remove all my "host" clothes from the game's
Clothes directory, re-open the game and bring the pet out.
It won't have any clothes on but it won't crash the game.
Now you can put the clothes back into the clothes directory
and put them back onto the pet.
