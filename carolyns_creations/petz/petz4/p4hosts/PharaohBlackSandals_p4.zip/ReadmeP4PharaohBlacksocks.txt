
My thanks to Carol (Minibyte) for the idea of producing a pair of 
formal footwear for other catz to wear who wish to dress up in 
Pharaoh's clothes, since Pharaoh himself will never take off his 
sandals. this is Carol's original version of these "Sandals".  
Her more sophisticated black ones will overwrite my more 
flamboyant version.

Enjoy!

Carolyn Horn
