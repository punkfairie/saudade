
This is a Petz 4 playscene, hex edited from the beach playscene so as to
give a fish-eye veiw of that beach.  It is a separate scene, it will _not_ 
overwrite your Beach.

I made this especially to go with my new goldfish bowl and goldfish tank
range of toyz, but petz enjoy it too, especially the fishie ones!
Yes, I know that in Real Life, goldfish are supposed to be freshwater fish.  
The ones I "liberated" from the goldfish bowl are ambiguous virtual types 
and can enjoy salt water :-)

Enjoy!

Carolyn Horn
