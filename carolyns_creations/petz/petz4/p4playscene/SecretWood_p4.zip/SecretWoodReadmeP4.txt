
This is the Petz 4 version of my Secret Wood playscene.

This scene comes with extra sounds and toyz, and a new carry-case and mice.  In order to enjoy it as it was intended, you need to download and install all these items, so please read the "readme" files very carefully.  If you cannot use the patchfile which gives you the mice and carry-case, then it's a shame because you won't see the scene exactly as it should be, but that can't be helped.  I hope you can still enjoy the scene anyway.

The scene is based on the huge central stone lion.  This is one of the giant granite sculptures created by Scottish sculptor Ronald Rae.  He carved it, using hand tools similar to those used by the ancient Egyptians, out of a 20-ton granite block.  You can see pictures of his works, and information about him, at his site
http://www.ronaldrae.co.uk/

For those who want to know more about how to make their own playscenes from the originals -- not using the Playscene Editor -- and the carry-case for Petz 4, I shall be putting together a tutorial based on my notes taken as I was creating this scene, complete with ready-to-use filmstrip sections etc.  It will be available at my site soon, I hope.

Place the Secret Wood.env file in your game's Resource\Area directory.  

If you have downloaded the sounds also, make sure that the env_roundabtloop.wav file is in the correct subdirectory.  If you unzip  the SecretWoodSounds.zip into your game's area directory, it should go automatically into the right place, but if not, you will need to make sure to create a subdirectory, off your Resource\Area directory, called SecretWood, and then another one off this subdirectory, called NewSounds.  The env_roundabtloop.wav, therefore, should end up in Resource\Area\SecretWood\NewSounds

If you have downloaded the toyz also, unzip the SecretWoodToyz zipfile into your game's Resource\Toyz directory.  This should cause a subdirectory called Birdiehouse and another one, off that one, called Sound, to be created; but if not, you will need to create by hand the Resource\Toyz\Birdiehouse\Sound directory, and place into it all five .wav files.  The four .toy files of course should be in the Toyz directory, and they will not clash with any of the P.F.Magic original toyz.  Although they were created specifically for this playscene, they will show up also in the toy closet.  Three of them will show up in the closet with their own graphics; the fourth will show up as a blank space on the shelf, because the base toy never had an on-shelf filmstrip, and once you've taken it off the shelf you won't be able to put it back on there.  I made it so that you can get it off the shelf because actually I like to see the little things running around in the toy room :-)

If you have downloaded the carry-case, please follow the patchfile instructions carefully.  If it works on your machine and operating system, both the carry-case and the mice should be replaced with my own versions.  For the mice to sound right, make sure that the two .txt files are in a subdirectory off the game's Resource directory called mouses and the .wav files are in a subdirectory off that one, called sound.

Enjoy!

Carolyn Horn

