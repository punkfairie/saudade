
This is the Catz 1 Squeaky Toy for Petz 4, for all those whose Catz 1 cats have
been pining for their old toy ever since they were imported to Petz 4 :-)

When you unzip this zipfile, you should see this readme and the toy file; 
you should also see the following subdirectory which it should have created 
off whichever directory you unzipped it into:

\art\sprites\Toyz\Chee_W1

Inside this "Chee_W1" directory there should be five files; one .txt, two .flm, 
and two .wav files.  What you need to do is to shift this nest of directories 
so that they come off your game's main directory.  If for some reason the 
unzipping process doesn't create these subdirectories, then you will have to 
create them yourself, using either My Computer or Windows Explorer. If so, it's 
pretty simple.  In Windows Explorer or My Computer, navigate to the game's main
directory (where the .exe is).  Now from the menu bar choose File, New, 
Folder.  Name the new folder art.  Open that new directory and repeat 
the process, this time calling the new folder or directory sprites.  Open
that directory and repeat, this time calling it Toyz.  Open that directory
and repeat one last time, calling the new one Chee_W1.  Place the five files
SOUNDS_CHEE_W1.txt, Chee_w1.flm, CHEE_W1_AWAY.FLM, Trleas1.wav and Trleas2.wav 
in there.

Place the SqueakyCatzToy.toy in your game's Toyz directory, of course.
But it is very important that these other files go into that 
\art\sprites\Toyz\Chee_W1 directory.

Next time your game opens you should see the dear old Catz 1 squeaky toy on 
the shelf.

Enjoy!

Carolyn Horn


