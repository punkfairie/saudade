
This is a Petz 4 toy.

The Goldfish Tank is based on that awful goldfish bowl; I made this because that
bowl seemed just plain cruel, with nothing in it for the fish to play in or hide
around.  _Not_ a good way to teach people how to look after animals!  So, just put
the toy in your game's Toyz directory, and it will show up separately on the shelf.

It is a separate toy, but it uses the same fish food as the goldfish bowl.

Enjoy!

Carolyn Horn