
NOTE: This version of the breedfile is fixed so that new
adoptees will _not_ "lay eggs" when excited.  Any pets
adopted from the previous version will still do so but,
as before, it does them no harm and the extra ballz will
disappear after you put the pet away.  The previous version
is also available for those who like that unusual
Feature :-)

This is the Catz 5 breed file for the Chickenz.

Put the Chickenz.cat and Feathers.bmp files in your 
Resource\Catz directory. 

The Chickens will then show up in your 
Adoption Centre the next time you go there.

If you want them to talk "Chicken" to you even as chicks,
then make sure you have downloaded the sound files also
(available from the site whence you downloaded this file),
and create the subdirectory:
Resource\Catz\chk
Put all the .wav files and chksn.txt in this "chk" 
subdirectory.

Enjoy!

Carolyn Horn

