
This is the Dogz 5 breed file for the Ancestor Lizard.

Put the Ancestor Lizard.dog file in your game's
Resource\Dogz directory; the lizards will then show up 
in your Adoption Centre the next time you go there.

These Lizards will bark just like dachshunds, but
there will be times when they will speak too quietly
to be heard, just as lizards are usually quiet.  This 
is intentional; after all, these lizards are "ancestors" 
of dogz as well as lizardz :-)

Enjoy!

Carolyn Horn

