
This is the Dogz 5 breed file for the Great Bearz.
Put it in your Resource\Dogz directory, and it will show
up in your Adoption Centre the next time you go there.
The bear has its own internal sounds, and will usually
speak "bear" to you.

There are various colours of Great Bear in this breed;
just choose the one you want when it comes out of the
Adoption centre.

The Great Bear will grow from a cute cuddly bear pup
to a large bear with a deep, growly voice.  It Don't worry,
though, it is as friendly and eager to please as your
other petz.

Enjoy!

Carolyn Horn

