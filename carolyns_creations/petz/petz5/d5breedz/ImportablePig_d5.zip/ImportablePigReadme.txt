
This breedfile is identical to the Petz 5 default breed except that it will show up at the Adoption Centre and you can import pets from previous games using it.  But with this breedfile in place you will not be able to play with the Pigz Hosts in the game, so you will have to either turn off the "Hosts in Playscenes" option or avoid the Backyard and Fantasy Castle.

You will probably not be able to breed your pets unless you use my "breedable" pig at the correct moments.

Enjoy!

Carolyn Horn

