
These are the toyz for the Petz 5 version of my Secret Wood playscene.

Unzip the SecretWoodToyz zipfile into your game's Resource\Toyz directory.  

This should cause a subdirectory called Birdiehouse and another one, off 
that one, called Sound, to be created; but if not, you will need to create 
by hand the Resource\Toyz\Birdiehouse\Sound directory, and place into it 
all five .wav files.  

The four .toy files of course should be in the Toyz directory, and they 
will not clash with any of the original toyz.  

Although they were created specifically for this playscene, you can use Tinker
to make them show up also in the toy closet.  All of them will show up in the 
Carry case with their own graphics, but don't have Tinker put the Dung Beetle 
in the case because as soon as you try to take it out again it will crash your game.

Enjoy!

Carolyn Horn
