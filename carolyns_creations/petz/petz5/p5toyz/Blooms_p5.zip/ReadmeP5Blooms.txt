This is the Petz 5 version of this toy.

The Blooms are a variation of the original white potted flowers.
Place the .toy file in your game's Toyz directory.

They are non-overwriting, so you have to do a little bit more...
Petz 5 is rather different from the earlier games, because you need
to make downloaded toyz show up in the cary-case.  The best way is to 
use Tinker (available from the "Nicholas' Tools" pages at my site).
Once Tinker is installed, just open it and choose "Modify Carry-case"
from the File menu.  Choose the toy that you want to have show up,
and use the up-arrow.  Close Tinker and open the game -- your new
toy should be in the case. 

Blooms are a separate toy, with pale blue flowers and red-tinted butterflies,
and they show up on the toy shelf with their own red pot.

You can have my Blooms and the original flowers blooming in your game together,
and your catz and dogz will enjoy chasing all the butterfiles.

Enjoy!

Carolyn Horn