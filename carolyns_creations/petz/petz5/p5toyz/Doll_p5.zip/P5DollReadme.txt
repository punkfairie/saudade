

This is my Babyz Doll for Petz 5.   It is made to look as close as
possible to the Babyz rag doll so that Petz players can enjoy that
toy in their games. 

To make it show up in your game you need to put everything in the
correct places:

The .toy file goes in the game's Toyz directory, of course.

The Case Nameinfo.lkv needs to go into your game's Resource\Keys 
directory.  It will overwrite the one which you already have there, 
so place your original somewhere safe first.

Now, to see extra toyz you need to have a full toycase.  To get a 
full toycase, if you have Windows 95, 98 or ME, just double-click on 
the .reg file included in this zip.  If you have Windows 2000 or XP
I do not know if this will work correctly.  If you have Windows 2000 
or XP or you'd rather do it manually, then open Regedit.exe (go to 
Start, then Run, then type in Regedit.exe and press Enter).  Navigate 
via the little crosses in the left-hand pane to
HKEY_LOCAL_MACHINE\SOFTWARE\StudioMythos\Petz 5\4.00.00
Place your cursor on the 4.00.00 folder and find the phrase "Case ListSize".
Double-click on it.  You will see a small hex editor pop up with 
0000 on the left, then a hexadecimal number three 00 numbers after it.
Highlight or delete that hexadecimal number, and type in 9F.  Press
OK and close Regedit.

Next time you open your game you should see my Doll in your 
Carrycase.  In the case, it looks like the tartan pants.

NOTE: any hexer who wants to port their own Babyz hexed dolls to 
Petz 5 can use this for that purpose.  There are some differences 
to take into account -- there are only 7 base balls instead of 17, 
and the xyz positions are very different due to the Petz defaults 
being different from the Babyz ones.  Note that the Petz 3 version 
is a little different from the Petz 4 and Petz 5 versions, so to 
convert your own hexed dollz to work in all games you'll need to 
make some alterations to your .LNZ files.

Enjoy

Carolyn Horn
