
This is a Petz 5 toy.

The Goldfish Bowl will overwrite the one that's already in your game.  Make sure
that you have the original moved somewhere safe in case you want the poor fish
to go back into it.

I made this because that bowl seemed just plain cruel, with nothing in it for the 
fish to play in or hide  around.  _Not_ a good way to teach people how to look after 
animals!

Your little fish can now float freely around; he'll still not stray far from where
you place him, but he is free of the restraint of glass.  Go to my special "fishy" playscene, 
which is a fish-eye view of the beach, and let the fishies play with each other and your petz.
Yes, I know that in Real Life, goldfish are supposed to be freshwater fish.  These ones 
of mine are saltwater varieties of fish :-)

You can still feed these little fishes; just hold the food over the centre point that
each one swims around.

If this total fishy freedom is too much for you, download my other version, which
will give your fish plenty of space and a miniature circus to swim around.

Enjoy!

Carolyn Horn