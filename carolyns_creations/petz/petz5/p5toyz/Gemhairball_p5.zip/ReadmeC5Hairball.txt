
NOTE: This _will_ overwrite your Hair Ball.toy, so make sure you have
moved the original to somewhere safe if you think you'll want it back.

This gem hairball will show up in the carry case if you make it do so. 
The best way is to use Tinker (available from the "Nicholas' Tools" pages 
at my site). Once Tinker is installed, just open it and choose "Modify 
Carry-case" from the File menu.  Choose the toy that you want to have 
show up, and use the up-arrow.  Close Tinker and open the game -- your new
toy should be in the case. 

Here's what dragonz cough up instead of that squishy, gross hairball.
What is it?  Why, a sapphire of course.  And if you put this in your
game instead of the Hair Ball.toy, all your catz will make you rich
with beautiful gems instead of sickened with yucky balls :-)

Enjoy!

Carolyn Horn

