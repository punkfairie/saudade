
This is a Petz 5 toy.

The Goldfish Bowl will overwrite the one that's already in your game.  Make sure
that you have the original moved somewhere safe in case you want the poor fish
to go back into it.

I made this because that bowl seemed just plain cruel, with nothing in it for the 
fish to play in or hide  around.  _Not_ a good way to teach people how to look after 
animals!

I have not created any new graphics for it, but your little fish now has a whole
miniature circus to play around, and he has a _lot_ more room.  You cannot see the
water or the edges of the tank -- that's really clean, clear water and glass ;-)

You can still feed him just the same -- hold the food over the centre of his nice 
big "tank" and the food will work.

Enjoy!

Carolyn Horn