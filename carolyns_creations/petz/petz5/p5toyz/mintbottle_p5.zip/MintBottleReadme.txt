

This is my Mint Bottle for Petz 5.  It is an editable toy which
you can also use as a base to edit your own petz drinks.

To make it show up in your game you need to put everything in the
correct places:

The .toy file goes in the game's Toyz directory, of course.

The Mint.lnz, Mint.scp, Mint.bhd, and Mint0.bdt need to go in a
subdirectory, off your game's main directory, which must be called
PtzFiles, and then into a subdirectory off that which must be called
Mint:

\PtzFiles\Mint

The Case Nameinfo.lkv needs to go into your game's Keys directory.
It will overwrite the one which you already have there, so place your
original somewhere safe first.

Now, to see extra toyz you need to have a full toycase.  To get a 
full toycase, if you have Windows 95, 98 or ME, just double-click on 
the .reg file included in this zip.  If you have Windows 2000 or XP
I do not know if this will work correctly.  If you have Windows 2000 
or XP or you'd rather do it manually, then open Regedit.exe (go to 
Start, then Run, then type in Regedit.exe and press Enter).  Navigate 
via the little crosses in the left-hand pane to
HKEY_LOCAL_MACHINE\SOFTWARE\StudioMythos\Petz 5\4.00.00
Place your cursor on the 4.00.00 folder and find the phrase "Case ListSize".
Double-click on it.  You will see a small hex editor pop up with 
0000 on the left, then a hexadecimal number three 00 numbers after it.
Highlight or delete that hexadecimal number, and type in 9E.  Press
OK and close Regedit.

Next time you open your game you should see my Mint Bottle in your 
Carrycase.

Enjoy

Carolyn Horn
