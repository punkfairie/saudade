
This file is intended for the use of hexers and anyone who wants to
change their Petz 3 Adoption Centre.

This Adoption Center.env file for Petz 3 will overwrite your game's original, and unless
you put everything in the correct place it _will_ crash your game, so please
please please make sure that you have your original safe somewhere and copies of
all your petz somewhere safe.

Place the Adoption Center.env in your game's resource\Area directory.
If you are using a non-English version of the game, download the extra AC file for
International users and use the Adoptionszentrum.env from that instead.

Now unpack the included zipfile, called AdoptioncenterFilesP3.zip, into your game's
main directory (the directory which contains the Petz 3.exe file)

The unzipping process _should_ create a set of subdirectories with the needed files in

\art\Sprites\Area\AdoptionCenter

What you should get are the  icon and the backdrop bitmaps.  These are simple
bitmaps and you can change these to whatever you wish in a paint program.

The Adoption Center filmstrips are in a different file; if you want to edit
them also, download my "Easy-edit Case, AC door, and mice etc for petz 3" kit plus,
for those with a non-English version of the game, the "Extra items required for petz 3 
non-English version".

Have fun giving your petz nice new Adoption Centres!

I would advise you not to try making it a separate playscene with its own ID number, as 
the game might crash if it contains two functioning Adoption Centres.  Nothing to stop you
from putting different filmstrips into it, disabling the AC features, and then having it as a
separate one of course; experiment as much as you wish, the worst that can happen is a few
game-crashes while you try things out :-)

Cheers

Carolyn Horn


