
The included zip contains the "DayToCloudy.spr" file to allow weather
effects if you downloaded and installed my easy-edit kit for the Petz 5 
Family Room.  Just unpack it into the root directory of your game 
(where the Petz .exe file is).  The DayToCloudy.spr file should automatically go 
into the correct place.  If not, you will have to drag-and-drop it into the 
game's

\art\sprites\Area\FamilyRoom

directory.  It will overwrite the small one which is already there.

Enjoy

Carolyn
