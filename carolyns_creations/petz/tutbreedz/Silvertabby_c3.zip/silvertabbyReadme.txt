

The Silver Tabby was designed to be an example for my Spikes "howto".
As I say in the howto, I called it a Silver Tabby because I had a 
downloaded pet which needed a breedfile which I don't have.  I found 
the ID number (one of my tutorials tells you how to do this) so, with 
the ID number and name I can run the pet.  But that seemed a little dull, 
so I thought I'd turn it into a spiky breed and see what happens when 
I breed my downloaded pet with it.  This is the kind of fun thing you can 
do when you're a hexer :-)

If you want to see the Silver Tabby the way I intended, you will need to 
have the three bitmaps in the correct place.

Make sure that there is a subdirectory, off your game's Resource\catz 
directory, which must be called "tabby" (without "" quotes of course).  
Put the three bitmaps t6.bmp, t7.bmp, t8.bmp in there.

This is a file which has been sound-stripped to make the download small.  

If you want your pets to have sounds, you will need the maine Coon
sounds which should be available from the place from which you downloaded this file
or from my site.  When you have downloaded the sounds, if you unzip them into
the game's main directory they should all go into the correct place.

If for some reason the unzipping process doesn't place them into the following
subdirectory which it should have created off your game's main directory:

\ptzfiles\cat\mc

then you will have to create that set of subdirectories yourself, using either
My Computer or Windows Explorer.  Off the game's main directory (where the .exe
file is) create a directory and call it ptzfiles.  Off that one, create another
and call it cat.  Off that one, create another and call it mc. Place all the .wav 
files and the mcsnd.txt file in that "mc" directory. Your pets will talk then.

Enjoy!

Carolyn Horn


