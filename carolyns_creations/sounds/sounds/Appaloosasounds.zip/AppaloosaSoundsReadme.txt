
These are the sound files for the Appaloosa.

Make a subdirectory off your Resource\catz directory, and call it ap.

Place all the .wav files, and apsn.txt from the breedfile archive, into this subdirectory.

Next time you bring out your Appaloosaz, they should talk to you.

Enjoy!

Carolyn Horn