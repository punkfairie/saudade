For people making their own Dogz 3, 4 and 5 bears, who want to
use my Great Bear sounds.

This is the sounds text file that you need in order to make
my Dogz II external bear sounds work with your Dogz 3, 4 and 5
Bear breedz.

Download the Great Bear sounds for Dogz II and unpack them
into your game's dogz directory.  A subdirectory called g
should thus be created, which contains the gbsnd.txt file,
and off that a directory called soun, which contains all the
wav files.  

To use them in Dogz 3, 4 or 5, You need to move all those wav 
files into the "g" directory, and you need to replace that 
gbsnd.txt file (which is for Petz II) with the one that's in this
zip.

Note for catz hexers:
If you want to use the Great Bear sounds with a Catz-based breed,
note that it will speak at all the wrong moments unless you have
a catz-based sounds txt file.  The same applies to my Tyger sounds.
It is not enough simply to redirect the sounds path to a catz
directory, you do need to use a catz sounds.txt file.

Enjoy!

Carolyn Horn

