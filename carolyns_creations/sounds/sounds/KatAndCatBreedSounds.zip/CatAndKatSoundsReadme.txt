
This zipfile contains the sound files for my "cat" Oddballz breedz.
You will want them if Catorwot, Catwingz, Kateydid and Katiedid.
Create a subdirectory off the Eggz\(name of breed) directory and call it Soundsss.

Put all the .wav files into this subdirectory, and your cat-like breed
will find its voice.

Enjoy!

Carolyn Horn

