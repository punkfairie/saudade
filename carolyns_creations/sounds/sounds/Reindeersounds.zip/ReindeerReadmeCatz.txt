
These are the sound files for the Catz 2, 3 and 4 Reindeerz.

Make a subdirectory off your Resource\catz directory, and call it rd.

Place all the .wav files and rdsn.txt into this subdirectory.
For Petz 2, replace the rdsn.txt with the one which was in the breedfile's zip.

Next time you bring out your Reindeerz, they should talk to you.

Enjoy!

Carolyn Horn