
Sandz Cat is the breed which I made back in the last century for Wendy of
Sand'z Cattery.  Sadly Wendy herself seems to have disappeared without
trace, but her site is still there, full of great Catz 3 breedz
as well as loads of fantastic pets that she bred herself and which will
work in Catz 3, 4 or 5.  Go there, you know you want to!
http://www.fortunecity.com/petparade/deer/160/intheframe.html
This breedfile was made using the data from Wendy's special cat, Fug,
which she sent to me for some corrective surgery as well as to have
him turned into a breed.

+++++++++++++++++

This is made from a sound-stripped breed for Petz 3 non-English -- an original 
game breedfile, simply with the sounds shifted onto your hard drive so that
you can download the sounds just once (they will work with all versions
of the Petz games 3, 4 and 5) and then all the breedfile downloads will 
be small, for all versions of the games.

If you want your pets to have sounds,  you can download the Russian Blue 
sounds which should be available from the place from which you downloaded this file
or from my site.  When you have downloaded the sounds, if you unzip them into
the game's main directory they should all go into the correct place.

If for some reason the unzipping process doesn't place them into the following
subdirectory which it should have created off your game's main directory:

\ptzfiles\cat\rb

then you will have to create that set of subdirectories yourself, using either
My Computer or Windows Explorer.  Off the game's main directory (where the .exe
file is) create a directory and call it ptzfiles.  Off that one, create another
and call it cat.  Off that one, create another and call it rb. Place all the .wav 
files and the rbsnd.txt file in that "rb" directory. Your pets will talk then.

Enjoy!

Carolyn Horn


