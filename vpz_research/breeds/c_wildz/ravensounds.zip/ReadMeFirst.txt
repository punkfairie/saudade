To hear your ravenz "talk" these enclosed files:

crowsnd.txt
caw.wav
loudcaw.wav
cawcaw.wav
coo.wav
purr.wav
soft.wav
longcaws.wav
rasp.wav
purr2.wav


need to be extracted to the following directly (in your petz game wherever it was installed).  "Petz 5\ptzfiles\cat\crow"

If the folders don't exist or this zip file dosn't create them, create them yourself.


Enjoy your new petz!


Vickie Boutwell
spark13@hotmail.com