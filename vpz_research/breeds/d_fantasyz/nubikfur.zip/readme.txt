This zip file contains textures for your Nubiks.  

If you unzip this to the same folder as your Nubik breedfile, it should create a folder called "nubik" with 16 bitmaps inside it.

If the zip file doesn't create this folder, you need to create a folder called "nubik" and place the bitmaps inside.

In summary, the 16 image files need to go into this directory:

C:\...\Petz 3\Resource\Dogz\nubik
or
C:\...\Petz 4\Resource\Dogz\nubik
or
C:\...\Petz 5\Resource\Dogz\nubik

Enjoy!



Vickie B.