This breed was created by me and can be downloaded from http://www.angelfire.com/moon2/petzzoo2/ 

The Cheetah VPZ.dog and the bitmaps included need to be put into the \Resource\Dogz folder in your Petz game.

If you want your cheetahs to have a voice, you need to download the Maine Coon sounds from Carolyn's Creations: http://carolyn.thepetzwarehouse.com/carolyn.htm 

The .WAV files from Carolyn's site must go into the Petz directory in this path 
\ptzfiles\cat\mc

The text file in this zip (mcsnx.txt) goes in the same folder as the .WAV files.

This file was tested on my computer using Windows XP and it works fine.  I cannot be held responsible nor help you with problems you might have.  If problems do occur with the file, simply remove it from yor game.



Vickie