Wow!  You're actually reading this thing!  Color me impressed!  As a special gift for your dilligence and ability to follow directions, I'm going to let you in on a secret...  

http://www.angelfire.com/moon2/mainecoon/20.htm

ABOUT AND INSTALATION

This breed was created by Vickie Boutwell and is available for download at http://www.angelfire.com/moon2/petzzoo2 or http://www.angelfire.com/moon2/mainecoon  Other versions of this breed (for Catz 3, Catz 4, and Catz 5) can also be found there.

The enclosed file needs to be extracted to the Resource\Catz folder in your game's directory.  You may have installed to a different location, but the default locations are
Catz 3: C:\Program Files\PF Magic\Petz 3\Resource\Catz
Catz 4: C:\Program Files\PF Magic\Petz 3\Resource\Catz
Catz 5: C:\Program Files\Ubi Soft\Studio Mythos\Petz 5\Resource\Catz

If this is an overwriting file, remember to save a backup of your original Maine Coon somewhere before extracting this file.  (If you accidentally overwrite your file, you can either reinstall your game or download a back-up from http://www.apkc.co.uk or http://www.petz.ws/archive/ )

This breed requires tabby fur files that you can download at the sites listed above.  These file goes in  the same folder as the breed file itself.

This file works fine on my computer, but I can't gaurantee it will work perfectly for you.  If you run into a problem, just remove the breed, and the proplem should be fixed.  (If not, then another file is causing problems, not my breed.)


VARIATIONS

The original version of this file contains the following variations:

4 body sizes/types
2 neck ruff variations
2 belly fur variations
13 color variations (black tabby, black, red tabby, red, blue tabby, blue, cream tabby, cream, white, tortie, tortie tabby, blue-cream, blue-cream tabby)
5 marking variations (solid and 4 types of bicolors)
6+ eye color variations (green, copper, gold, amber, blue, and odd-eyed)

The special show file contains only non-faulted PKC body types and one less bicolor variation.


IMPORTANT INFO

Every detail of this breed was created from scratch by me and I take a lot of pride in my work.  Please respect this by...

1) Not linking to the files on my server.
2) Providing a link to my page and a note of credit if you offer the file on your own page
3) Not using this breed to create your own breed... 
	DO NOT
	a. Use this breed as a base to make a new breed
	b. Copy any section of my breed (addballs, variations, or anything) to another file
		(even if you alter it, and even if you type it in rather than copy-paste)

You may of course, edit this file for personal needs, such as hexing litters or making specially colored pets for yourself.



I hope you enjoy this breed!

Vickie B.
spark13@hotmail.com